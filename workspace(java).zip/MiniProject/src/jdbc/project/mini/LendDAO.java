package jdbc.project.mini;

import java.sql.*;
import java.util.*;

import jdbc.project.connection.ProjectDBConnection;

public class LendDAO implements InterLendDAO {

	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;

	// === 자원반납 메소드 === //
	private void close() {
		try {
			if( rs != null )    rs.close();
			if( pstmt != null ) pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}// end of private void close()---------------------------


	// 대여 도서 조회
	@Override
	public List<LendDTO> lendBookList() {

		List<LendDTO> lendBookList = new ArrayList<>();

		conn = ProjectDBConnection.getConn();

		String sql = " select *  "+
				" from TBL_LEND ";

		try {

			pstmt = conn.prepareStatement(sql);

			rs = pstmt.executeQuery();

			while(rs.next()) {

				LendDTO ldto = new LendDTO();
				ldto.setLendcode(rs.getInt(1));
				ldto.setFk_userid(rs.getString(2));
				ldto.setLenddate(rs.getString(3));

				lendBookList.add(ldto);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}

		return lendBookList;
	}// end of public List<LendDTO> lendBookList()--------------------------


	// 채번 메소드
	@Override
	public int chaebun() {
		
		int seq = 0;
		
		conn = ProjectDBConnection.getConn();

		String sql = " select seq_lend.nextval "+
		             " from dual ";
		
		try {

			pstmt = conn.prepareStatement(sql);

			rs = pstmt.executeQuery();

			if(rs.next()) {
				seq = rs.getInt(1);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		
		return seq;
	}// end of public void chaebun()------------------------------------------


	// 대여테이블(tbl_lend)에 대여정보 insert 하기
	@Override
	public int insertLend(MemberDTO member, int seq) {

		int result = 0;

		try {
			conn = ProjectDBConnection.getConn(); // getConn에서 받아와 여기 conn에 넣어준다.

			String sql = " insert into tbl_lend(lend_code, fk_user_id) "+
					     " values(?, ?) ";

			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, seq);
			pstmt.setString(2, member.getUserid());
			
			result = pstmt.executeUpdate();

		} catch (SQLException e) {
			result = -1;
		} finally{
			close();
		}

		return result;
	}// end of public int insertLend(MemberDTO member, LibDTO libdto)----------------------
	
	

	   // 도서 대여해주기 - 대여 히스토리 테이블에 삽입(관리자)
	   @Override
	   public int lendhistory_insert(MemberDTO member, int seq) {
	      
	      int result = 0;
	      
	      try {
	         conn = ProjectDBConnection.getConn(); // getConn에서 받아와 여기 conn에 넣어준다.
	         
	         String sql = " insert into tbl_lend_history(lend_code, fk_user_id, fk_admin_id,lend_date) "+
	               " values(?,?,?,sysdate) ";
	         
	         pstmt = conn.prepareStatement(sql);
	         pstmt.setInt(1, seq);
	         pstmt.setString(2, member.getUserid());
	         pstmt.setString(3, member.getAdminid());


	         result = pstmt.executeUpdate();
	                  
	            
	      
	      } catch(SQLIntegrityConstraintViolationException e) {
	         if(e.getErrorCode() == 2291) { // 오라클의 제약조건에 위배가 된경우 발생함.
	            result = -1; // -1 이라는  -1. ==>isbn이 중복되어 프라이머리 키 제약 위배하여 등록실패한 것임.(Unique 제약에 위배 된 것임) 이거에 대한 에러코드를 만들자.
	         }
	         
	      } catch (SQLException e) {
	            result = -2; // -2  ==> SQL구문에 오류발생한 것임.
	      } finally{
	         close();
	      }
	      
	      
	      
	      
	      return result;
	   }
	
	
	

	// 대여상세테이블(lend_detail)에 대여상세정보 insert 하기
    @Override
	public int insertLendDetail(String isbn, int seq) {
		
		int result = 0;
		
		try {
			conn = ProjectDBConnection.getConn(); // getConn에서 받아와 여기 conn에 넣어준다.

			String sql = " insert into lend_detail(lend_d_code, fk_lend_code, fk_isbn, return_date) "+
					     " values(seq_lend_d.nextval, ?, ?, sysdate + 7) ";

			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, seq);
			pstmt.setString(2, isbn);

			result = pstmt.executeUpdate();

		} catch (SQLException e) {
			result = -2;
		} finally{
			close();
		}
		
		return result;
	}// end of public int insertLendDetail(LibDTO libdto, int seq)----------------------------

	
	
	 // 도서 대여해주기 - 대여 상세 히스토리 테이블에 삽입
	   @Override
	   public int lenddetailhistory_insert(String isbn, int seq) {
	   
	      int result = 0;
	      
	      try {
	         conn = ProjectDBConnection.getConn(); // getConn에서 받아와 여기 conn에 넣어준다.
	         
	          String sql = "   insert into lend_detail_history(lend_d_code, fk_lend_code, isbn, return_date) "+
	                "    values(seq_lend_d.nextval-1,?,?,sysdate+7) ";
	         
	          pstmt = conn.prepareStatement(sql);
	          pstmt.setInt(1,seq);
	          pstmt.setString(2,isbn);
	          
	          result = pstmt.executeUpdate();
	                  
	            
	      
	      } catch(SQLIntegrityConstraintViolationException e) {
	         if(e.getErrorCode() == 2291) { // 오라클의 제약조건에 위배가 된경우 발생함.
	            result = -1; // -1 이라는  -1. ==>isbn이 중복되어 프라이머리 키 제약 위배하여 등록실패한 것임.(Unique 제약에 위배 된 것임) 이거에 대한 에러코드를 만들자.
	         }
	         
	      } catch (SQLException e) {
	            result = -2; // -2  ==> SQL구문에 오류발생한 것임.
	      } finally{
	         close();
	      }
	      
	      
	      return result;
	   }
	
	
	   
	   
	// 대여중인 사람인지 확인하기
	@Override
	public void searchUser(MemberDTO member) {
		

		conn = ProjectDBConnection.getConn();

		String sql =  " select lend_code"
					+ ", to_char(lend_date, 'yyyy-mm-dd') as lend_date "
					+ ", to_char(return_date, 'yyyy-mm-dd') as return_date "
					+ ", userid "
					+ ", isbn "
					+ ", bookname "+
				" from  "+
				" ( "+
				" select A.lend_code AS lend_code "+
				" , A.fk_user_id AS userid "+
				" , A.lend_date AS lend_date "+
				" , B.fk_isbn AS isbn "+
				" , B.return_date AS return_date "+
				" , C.bookname AS bookname "+
				" from tbl_lend A "+
				" join lend_detail B "+
				" on A.lend_code = B.fk_lend_code "+
				" join tbl_lib C "+
				" on B.fk_isbn = C.isbn "+
				" ) D "
				+ " where userid = ? "
				+ " order by 1 asc ";

		try {

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, member.getUserid());

			rs = pstmt.executeQuery();
			
			

				
				StringBuilder sb = new StringBuilder();
				sb.append("=============== [ "+member.getName()+" 님의 대여현황 ] ============================================================\n");
				sb.append("대여번호\t대여일자\t\t반납예정일자\t\tID\tISBN\t책이름\n");
				sb.append("===========================================================================================\n\n");
				
				while(rs.next()) {
					sb.append(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3)+"\t"+rs.getString(4)+"\t"+rs.getString(5)+"\t"+rs.getString(6)+"\n");
				}
				
				sb.append("===========================================================================================\n\n");
				
				System.out.println(sb.toString());

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		

		
		
		
	}// end of 	public void searchUser(MemberDTO member)

	

	// 반납하려고 입력한 ISBN의 대여번호 가져오기
	@Override
	public LendDTO searchLendCode(String isbn) {
		
		conn = ProjectDBConnection.getConn();

		String sql = " select fk_lend_code, return_date "+
					 " from lend_detail "+
					 " where fk_isbn = ? ";
			
		LendDTO lenddto = null;
		
		try {

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, isbn);

			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				lenddto = new LendDTO();
				lenddto.setLendcode(rs.getInt(1));
				lenddto.setLenddate(rs.getString(2));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		
		return lenddto;
	}// end of public int searchLendCode(String isbn)---------------------------


	// 그 대여번호에서 남은 빌린 책의 갯수 알아내기
	@Override
	public int searchLendCnt(int lend_code) {
		int result = 0;
		
		try {
			conn = ProjectDBConnection.getConn(); // conn은 수동 commit으로 되어져 있다.

			String sql = " select lend_code, count(*) AS cnt "+
						" from tbl_lend A JOIN lend_detail B "+
						" on A.lend_code = B.fk_lend_code "+
						" where lend_code = ? "+
						" group by lend_code ";

			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, lend_code);

			rs = pstmt.executeQuery();

			if(rs.next()) {
				result = rs.getInt(2); // 갯수 몇개 남았나 가져옴
			}
			

		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		
		return result;
	}

	   // 대여상세 테이블 삭제하기
	   @Override
	   public int deleteLendDetail(String isbn) {
	      int result = 0;

	      try {
	         conn = ProjectDBConnection.getConn(); // conn은 수동 commit으로 되어져 있다.

	         String sql = " delete from lend_detail "
	               +    " where fk_isbn = ? ";

	         pstmt = conn.prepareStatement(sql);
	         pstmt.setString(1, isbn);

	         result = pstmt.executeUpdate();

	         System.out.println("\n>> 대여상세테이블에서 삭제함<<\n");

	      } catch(SQLException e) {
	         e.printStackTrace();
	      } finally {
	         close();
	      }

	      return result;
	   }// end of public int deleteLendDetail(String isbn)-------------------
	   
	   // 대여 테이블 삭제하기
	   @Override
	   public int deleteLend(int lend_code) {
	      
	      int result = 0;

	      try {
	         conn = ProjectDBConnection.getConn(); // conn은 수동 commit으로 되어져 있다.

	         String sql = " delete from tbl_lend "
	               +    " where lend_code = ? ";

	         pstmt = conn.prepareStatement(sql);
	         pstmt.setInt(1, lend_code);

	         result = pstmt.executeUpdate();

	         System.out.println("\n>> 대여테이블에서 삭제함 <<\n");
	         

	      } catch(SQLException e) {
	         e.printStackTrace();
	      } finally {
	         close();
	      }

	      return result;
	   
	   }// end of public int deleteLend(String isbn)-------------------------------


	   // 반납기간이 지났는지 확인하기
	   @Override
	   public int checkYeonche(String isbn) {
	      
	      int check = 0;
	      
	      conn = ProjectDBConnection.getConn();

	      String sql = " select case when current_date - return_date > 0 then 0 else 1 end AS yeonche "+
	                " from "+
	                " ( "+
	                "    select B.fk_isbn AS isbn "+
	                "         , to_date(to_char(B.return_date, 'yyyy-mm-dd')) AS return_date "+
	                "         , to_date(to_char(sysdate, 'yyyy-mm-dd')) AS current_date "+
	                "    from tbl_lend A JOIN lend_detail B "+
	                "    on A.lend_code = B.fk_lend_code "+
	                " ) D\n"+
	                " where isbn = ? ";   
	      
	      try {
	         pstmt = conn.prepareStatement(sql);
	         pstmt.setString(1, isbn);
	         rs = pstmt.executeQuery();
	         
	         if(rs.next()) {
	            check = rs.getInt(1);
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	      } finally {
	         close();
	      }
	      
	      return check;
	      
	   }// end of public int checkYeonche(String isbn)-------------------------------


	   // 연체에 넣을 정보들을 가져와준다.
	   @Override
	   public YeoncheDTO getToYeonche(String isbn) {
	      
	      conn = ProjectDBConnection.getConn();
	      
	      YeoncheDTO ycdto = new YeoncheDTO();
	      
	      String sql = " select to_date(current_date) - to_date(return_date) AS ycdate "+
	            "  ,  userid "+
	            "  ,  lend_d_code "+
	            " from "+
	            " ( "+
	            "    select A.lend_code AS lend_code "+
	            "         , A.fk_user_id AS userid "+
	            "         , A.lend_date AS lend_date "+
	            "         , B.fk_isbn AS isbn "+
	            "         , to_char(B.return_date, 'yyyy-mm-dd') AS return_date "+
	            "         , to_char(sysdate, 'yyyy-mm-dd') AS current_date "+
	            "         , B.lend_d_code as lend_d_code "+
	            "    from tbl_lend A JOIN lend_detail B "+
	            "    on A.lend_code = B.fk_lend_code "+
	            " ) D "+
	            " where isbn = ? ";
	      
	      try {
	         
	         pstmt = conn.prepareCall(sql);
	         pstmt.setString(1, isbn);

	         rs = pstmt.executeQuery();
	         
	         if(rs.next()) {
	            ycdto.setYc_date(rs.getString(1));
	            
	            int ycdate = Integer.parseInt(rs.getString(1));
	            
	            ycdto.setYc_fee(ycdate * 500);
	            ycdto.setFk_userid(rs.getString(2));
	            ycdto.setFk_lend_d_code(rs.getInt(3));
	            
	         }
	         
	      } catch (SQLException e) {
	         e.printStackTrace();
	      } finally {
	         close();
	      }
	      
	      return ycdto;
	   }// end of public YeoncheDTO getToYeonche(String isbn)---------------------------------


	   // ycdto 에 넣은 정보를 토대로 연체 테이블에 넣는다.
	   @Override
	   public int goToYeonche(YeoncheDTO ycdto) {
	      
	      int result = 0;
	      
	      try {
	         conn = ProjectDBConnection.getConn(); // getConn에서 받아와 여기 conn에 넣어준다.
	         
	         String sql = "insert into tbl_yeonche(yc_code, yc_date, yc_fee, fk_userid, fk_lend_d_code)\n"+
	                    "values(seq_yeonche.nextval, ?, ?, ?, ?)";
	         
	         pstmt = conn.prepareCall(sql);
	         
	         pstmt.setString(1, ycdto.getYc_date());
	         pstmt.setInt(2, ycdto.getYc_fee());
	         pstmt.setString(3, ycdto.getFk_userid());
	         pstmt.setInt(4, ycdto.getFk_lend_d_code());
	         
	         
	         result = pstmt.executeUpdate();
	         
	         conn.commit();

	      } catch (SQLException e) {
	         e.printStackTrace();
	      } finally{
	         close();
	      }
	      
	      return result;
	   }// end of public int goToYeonche(YeoncheDTO ycdto)--------------------------



	




}
