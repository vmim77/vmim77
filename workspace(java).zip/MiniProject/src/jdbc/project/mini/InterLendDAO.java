package jdbc.project.mini;

import java.util.List;

public interface InterLendDAO {

	List<LendDTO> lendBookList();	// 대여 도서 조회

	int lendhistory_insert(MemberDTO member, int seq); // 도서 대여해주기 - 대여 히스토리 테이블에 삽입(관리자)

	int lenddetailhistory_insert(String isbn, int seq); // 도서 대여해주기 - 대여 상세 히스토리 테이블에 삽입

	int chaebun(); // 채번 메소드

	int insertLend(MemberDTO member, int seq); // 대여테이블(tbl_lend)에 대여정보 insert 하기

	int insertLendDetail(String isbn, int seq); // 대여상세테이블(lend_detail)에 대여상세정보 insert 하기

	void searchUser(MemberDTO member); // 대여중인 사람인지 확인하기

	LendDTO searchLendCode(String isbn); // 반납하려고 입력한 ISBN의 대여번호 가져오기

	int searchLendCnt(int lend_code); // 그 대여번호에서 남은 빌린 책의 갯수 알아내기

	int deleteLendDetail(String isbn); // 대여상세 테이블 삭제하기

	int deleteLend(int lend_code); // 대여 테이블 삭제하기

	int checkYeonche(String isbn); // 반납기간이 지났는지 확인하기

	YeoncheDTO getToYeonche(String isbn); // 연체에 넣을 정보들을 가져와준다.

	int goToYeonche(YeoncheDTO ycdto); // ycdto 에 넣은 정보를 토대로 연체 테이블에 넣는다.
	
	

}
