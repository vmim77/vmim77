package jdbc.project.mini;

public class MemberDTO {

	private String userid;         // 회원아이디(PK)
	private String passwd;         // 비밀번호
	private String name;         // 회원명
	private String birthdate;      // 생년월일
	private String address;         // 주소
	private String mobile;         // 전화번호
	private String email;         // 이메일
	private String adminid; 	// 관리자아이디




	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getPasswd() {
		return passwd;
	}

	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getBirthdate() {
		return birthdate;
	}
	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}

	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public String getAdminid() {
		return adminid;
	}

	public void setAdminid(String adminid) {
		this.adminid = adminid;
	}



	public String viewInfo() {


		return "1.아이디 :"  + userid+"\n"
				+"2.비밀번호 :" + passwd+"\n"
				+"3. 이름 : " + name + "\n"
				+"4. 연락처 : " + mobile + "\n"
				+"5. 주소 : " + address + "\n"
				+"6. 이메일 : " + email;
	}





}