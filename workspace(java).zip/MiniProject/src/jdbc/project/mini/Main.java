package jdbc.project.mini;

import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		
		TotalController tctrl = new TotalController();
		Scanner sc = new Scanner(System.in);
		
		tctrl.mainMenu(sc);
		
		sc.close();
		System.out.println("~~~ 프로그램 종료 ~~~");
	} // end of main(String[] args)-----------------------------

}
