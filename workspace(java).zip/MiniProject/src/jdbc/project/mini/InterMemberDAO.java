package jdbc.project.mini;

import java.util.*;

public interface InterMemberDAO {
	
	// 회원 가입
	public int memberRegister(MemberDTO member, Scanner sc);
	
	// 관리자 회원가입
	public int adminRegister(MemberDTO member, Scanner sc);
	
	// 관리자 로그인
	public MemberDTO login(Map<String, String> paraMap);
	
	// 회원 로그인
	public MemberDTO memberLogin(Map<String, String> paraMap);
	
	// 회원 정보 수정
	public int changeInfo(MemberDTO member, Scanner sc);
	
	// 전체 회원 조회
	List<MemberDTO> showAllMember();
	
	// 연체 회원 조회
	List<YeoncheDTO> showAllYeonche();
	
	// 회원 탈퇴하기전 대여 있는지 확인 메소드
	List<Map<String, String>> memberLendCheck(MemberDTO member);
	
	//탈퇴하기전 연체있는지 확인 메소드
	List<Map<String, String>> memberYCheck(MemberDTO member);
	
	// 회원 아이디 삭제
	int memberDelete(MemberDTO member);

}
