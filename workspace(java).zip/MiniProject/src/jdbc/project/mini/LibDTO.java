package jdbc.project.mini;

import java.util.regex.*;


public class LibDTO {




	private String isbn;            // ISBN(Unique)
	private String fk_sub_code;      // 소분류코드
	private String bookname;      // 도서명
	private String writer;         // 저자
	private String publisher;      // 출판사
	private String price;        //가격
	private String status;		// tbl_book 책의 상태(0 : 보유중, 1 : 대여중)



	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getFk_sub_code() {
		return fk_sub_code;
	}
	public void setFk_sub_code(String fk_sub_code) {

		Pattern p = Pattern.compile("^[A-Ja-j][0][1-2]$");

		Matcher m = p.matcher(fk_sub_code);

		boolean bool = m.matches();

		if(bool){
			this.fk_sub_code = fk_sub_code;
		}
		else {
			System.out.println(" \n >>"+fk_sub_code+"는 소분류 코드에 맞지 않습니다. <<\n");
			this.fk_sub_code = null;
		}
	}

	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}


	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}


	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}


	///////////////////////////////////////////////////
	public String viewInfo() {

		
		return isbn+"\t"+fk_sub_code+"\t"+bookname+"\t"+writer+"\t"+publisher+"\t"+price;
	}

	public String viewInfo2() {

		
		return isbn+"\t"+fk_sub_code+"\t"+bookname+"\t"+writer+"\t"+publisher+"\t"+price+"\t"+status;
	}


}