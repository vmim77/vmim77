package jdbc.project.mini;

import java.util.*;

import jdbc.project.connection.ProjectDBConnection;


public class TotalController {

	LibDAO libdao = new LibDAO();
	LendDAO lenddao = new LendDAO();
	MemberDAO mdao = new MemberDAO();

	// **** 메인 메뉴 **** //
	public void mainMenu(Scanner sc) {

		String mainMenuNo = "";
		do {
			System.out.println("\n--------------- 메인메뉴 ----------------\n");
			System.out.println("1. 관리자            2. 회원             3. 프로그램 종료                  \n");
			System.out.println("---------------------------------------\n");
			System.out.print("▷ 메인메뉴 번호 선택 : ");
			mainMenuNo = sc.nextLine();

			switch (mainMenuNo) {
			case "1" : // 관리자
				adminloginMenu(sc);
				break;

			case "2" : // 회원
				userMenu(sc);
				break;

			case "3" : // 프로그램 종료
				ProjectDBConnection.closeConnection();// Connection 객체 자원 반납
				break;

			default:
				System.out.println("@@@ 잘못된 번호입니다. 다시 입력하세요!! @@@");
				break;
			}
		} while(!"3".equals(mainMenuNo));
	}// end of public void mainMenu(Scanner sc) --------------------


	// **** 회원 메뉴 *****//
	private void userMenu(Scanner sc) {

		MemberDTO member  = null;
		String menuNo = "";
		do {


			String loginName = (member==null)?"":"["+ member.getName() +" 로그인중..]";


			System.out.println("\n ---------회원 메뉴 "+ loginName +"-----------\n");
			System.out.println("1. 회원가입    2. 회원 로그인   3. 로그아웃  4. 정보수정하기  5. 도서검색\n"
					+ "6. 도서 대여하기   7. 도서 반납하기   8. 나의 대여 현황   9. 회원탈퇴      10. 뒤로가기");

			System.out.print("▷메뉴번호 선택 : ");
			menuNo = sc.nextLine();

			switch (menuNo) {

			case "1": // 회원가입

				memberRegister(sc);

				break;

			case "2": // 회원 로그인
				
				member = memberLogin(sc);

				break;

			case "3": // 로그아웃
	            if(member != null) {
	               member = null;
	               System.out.println(">> 로그아웃 됐습니다. <<");
	            }
	            else {
	               System.out.println("\n>> 로그인을 먼저 해주세요!! << \n");
	            }

	            break;

			case "4": // 내 정보
				if(member != null) {
					infoMenu(sc, member);
				}
				else {
					System.out.println("\n>> 로그인을 먼저 해주세요!! << \n");
				}

				break;

			case "5": // 도서검색

				searchBook(sc);


				break;

			case "6": // 도서 대여하기
				if(member != null) {
					lendMenu(member,sc);
				}
				else {
					System.out.println("\n>> 로그인을 먼저 해주세요!! << \n");
				}

				break;

			case "7": // 도서 반납하기
				if(member != null) {
					returnMenu(member,sc);
				}
				else {
					System.out.println("\n>> 로그인을 먼저 해주세요!! << \n");
				}
				
				
				break;

			case "8": // 나의 대여 현황
				myLendBook(member);
				break;

			case "9": // 회원 탈퇴
				member = memberDelete(member, sc);
				break;

			case "10": // 뒤로가기

				break;


			default:
				System.out.println(">> 메뉴에 없는 번호입니다!! 다시 선택하세요 << \n");
				break;
			}


		} while( !("10".equals(menuNo)) );
		// end of do~while---------------------------


	}// end of private void userMenu(Scanner sc)----------------------------

	


	// *** 관리자 메뉴 *** //
	private void adminloginMenu(Scanner sc) {

		String menuNo = null;

		do {
			System.out.println("\n------ 관리자 메뉴 ------\n");
			System.out.println("1.회원가입    2.로그인    3.뒤로가기");

			System.out.print("▷메뉴번호 선택 : ");
			menuNo = sc.nextLine();


			switch (menuNo) {
			case "1" : // 관리자 회원가입
				adminRegister(sc);
				continue;

			case "2" : // 관리자 로그인 & 로그아웃
				login(sc);   // 로그인 시도하기
				break;

			case "3" : // 뒤로가기

				break;

			default:
				System.out.println(">> 잘못된 번호입니다. 다시 입력하세요!! <<");
				break;
			}
		} while(!"3".equals(menuNo));
	}


	// **** 관리자 메뉴 **** //
	private void adminMenu(Scanner sc, MemberDTO member) {

		String menuNo = null;

		outer:
			do {

				System.out.println("\n--------------- 관리자 메뉴[" + member.getName() + "님 로그인중..] ---------------\n");
				System.out.println(" 1.도서등록             2.전체 도서 조회     3.대여 도서 조회\n" 
								 + " 4.전체 회원 조회     5.연체 회원 조회     6.도서 정보 변경\n" 
								 + " 7.도서 삭제            8.로그아웃             9.뒤로가기\n");

				System.out.print("▷메뉴번호 선택 : ");
				menuNo = sc.nextLine();

				switch (menuNo) {

				case "1" : // 도서 등록
					libRegister(sc);
					break;

				case "2" : // 전체 도서 조회
					bookList();
					break;

				case "3" : // 대여 도서 조회
					lendBookList();
					break;

				case "4" : // 전체 회원 조회
					showAllMember();
					break;

				case "5" : // 연체 회원 조회
					showYeoncheMember();
					break;

				case "6" : // 도서 정보 변경
					int n = updateLib(member, sc);

					/*
	                   n == 0   검색하신 ISBN 코드는 존재하지 않습니다.  
	                   n == 1   도서 변경 성공!!  
	                   n == 2   장애발생으로 인해 도서 변경 실패!!  
	                   n == 3   도서 변경을 취소하였습니다.  
					 */

					if(n==0) {
						System.out.println("\n>> 검색하신 ISBN 코드는 존재하지 않습니다. <<\n");
					}
					else if(n==1) {
						System.out.println("\n>> 도서 변경 성공!! <<\n");
					}
					else if(n==2) {
						System.out.println("\n>> 장애발생으로 인해 도서 변경에 실패했습니다. <<\n");
					}
					else if(n==3) {
						System.out.println("\n>> 도서 변경을 취소하였습니다. <<\n");
					}

					break;

				case "7" : // 도서 삭제

					n = deleteLib(member, sc);

					/*
	                   n == 0   검색하신 ISBN 코드는 존재하지 않습니다.  
	                   n == 1   도서 삭제 성공!!  
	                   n == 2   장애발생으로 인해 도서 삭제 실패!!  
	                   n == 3   도서 삭제을 취소하였습니다.  
					 */

					if(n==0) {
						System.out.println("\n>> 검색하신 ISBN 코드는 존재하지 않습니다. <<\n");
					}
					else if(n==1) {
						System.out.println("\n>> 도서 삭제 성공!! <<\n");
					}
					else if(n==2) {
						System.out.println("\n>> 장애발생으로 인해 도서 삭제에 실패했습니다. <<\n");
					}
					else if(n==3) {
						System.out.println("\n>> 도서 삭제를 취소하였습니다. <<\n");
					}

					break;

				case "8" : // 로그아웃


					do {
						System.out.print(">> 로그아웃 하시겠습니까?[Y/N] : ");
						String yn = sc.nextLine();

						if("y".equalsIgnoreCase(yn)) {
							member = null;
							System.out.println("@@@ 로그아웃 되었습니다. @@@\n");
							break outer;
						} else if("n".equalsIgnoreCase(yn)) {
							break;
						} else {
							System.out.println("!!! Y 또는 N 만 입력하세요. !!!\n");
						}
					} while(true);

					break;

				case "9" : // 뒤로가기

					break;

				default:
					break;
				}
			}while(!"9".equals(menuNo));
	} //end of private void adminMenu(Scanner sc)----------------------




	// 멤버 회원가입
	private void memberRegister(Scanner sc) {

		System.out.print("▷ 아이디 : ");
		String userid = sc.nextLine();

		System.out.print("▷ 비밀번호 : ");
		String passwd = sc.nextLine();

		System.out.print("▷ 성명 : ");
		String name = sc.nextLine();

		System.out.print("▷ 생년월일[ 8글자로 입력해주세요 ex.1999-09-29 ] : ");
		String birthdate = sc.nextLine();

		System.out.print("▷ 연락처 : ");
		String mobile = sc.nextLine();

		System.out.print("▷ 주소 : ");
		String address = sc.nextLine();

		System.out.print("▷ 이메일 : ");
		String email = sc.nextLine();

		MemberDTO member = new MemberDTO();
		member.setUserid(userid);
		member.setPasswd(passwd);
		member.setName(name);
		member.setBirthdate(birthdate);
		member.setMobile(mobile);
		member.setAddress(address);
		member.setEmail(email);

		mdao.memberRegister(member, sc);

	}// end of private void memberRegister(Scanner sc)-----------------------

	// **** 관리자 회원가입 **** //
	private void adminRegister(Scanner sc) {

		System.out.println("\n >>> ----- 회원가입 ----- <<<");

		System.out.print("1.관리자 아이디 : ");
		String adminid = sc.nextLine();

		System.out.print("2.비밀번호 : ");
		String passwd = sc.nextLine();

		System.out.print("3.이름 : ");
		String name = sc.nextLine();


		MemberDTO member = new MemberDTO();
		member.setAdminid(adminid);
		member.setPasswd(passwd);
		member.setName(name);

		int n = mdao.adminRegister(member, sc);
		/*
	         0 ==> 정상적으로 회원가입을 취소한 것(rollback)
	         1 ==> 정상적으로 회원가입한 것(commit)
	         -1 ==> 사용자 아이디가 중복되어 회원가입이 실패한 것(Unique 제약에 위배된 것)
	         -2 ==> SQL구문에 오류 발생한 것
		 */

		if(n==0) {
			System.out.println("\n>>> 회원가입을 취소하셨습니다. <<<");
		} 
		else if(n==1) {
			System.out.println("\n>>> 회원가입을 축하드립니다. <<<");
		} 
		else if(n==-1) {
			System.out.println("\n>>> 아이디가 이미 사용중이므로 다른 아이디로 입력하세요. <<<");
		}
		else if(n==-2) {
			System.out.println("\n>>> SQL 구문에 오류 발생!! <<<");
		}

	} // end of private void memberRegister(Scanner sc)------------------------


	// **** 회원 로그인 **** //
	private MemberDTO memberLogin(Scanner sc) {

		MemberDTO member = null;

		System.out.println("\n >>> ---- 로그인 ---- <<<");
		System.out.print("▷.아이디 : ");
		String userid = sc.nextLine();

		System.out.print("▷비밀번호 : ");
		String passwd = sc.nextLine();

		Map<String, String> paraMap = new HashMap<>();
		paraMap.put("userid", userid);
		paraMap.put("passwd", passwd);


		member = mdao.memberLogin(paraMap);

		return member;
	}// end of private MemberDTO memberLogin(Scanner sc) ---------------------------------






	// **** 관리자 로그인 **** //
	private MemberDTO login(Scanner sc) {

		MemberDTO member = null;

		System.out.println("\n >>> ---- 로그인 ---- <<<");
		System.out.print("▷.아이디 : ");
		String adminid = sc.nextLine();

		System.out.print("▷비밀번호 : ");
		String passwd = sc.nextLine();

		Map<String, String> paraMap = new HashMap<>();
		paraMap.put("adminid", adminid);
		paraMap.put("passwd", passwd);

		member = mdao.login(paraMap);


		if(member != null) {
			System.out.println("\n >>> 로그인 성공!! <<< \n");
			adminMenu(sc, member);
		}
		else {
			System.out.println("\n >>> 로그인 실패!! <<< \n");
		}


		return member;
	} // end of private MemberDTO login(Scanner sc)-------------------------



	//*****도서 등록하기 ******//
	private void libRegister(Scanner sc) {
	      
	      LibDTO libdto = new LibDTO();

	      
	      System.out.println("\n >>>-------------도서등록 ------------------<<<");
	      
	      System.out.println("1. ISBN : ");
	      String isbn = sc.nextLine();

	      System.out.println("2. 도서명 : ");
	      String bookname = sc.nextLine();
	      
	      System.out.println("3. 저자명 : ");
	      String writer = sc.nextLine();
	      
	      System.out.println("4. 출판사 : ");
	      String publisher = sc.nextLine();
	      
	      System.out.println("5.가격 : ");
	      String price = sc.nextLine();
	      
	      do {
	         System.out.println("6. 소분류 코드 : ");
	         String fk_sub_code = sc.nextLine();
	         
	         libdto.setFk_sub_code(fk_sub_code);
	         
	         if(libdto.getFk_sub_code() != null) {
	            break;
	         }
	         
	         }while(true);
	      
	   
	      
	      libdto.setIsbn(isbn);
	      libdto.setBookname(bookname);
	      libdto.setWriter(writer);
	      libdto.setPublisher(publisher);
	      libdto.setPrice(price);
	   
	      
	      int n = libdao.libRegister(libdto,sc);
	      
	      if(n == 1) {
	         libdao.libdetailRegister(libdto);
	         
	      }
	      
	      if(n==0) {
	         System.out.println("\n >>> 도서등록을 취소하셨습니다. <<<");
	      }
	      else if(n==1) {
	         System.out.println("\n >>> 도서등록을 축하드립니다!!!!. <<<");
	      }
	      else if(n== -1){
	         System.out.println("\n >>> 제약에 위배 됩니다 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!.<<< ");
	      }
	      else if(n==-2) {
	         System.out.println("\n >>> SQL 구문에 오류가 발생함!! <<");
	      }
	      
	   }//end of private void libRegister(Scanner sc)-----------------------------------------------------------


	// 전체 도서 조회
	private void bookList() {

		List<LibDTO> bookList = libdao.bookList();

		if(bookList.size() > 0) {

			System.out.println("\n-------------------- [전체도서목록] ---------------------------------");
			System.out.println("ISBN\t소분류코드\t책이름\t글쓴이\t출판사\t가격\t상태");
			System.out.println("\n-------------------------------------------------------------------");

			StringBuilder sb = new StringBuilder();

			for(LibDTO libdto :bookList ) {

				sb.append(libdto.viewInfo2()+"\n");

			}// end of for---------------------------------

			System.out.println(sb.toString());
		}

		else {
			System.out.println(">> 보유중인 책이 없습니다. << \n");
		}



	}// end of private void bookList() -------------------------------------


	// 대여 도서 조회
	private void lendBookList() {

		List<LendDTO> lendBookList = lenddao.lendBookList();

		if( lendBookList.size() > 0 ) {

			System.out.println("\n-------------------- [대여도서목록] ---------------------------------");
			System.out.println("대여코드\t유저아이디\t관리자아이디\t대여일자");
			System.out.println("\n-------------------------------------------------------------------");


			StringBuilder sb = new StringBuilder();

			for(LendDTO ldto : lendBookList) {

				sb.append(ldto.viewInfo()+"\n");

			}// end of for---------------------------

			System.out.println(sb.toString());
		}
		else {
			System.out.println(">> 대여중인 책이 없습니다. << \n");
		}


	}// end of private void lendBookList()------------------------------------
	
	
	
	
	// 정보 메뉴(정보조회, 정보변경)
		private void infoMenu(Scanner sc, MemberDTO member) {

			System.out.println("\n>>"+member.getName() + " 님의 현재 정보입니다. << \n");
			System.out.println(member.viewInfo());

			String original_passwd = member.getPasswd();
			String original_name = member.getName();
			String original_mobile = member.getMobile();
			String original_address = member.getAddress();
			String original_email = member.getEmail();


			do {
				System.out.print("\n▷암호 변경[변경하지 않으려면 그냥 엔터하세요] : "); 
				String passwd = sc.nextLine();

				if(passwd != null && passwd.trim().isEmpty() ) {
					passwd = original_passwd; 
				}


				member.setPasswd(passwd);

				if( member.getPasswd() != null ) { 
					break;
				}

			} while(true);

			do {
				System.out.print("▷이름 변경[변경하지 않으려면 그냥 엔터하세요] : "); 
				String name = sc.nextLine();

				if( name != null && name.trim().isEmpty() ) {
					name = original_name; 
				}

				member.setName(name);

				if( member.getName() != null ) { 
					break;
				}

			} while(true);

			do {
				System.out.print("▷연락처 변경[변경하지 않으려면 그냥 엔터하세요] : "); 
				String mobile = sc.nextLine();

				if( mobile != null && mobile.trim().isEmpty() ) {
					mobile = original_mobile; 
				}

				member.setMobile(mobile);

				if( member.getMobile() != null ) { 
					break;
				}

			} while(true);

			do {
				System.out.print("▷주소 변경[변경하지 않으려면 그냥 엔터하세요] : "); 
				String address = sc.nextLine();

				if( address != null && address.trim().isEmpty() ) {
					address = original_address; 
				}

				member.setAddress(address);

				if( member.getAddress() != null ) { 
					break;
				}

			} while(true);

			do {
				System.out.print("▷이메일 변경[변경하지 않으려면 그냥 엔터하세요] : "); 
				String email = sc.nextLine();

				if(email != null && email.trim().isEmpty()) {
					email = original_email; 
				}

				member.setEmail(email);

				if( member.getEmail() != null ) { 
					break;
				}

			} while(true);

			int result = mdao.changeInfo(member, sc);

			if(result == 1) {
				System.out.println("\n>>"+member.getName() + " 님의 변경된 정보입니다!! << \n");
				System.out.println(member.viewInfo());
			}
			else if(result == -1) {
				System.out.println(">> SQL 오류로 인하여 정보를 변경 전으로 초기화했습니다!! <<");
				System.out.println(member.viewInfo());
			}



		}// end of private void infoMenu(Scanner sc, MemberDTO member)-------------------------


		// 도서검색
		private void searchBook(Scanner sc) {
			String menuNo = "";

			do {
				System.out.println("\n-------------------도서 검색메뉴------------------\n");
				System.out.println("1. 책 이름 검색            2. 저자 검색             3. 장르 검색             4. 뒤로가기   \n");
				System.out.print("▷ 메뉴번호 선택 : ");

				menuNo = sc.nextLine();


				switch (menuNo) {
				case "1": // 책 이름 검색

					System.out.print("▷ 검색하실 책 제목을 입력해주세요 : ");
					String title = sc.nextLine();

					// 제목 검색
					List<LibDTO> titleList = libdao.searchTitle(title);

					if(titleList.size() > 0) {
						System.out.println("\n-------------------- [제목 검색결과] ---------------------------------");
						System.out.println("ISBN\t\t소분류코드\t책제목\t\t글쓴이\t출판사\t가격");
						System.out.println("\n-------------------------------------------------------------------");

						StringBuilder sb = new StringBuilder();

						for(LibDTO libdto : titleList) {

							sb.append(libdto.viewInfo()+"\n");
						}// end of for---------------------

						System.out.println(sb.toString());
					}
					else {
						System.out.println(">> 보유 도서중에서 "+ title +" 라는 제목의 책은 없습니다!! <<\n");
					}

					break;

				case "2": // 저자 검색

					System.out.print("▷ 검색하실 저자를 입력하세요 : ");
					String writer = sc.nextLine();

					// 저자 검색
					List<LibDTO> writerList = libdao.searchWriter(writer);

					if(writerList.size() > 0) {
						System.out.println("\n-------------------- [저자 검색결과] ---------------------------------");
						System.out.println("ISBN\t\t소분류코드\t책제목\t\t글쓴이\t출판사\t가격");
						System.out.println("\n-------------------------------------------------------------------");

						StringBuilder sb = new StringBuilder();

						for(LibDTO libdto : writerList) {

							sb.append(libdto.viewInfo()+"\n");
						}// end of for---------------------

						System.out.println(sb.toString());
					}
					else {
						System.out.println(">> 보유 도서중에서 "+ writer +" 라는 저자는 없습니다!! <<\n");
					}

					break;

				case "3": // 중분류 검색

					List<String> genreCodeList = libdao.showGenre(); // 무슨 중분류가 있는지 먼저 쏴줍니다.

					String genre = "";

					do {
						System.out.print("▷ 장르를 선택해주세요 : ");
						genre = sc.nextLine();

						boolean checkFlag = false;

						for(String genreCode : genreCodeList) {

							if(genreCode.equalsIgnoreCase(genre)) { // 장르를 선택했는데 목록에 있는 걸 골랐다면 탈출, 없는 걸 골랐다면 무한반복
								checkFlag = true;
							}

						} // end of for------------------------------------------------

						if(checkFlag) {
							break;
						}
						else {
							System.out.println(">> 장르 목록에 없는 장르코드입니다. 목록을 보고 다시 선택해주세요!! <<\n");
						}

					} while(true);
					//end of do~while-------------------------------------------

					List<LibDTO> genreList = libdao.searchGenre(genre); // 보고 고르게 합니다.

					if(genreList.size() > 0) {
						System.out.println("\n-------------------- [장르 검색결과] ---------------------------------");
						System.out.println("ISBN\t\t소분류코드\t책제목\t\t글쓴이\t출판사\t가격");
						System.out.println("\n-------------------------------------------------------------------");

						StringBuilder sb = new StringBuilder();

						for(LibDTO libdto : genreList) {

							sb.append(libdto.viewInfo()+"\n");

						}// end of for---------------------

						System.out.println(sb.toString());
					}
					else {
						System.out.println(">> 아직 "+ genre +" 에는 책이 입고되지 않았습니다. 관리자에게 문의해주세요!! <<\n");
					}


					break;


				case "4": // 뒤로가기

					break;


				default:
					System.out.println(">> 메뉴에 없는 번호입니다. 다시 선택해주세요!! << \n");
					break;
				}
				// end of switch -----------------------------------------------


			} while( !("4".equals(menuNo)) );
			// end of do~while--------------------------------------------------



		}// end of private void searchBook(Scanner sc)--------------------------


		// 도서 대여메뉴
		private void lendMenu(MemberDTO member, Scanner sc) {

			String menuNo = "";

			do {
				System.out.println("\n-------------------도서 대여메뉴------------------\n");
				System.out.println("1. 보유도서보기      2. 대여하기             3. 뒤로가기   \n");
				System.out.print("▷ 메뉴번호 선택 : ");
				menuNo = sc.nextLine();

				switch (menuNo) {
				case "1": // 보유도서보기
					bookList();
					break;

				case "2": // 대여하기
					lendBook(member, sc);
					break;

				case "3": // 뒤로가기

					break;

				default:
					System.out.println(">> 메뉴에 없는 번호입니다. 다시 선택하세요!! <<\n");
					break;
				}
				// end of switch----------------------------------------------------------------------
			}while( !("3".equals(menuNo)) );


		}// end of private void lendMenu(MemberDTO member, Scanner sc)----------------------------------------------
		
		
// 여기 변경!!!!!
		
		
		// 도서대여하기
		private void lendBook(MemberDTO member, Scanner sc) {
			
			int seq = 0;
			int n = 0;

			
				outer:
				do {
					
					System.out.print("▷ ISBN을 입력해주세요 : ");
					String isbn = sc.nextLine();
			
					LibDTO libdto = libdao.lendBookSearch(isbn, sc);
					
					
					if(libdto != null && "0".equals(libdto.getStatus()) ) { // ISBN을 있는 것을 입력했다면
						
						System.out.println("========================[대여신청하신 책입니다.]====================================================================");
						System.out.println("ISBN\t소분류코드\t책제목\t글쓴이\t출판사\t가격\t대여상태");
						System.out.println(libdto.viewInfo2());
						System.out.println("=============================================================================================================== \n");		
			
						if(seq == 0){ // 한 사람이 처음으로 대여 신청을 하는거면
							seq =lenddao.chaebun(); // 채번 메소드
							n = lenddao.insertLend(member, seq); // 대여테이블 insert / 성공하면 1
							lenddao.lendhistory_insert(member, seq);
						}
						
						if(n==1) {
							n = lenddao.insertLendDetail(isbn, seq); // 대여상세 insert / 성공하면 1
							lenddao.lenddetailhistory_insert(isbn,seq);
						}
						
						if(n==1) {
							Map<String, String> paraMap = new HashMap<>();
							paraMap.put("isbn", isbn);
							
			
							n = libdao.updateLendBook(paraMap); // 도서상세 status update / 성공하면 1
						}
						
						/*
							 n = -1 ==> 대여 테이블 insert 오류
							 n = -2 ==> 대여상세 테이블 insert 오류
							 n = -3 ==> 도서상세 테이블 update 오류
						*/
						
						if(n==1) {
							System.out.println(" 모두 성공 --> 대여신청완료 ");
						}
						else if(n==-1) {
							System.out.println("대여 테이블 insert 오류");
						}
						else if(n==-2) {
							System.out.println("대여상세 테이블 insert 오류");
						}
						else if(n==-3) {
							System.out.println("도서상세 테이블 update 오류");
						}
						
						String yn = "";
						
						do {
							
							System.out.print(" ");
							System.out.print("▷ 또 빌리실건가요?[Y/N] :  ");
							System.out.print(" ");
							
							yn = sc.nextLine();
							
							if("y".equalsIgnoreCase(yn)) {
								n = 1; // 다시 빌린다고 하면 1번째 insert를 돌지 않기에 임의로 1을 줍니다.
								break;
							}
							else if("n".equalsIgnoreCase(yn)) {
								break outer;
							}
							else {
								System.out.println(">> Y 또는 N 만 입력해야 합니다!! <<\n");
							}
						} while(!("y".equalsIgnoreCase(yn)) || !("n".equalsIgnoreCase(yn)));
						// end of do~while--------------------------------------------
						
					}
					else if(libdto == null) { // ISBN이 없는 것
						System.out.println(">> 보유중인 책 목록에 없는 ISBN입니다. 다시 확인하고 입력해주세요!! <<\n");
					}
					
					else if("1".equals(libdto.getStatus())) {
						System.out.println(">> 현재 대여중인 책이여서 대여가 불가능합니다!! <<\n");
						
					}
				} while(true); // outer do~while--------------------------------------------

		}// end of private void lendBook(Scanner sc)----------------------------------------

	

	// **** 도서 정보 변경(수정) **** //
	private int updateLib(MemberDTO member, Scanner sc) {

		int result = 0;

		System.out.println("\n>>> 도서 정보 변경하기 <<<");

		System.out.print("▷ 변경할 도서의 ISBN : "); 
		String isbn = sc.nextLine();

		Map<String, String> paraMap = new HashMap<>();
		paraMap.put("isbn", isbn);

		LibDTO libdto = libdao.viewContents(paraMap);
		// 현재 paraMap 에는 "isbn" 만 있는 상태! 

		if(libdto != null) {
			// 수정할 isbn이 존재하는 경우 


			// 변경할 도서 정보를 보여주고 변경 작업하기!
			System.out.println("------------------------------------------------");
			System.out.println("ISBN : " + libdto.getIsbn());
			System.out.println("소분류코드 : " + libdto.getFk_sub_code());
			System.out.println("책이름 : " + libdto.getBookname());
			System.out.println("글쓴이 : " + libdto.getWriter());
			System.out.println("출판사 : " + libdto.getPublisher());
			System.out.println("가격 : " + libdto.getPrice());
			System.out.println("------------------------------------------------\n");


			System.out.print("▷  소분류코드[변경하지 않으려면 엔터]: ");
			String fk_sub_code = sc.nextLine();
			if( fk_sub_code != null && fk_sub_code.trim().isEmpty() ) {
				fk_sub_code = libdto.getFk_sub_code();
			}

			System.out.print("▷ 책이름[변경하지 않으려면 엔터]: ");
			String bookname = sc.nextLine();
			if( bookname != null && bookname.trim().isEmpty() ) {
				bookname = libdto.getBookname();
			}

			System.out.print("▷ 글쓴이[변경하지 않으려면 엔터]: ");
			String writer = sc.nextLine();
			if( writer != null && writer.trim().isEmpty() ) {
				writer = libdto.getWriter();
			}

			System.out.print("▷ 출판사[변경하지 않으려면 엔터]: ");
			String publisher = sc.nextLine();
			if( publisher != null && publisher.trim().isEmpty() ) {
				publisher = libdto.getPublisher();
			}

			System.out.print("▷ 가격[변경하지 않으려면 엔터]: ");
			String price = sc.nextLine();
			if( price != null && price.trim().isEmpty() ) {
				price = libdto.getPrice();
			}

			do {
				System.out.print("\n▷ 정말로 수정하시겠습니까?[Y/N]: ");
				String yn = sc.nextLine();

				if("y".equalsIgnoreCase(yn)) {
					// DB에 업데이트 되도록 메소드 호출하기 

					paraMap.put("fk_sub_code", fk_sub_code);
					paraMap.put("bookname", bookname);
					paraMap.put("writer", writer);
					paraMap.put("publisher", publisher);
					paraMap.put("price", price);

					// 이제 paraMap에는 6가지 다 들어감!

					int n = libdao.updateLib(paraMap); // 도서 정보 변경하기

					if(n==1) {
						// 도서 변경이 성공한 경우
						result = 1;
					}
					else {
						// 장애발생으로 인한 도서 변경을 실패한 경우
						result = 2;
					}
					break;
				}

				else if("n".equalsIgnoreCase(yn)) {
					// 도서 변경을 취소한 경우
					result = 3;
					break;
				}

				else {
					System.out.println(">> Y 또는 N 만 입력하세요!! << ");
				}

			} while(true);

		}

		return result;
		/*
	             result == 0   검색하신 ISBN 코드는 존재하지 않습니다.  
	             result == 1   도서 변경 성공!!  
	             result == 2   장애발생으로 인해 도서 변경 실패!!  
	             result == 3   도서 변경을 취소하였습니다.  
		 */

	}// end of private int updateBoard(MemberDTO member, Scanner sc)-----------------------------


	// *** 도서 삭제하기 *** //
	private int deleteLib(MemberDTO member, Scanner sc) {

		int result = 0;

		System.out.println("\n>>> 도서 삭제 하기 <<<");

		System.out.print("▷ 삭제할 도서의 ISBN : "); 
		String isbn = sc.nextLine();

		Map<String, String> paraMap = new HashMap<>();
		paraMap.put("isbn", isbn);

		LibDTO libdto = libdao.viewContents(paraMap); 
		// 현재 paraMap 에는 "isbn" 만 있는 상태!

		if(libdto != null) {
			// 삭제할 ISBN이 존재하는 경우 

			// 변경할 도서 정보를 보여주고 변경 작업하기!
			System.out.println("------------------------------------------------");
			System.out.println("ISBN : " + libdto.getIsbn());
			System.out.println("소분류코드 : " + libdto.getFk_sub_code());
			System.out.println("책이름 : " + libdto.getBookname());
			System.out.println("글쓴이 : " + libdto.getWriter());
			System.out.println("출판사 : " + libdto.getPublisher());
			System.out.println("가격 : " + libdto.getPrice());
			System.out.println("------------------------------------------------\n");


			do {
				System.out.print("\n▷ 정말로 삭제하시겠습니까?[Y/N]: ");
				String yn = sc.nextLine();

				if("y".equalsIgnoreCase(yn)) {
					// DB에서  삭제되도록 메소드 호출하기 

					int n = libdao.deleteLib(paraMap); // 글 삭제하기

					if(n==1) {
						// 글 삭제가 성공한 경우
						result = 1;
					}
					else {
						// 장애발생으로 인한 글 삭제 실패한 경우
						result = 2;
					}
					break;
				}

				else if("n".equalsIgnoreCase(yn)) {
					// 글 삭제를 취소한 경우
					result = 3;
					break;
				}

				else {
					System.out.println(">> Y 또는 N 만 입력하세요!! << ");
				}

			} while(true);

		}


		return result;
		/*
	             result == 0   검색하신 ISBN 코드는 존재하지 않습니다.  
	             result == 1   도서 삭제 성공!!  
	             result == 2   장애발생으로 인해 도서 삭제 실패!!  
	             result == 3   도서 삭제를 취소하였습니다.  
		 */
	}

	
	
	
	 // 도서 반납하기
	   private void returnMenu(MemberDTO member, Scanner sc) {

	      lenddao.searchUser(member); // 먼저 로그인한 회원의 대여목록을 출력

	      int n = 1; // 트랜잭션용


	      outer:
	         do {

	            YeoncheDTO ycdto = null;

	            System.out.print("▷ 반납하실 책의 ISBN을 입력해주세요 : ");
	            String isbn = sc.nextLine();

	            LendDTO lenddto = lenddao.searchLendCode(isbn); // ISBN넣어서 대여번호가 몇인지 확인

	            if(lenddto != null) { // 대여목록에 있는 ISBN을 입력했다면

	               /////////////////////////// 연체 확인용 /////////////////////////////////////////////
	               int check = lenddao.checkYeonche(isbn); // 사용자가 반납하려는 책이 연체된건지 확인
	               // 0이면 연체된 책, 1이면 연체가 아닌 책


	               if(check == 0) { // 연체된거면 연체테이블에 넣을 정보들을 가져온다.
	                  ycdto = lenddao.getToYeonche(isbn);  // select 

	                  if(ycdto != null) { // 제대로 가져왔으면 연체테이블에 넣는다.
	                     n *= lenddao.goToYeonche(ycdto); // insert

	                     if(n == 1) {
	                        System.out.println(member.getName()+"님은 반납일을 넘기셨기 때문에 연체되셨습니다. \n");
	                     }
	                  }

	               }
	               /////////////////////////// 연체 확인용 /////////////////////////////////////////////


	               int cnt = lenddao.searchLendCnt(lenddto.getLendcode()); // 그 대여번호에 묶인 책들이 몇 권인지 가져온다.

	               n *= lenddao.deleteLendDetail(isbn); 
	               // 대여상세에서 ISBN으로 데이터를 찾아서 삭제한다.
	               // 성공시 1을 반환
	               
	               
	               System.out.println(member.getName()+" 님이  "+lenddto.getLenddate()+" 까지 반납해야할 책은 "+(cnt-1)+" 개 남았습니다!! \n"); 



	               if(lenddto != null && cnt == 1) { // 위에서 대여상세를 삭제했는데 갯수가 0개가 되면 대여테이블도 삭제한다. 
	               //CNT==1인 것은 위의 대여상세 삭제가 작동하기 전의 값이다. 그래서 위의 deleteLendDetail이 돌면 0이되니깐 아래의 식을 구동시킨다.
	                  
	                  n *= lenddao.deleteLend(lenddto.getLendcode());
	               }

	               Map<String, String> paraMap = new HashMap<>();
	               paraMap.put("isbn", isbn);
	               paraMap.put("status", "0");


	               /// ================ status 업데이트하는거 넣어야 합니다 ============================ //
	               paraMap = new HashMap<>();
	               paraMap.put("isbn", isbn);

	               n *= libdao.updateLendBook2(paraMap); // 반납하려고 입력한 ISBN의 책을 반납이 완료됐으니 STATUS를 0(도서관에 보유중)으로 바꾼다.

	               if(n == 1) {
	                  System.out.println("\n>> 모든 DML문이 정상적으로 작동됐습니다. <<\n");
	               }


	               String yn ="";

	               do {
	                  System.out.print(" ");
	                  System.out.print("▷ 또 반납 하실건가요?[Y/N] :  ");
	                  System.out.print(" ");

	                  yn = sc.nextLine();

	                  if("y".equalsIgnoreCase(yn)) {
	                     break;
	                  }
	                  else if("n".equalsIgnoreCase(yn)) {
	                     break outer;
	                  }
	                  else {
	                     System.out.println(">> Y 또는 N 만 입력해야 합니다!! <<\n");
	                  }
	               } while(true);
	               // end of do~while--------------------------------------------

	            } 

	            else {
	               System.out.println("대여목록에 없는 ISBN입니다. 다시 확인하고 입력하세요!! \n");
	            }

	         } while(true);


	   }// end of private void returnMenu(MemberDTO member, Scanner sc)------------------------------
	
	
	
	
	// 전체 멤버 조회(관리자 메뉴)
	private void showAllMember() {
		
		List<MemberDTO> mbrList = mdao.showAllMember();

		if(mbrList.size() > 0) {

			System.out.println("\n------------------------------------ [전체회원목록] ------------------------------------");
			System.out.println("아이디\t이름\t생년월일\t\t\t연락처\t\t주소\t\t이메일");
			System.out.println("\n-------------------------------------------------------------------------------------");

			StringBuilder sb = new StringBuilder();

			for(MemberDTO mdto : mbrList ) {

				sb.append(mdto.getUserid() + "\t" +
						  mdto.getName() + "\t" +
						  mdto.getBirthdate() + "\t" +
						  mdto.getMobile() + "\t" +
						  mdto.getAddress() + "\t" +
						  mdto.getEmail() + "\n"
						);

			}// end of for---------------------------------

			System.out.println(sb.toString());
		}

		else {
			System.out.println(">> 회원이 아무도 없습니다. << \n");
		}
		
	}
	
	
	
	
	private void showYeoncheMember() {
		
		List<YeoncheDTO> yList = mdao.showAllYeonche();

		if(yList.size() > 0) {

			System.out.println("\n-------------------------- [연체회원목록] --------------------------");
			System.out.println("아이디\t이름\t연체일\t\t\t연체료");
			System.out.println("\n-----------------------------------------------------------------");

			StringBuilder sb = new StringBuilder();

			for(YeoncheDTO ydto : yList ) {

				sb.append(ydto.getFk_userid() + "\t" +
						  ydto.getName() + "\t" +
						  ydto.getYc_date() + "\t" +
						  ydto.getYc_fee() + "\n"
						);

			}// end of for---------------------------------

			System.out.println(sb.toString());
		}

		else {
			System.out.println(">> 연체된 회원이 아무도 없습니다. << \n");
		}
		
	}
	
	
	
	// 나의 대여 현황
	private void myLendBook(MemberDTO member) {
		
		System.out.println("\n------------------------------------ [나의 대여 현황] ------------------------------------");
		System.out.println("대여번호\t아이디\tISBN\t책제목\t대여일\t\t반납일");
		System.out.println("\n-------------------------------------------------------------------------------------");

		List<Map<String, String>> resultList = libdao.showMyLend(member);
		
		if(resultList.size() > 0) {
			
			StringBuilder sb = new StringBuilder();
			
			for(Map<String, String> map : resultList) {
				sb.append(map.get("lend_code") + "\t" +
						  map.get("userid") + "\t" +
						  map.get("isbn") + "\t" +
						  map.get("bookname") + "\t" +
						  map.get("lend_date") + "\t" +
						  map.get("return_date") + "\n");
			} // end of for------------------------------
			
			System.out.println(sb.toString());
		}
		else {
			System.out.println("\n>> 대여중인 책이 없습니다. <<");
		}
	
		
	
	} // end of private void myLendBook(MemberDTO member)-------------------------------------
	
	
	
	//회원 탈퇴
	   private MemberDTO memberDelete(MemberDTO member, Scanner sc) {
	      
	      int lend_result = 0;
	      int y_result = 0;
	      
	      do {
	      System.out.print("정말 탈퇴하시겠습니까?[Y/N]");
	      String yn = sc.nextLine();
	      
	      if("y".equalsIgnoreCase(yn)) {
	         

	         
	         List<Map<String, String>> memberLendList = mdao.memberLendCheck(member); // 탈퇴하기전 대여가 있는지 확인 메소드
	         
	         
	         
	         if(memberLendList.size()>0) {
	            
	            System.out.println("--------------------------------------------------------------------------------");
	            System.out.println("대여번호        회원아이디            ISBN      반납예정일자       도서명                저자명             출판사        가격 ");
	            System.out.println("--------------------------------------------------------------------------------\n");
	            
	            StringBuilder sb = new StringBuilder();
	            
	            for(Map<String, String> map : memberLendList){
	               
	               sb.append(map.get("A.lend_code")+"\t"+map.get("A.fk_user_id")+"\t"+map.get("B.fk_isbn")+"\t"+map.get("B.return_date")+"\t"+ map.get("bookname")
	               +"\t"+map.get("writer")+"\t"+map.get("publisher")+"\t"+map.get("price")+"\n");
	            }
	            
	            System.out.println(sb.toString());
	            
	            System.out.println("");
	         }
	         else {
	            lend_result = 1;
	            
	            
	            
	         }
	         
	         List<Map<String,String>> memberYlist = mdao.memberYCheck(member); // 탈퇴하기전 연체 있는지 확인 메소드
	         
	         
	            if( memberYlist.size()>0) {
	            
	            System.out.println("--------------------------------------------------------------------------------");
	            System.out.println(" 연체 번호      연체기간        연체료          대여번호        회원아이디        회원명          휴대폰번호         이메일");
	            System.out.println("--------------------------------------------------------------------------------\n");
	            
	            StringBuilder sb = new StringBuilder();
	            
	            for(Map<String, String> map : memberYlist){
	               
	               sb.append(map.get("yc_code")+"\t"+map.get("yc_date")+"\t"+map.get("yc_fee")+"\t"+map.get("fk_lend_d_code")+"\t"+ map.get("M.userid")
	               +"\t"+map.get("name")+"\t"+map.get("mobile")+"\t"+map.get("email")+"\n");
	            }
	            
	            System.out.println(sb.toString());
	            System.out.println(" >>>>>>>      돈 갚아 이새끼야");
	            
	         }
	         else {
	            y_result = 1;
	            // 
	            
	            
	         }
	         
	         
	         // 대여와 연체가 둘다 없다면 아이디 삭제!!!!
	            if(lend_result == 1 && y_result == 1) {
	               System.out.println(">>> 회원 탈퇴 중...");
	               
	          int n = mdao.memberDelete(member); // 삭제 메소드 실행
	         
	               if(n==0) {
	                  System.out.println(" >>>>  삭제할 아이디가 존재하지 않습니다!!");
	               }
	               else if(n==2) {
	                  System.out.println(">>> 장애 발생으로 회원 탈퇴 실패!!!!");
	               }
	               else if(n==1) {
	               System.out.println(">>> 정상적으로 회원 탈퇴되었습니다. ");
	          //   member.setName(null);
	               member = null;
	               }
	         
	            }
	            else if(lend_result !=1 && y_result ==1) {
	               
	               System.out.println(">>> 현재 대여중인 도서가 있습니다. 모두 반납하고 다시 탈퇴신청 하세요!!!!!\n");
	            }
	            else if(lend_result ==1 && y_result !=1) {
	               System.out.println(" >>> 현재 연체내역이 있습니다. 연체료를 완납하고 다시 탈퇴신청 하세요!!!!!\n");
	            }
	            else {
	               System.out.println(" >>>현재 대여중인 도서와 연체내역이 있습니다.   대여도서는 모두 반납하고 연체료는 완납하고 다시 탈퇴신청하세요!!!!\n");
	            }
	         
	         
	         break;
	      }
	      else if("n".equalsIgnoreCase(yn)) {
	         System.out.println(">> 회원 탈퇴 취소!!");
	         break;
	      }
	      else {
	         System.out.println(">>Y나 N 만 입력가능합니다!!");
	      }
	      }while(true);
	      
	      return member;
	      
	   }//end of private void memberDelete(MemberDTO member, Scanner sc) 
	
	

}