package jdbc.project.mini;

public class LendDTO {

      private int lendcode;            	// 대여번호(PK)
      private String fk_userid;      	// 회원번호(FK)
      private String lenddate;      	// 대출일자
      
	public int getLendcode() {
		return lendcode;
	}
	
	public void setLendcode(int lendcode) {
		this.lendcode = lendcode;
	}
	
	public String getFk_userid() {
		return fk_userid;
	}
	
	public void setFk_userid(String fk_userid) {
		this.fk_userid = fk_userid;
	}
	
	public String getLenddate() {
		return lenddate;
	}
	
	public void setLenddate(String lenddate) {
		this.lenddate = lenddate;
	}
	
	
	//////////////////////////////////////////////////
	
	// 대여 도서 조회
	public String viewInfo() {
		return lendcode+"\t"+fk_userid+"\t"+lenddate;
	}
     
      
     
      
   
      
      
      

   
}