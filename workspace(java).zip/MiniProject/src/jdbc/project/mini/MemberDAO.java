package jdbc.project.mini;

import java.sql.*;
import java.util.*;

import jdbc.project.connection.ProjectDBConnection;

public class MemberDAO implements InterMemberDAO {

	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;
	
	// === 자원반납 메소드 === //
	private void close() {
		try {
			if( rs != null )    rs.close();
			if( pstmt != null ) pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}// end of private void close()---------------------------
	


	// *** 멤버 회원가입(insert) 메소드 *** //
	@Override
	public int memberRegister(MemberDTO member, Scanner sc) {

		int result = 0;
		conn = ProjectDBConnection.getConn();

		String sql = " insert into tbl_member(userid, passwd, name, birthdate, mobile, address, email) "+
				" values(?, ?, ?, ?, ?, ?, ?) ";

		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, member.getUserid());
			pstmt.setString(2, member.getPasswd());
			pstmt.setString(3, member.getName());
			pstmt.setString(4, member.getBirthdate());
			pstmt.setString(5, member.getMobile());
			pstmt.setString(6, member.getAddress());
			pstmt.setString(7, member.getEmail());

			result = pstmt.executeUpdate();

			if(result == 1) {

				do {
					System.out.print(">> 정말 입력하시겠습니까?[Y/N] : ");
					String yn = sc.nextLine();

					if("y".equalsIgnoreCase(yn)) {
						conn.commit();
						System.out.println(">> 회원가입 성공!! <<\n");
						break;
					}
					else if("n".equalsIgnoreCase(yn)) {
						conn.rollback();
						System.out.println(">> 회원가입 취소되었습니다.!! <<\n");
						result = 0;
						break;
					}
					else {
						System.out.println(">> Y 또는 N 만 입력하세요!! << \n");
					}
				} while(true);


			}

		} catch (SQLException e) {

			if(e.getErrorCode() == 1) {
				System.out.println(">> 아이디가 중복되었습니다!! 다른 아이디를 입력해주세요!! << \n");
				result = -1;
			}
			else if(e.getErrorCode() == 1841) {
				System.out.println(">> 생년월일은 반드시 8글자 형태로 입력하셔야 합니다!! <<");
			}

			else {
				System.out.println(">> SQL구문 오류입니다!! <<");
				e.printStackTrace();
				result = -2;
			}
		} finally {
			close();
		}





		return result;
	}// end of public int memberRegister(MemberDTO member, Scanner sc) ------------


	// *** 관리자 회원가입(insert) 메소드 *** //
	   @Override
	   public int adminRegister(MemberDTO member, Scanner sc) {
	      
	      int result = 0;
	      
	      try {
	         conn = ProjectDBConnection.getConn();
	         
	         String sql = " insert into tbl_admin(adminid, passwd, admin_name) "+
	                    " values(?, ?, ?) ";
	      
	         pstmt = conn.prepareStatement(sql);
	         pstmt.setString(1, member.getAdminid());
	         pstmt.setString(2, member.getPasswd());
	         pstmt.setString(3, member.getName());
	      
	         result = pstmt.executeUpdate();
	         
	         if(result == 1) {
	            
	            String yn = "";
	            do {
	               System.out.print(">> 회원가입을 정말로 하시겠습니까?[Y/N] : ");
	               yn = sc.nextLine();
	               
	               if("y".equalsIgnoreCase(yn)) {
	                  conn.commit(); // 커밋
	               }
	               else if("n".equalsIgnoreCase(yn)) {
	                  conn.rollback(); // 롤백
	                  result = 0;
	               }
	               else {
	                  System.out.println(">>> Y 또는 N 만 입력하세요!! \n");
	               }
	            } while(!("y".equalsIgnoreCase(yn) || "n".equalsIgnoreCase(yn))); // end of do~while-----------------------
	            
	         } // end of if(result == 1)----------------------------------
	         
	      } catch(SQLIntegrityConstraintViolationException e) { // 오라클의 제약조건에 위배가 된 경우 발생!
	         if(e.getErrorCode() == 1) // unique 한 것에 위배된 경우
	            result = -1;
	      } catch(SQLException e) {
	         result = -2;
	      }
	      
	      return result;
	   } // end of public int adminRegister(MemberDTO member, Scanner sc)-----------
	
	
	
	
	
	
	

	// *** 관리자 로그인 메소드 *** //
	   @Override
	   public MemberDTO login(Map<String, String> paraMap) {
	      
	      MemberDTO member = null;
	      
	      try {
	         
	         conn = ProjectDBConnection.getConn();
	         
	         String sql = " select adminid, passwd, admin_name "+
	                   " from tbl_admin "+
	                   " where adminid = ? and passwd = ?";
	         
	         pstmt = conn.prepareStatement(sql);
	         pstmt.setString(1, paraMap.get("adminid"));
	         pstmt.setString(2, paraMap.get("passwd"));
	         
	         rs = pstmt.executeQuery();
	         
	         if(rs.next()) {
	            member = new MemberDTO();
	            
	            member.setAdminid(rs.getString(1));
	            member.setPasswd(rs.getString(2));
	            member.setName(rs.getString(3));
	            
	         }
	         
	      } catch(SQLException e) {
	         System.out.println(">> SQL구문 오류!! <<");
	         e.printStackTrace();
	      } finally {
	         close();
	      }
	      
	      return member;
	   } // end of public MemberDTO login(Map<String, String> paraMap)---------------------


	// *** 회원 로그인 메소드 *** //
	@Override
	public MemberDTO memberLogin(Map<String, String> paraMap) {
		
		MemberDTO member = null;

		try {

			conn = ProjectDBConnection.getConn();

			String sql = " select userid, passwd, name, mobile, address, email "+
					" from tbl_member "+
					" where userid = ? and passwd = ?";

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, paraMap.get("userid"));
			pstmt.setString(2, paraMap.get("passwd"));

			rs = pstmt.executeQuery();

			if(rs.next()) {
				member = new MemberDTO();

				member.setUserid(rs.getString(1));
				member.setPasswd(rs.getString(2));
				member.setName(rs.getString(3));
				member.setMobile(rs.getString(4));
				member.setAddress(rs.getString(5));
				member.setEmail(rs.getString(6));

			}
			
			else {
				System.out.println(">> 조회된 회원이 없습니다!! << \n");
			}

		} catch(SQLException e) {
			System.out.println(">> SQL구문 오류!! <<");
			e.printStackTrace();
		}  finally {
			close();
		}
		return member;
	}// end of public MemberDTO memberLogin(Map<String, String> paraMap-----------------------------------------
	
	
	// 정보 수정하기
		@Override
		public int changeInfo(MemberDTO member, Scanner sc) {
			
			int result = 0;
			
			
			try {
				conn = ProjectDBConnection.getConn();
				
				String sql = " update tbl_member set passwd = ?, name = ?, mobile = ?, address = ?, email = ? "+
						     " where userid = ? ";

				pstmt = conn.prepareStatement(sql);
				
				pstmt.setString(1, member.getPasswd());
				pstmt.setString(2, member.getName());
				pstmt.setString(3, member.getMobile());
				pstmt.setString(4, member.getAddress());
				pstmt.setString(5, member.getEmail());
				pstmt.setString(6, member.getUserid());
				
				result = pstmt.executeUpdate();
				
				if(result == 1) {
					
					do {
						System.out.print(">> 정말 변경하시겠습니까? [Y/N] : ");
						String yn = sc.nextLine();
						
						if("y".equalsIgnoreCase(yn)) {
							conn.commit();
							System.out.println(">> 회원정보 변경이 완료됐습니다!! << \n");
							break;
						}
						
						else if("n".equalsIgnoreCase(yn)) {
							conn.rollback();
							System.out.println(">> 회원정보 변경이 취소됐습니다!! << \n");
							result = 0;
							break;
						}
						else {
							System.out.println(">> Y 또는 N 만 입력해주세요!! <<");
						}
					} while(true);
					
				}
				
			} catch(SQLException e) {
				e.printStackTrace();
				result = -1;
			} finally {
				close();
			}

			return result;
			
		} // end of public int changeInfo(MemberDTO member, Scanner sc) ---------------------

	
	
	// 전체 회원 조회
	@Override
	public List<MemberDTO> showAllMember() {
		
		List<MemberDTO> mbrList = new ArrayList<>();



		conn = ProjectDBConnection.getConn();

		String sql = " select userid, name, birthdate, mobile, address, email "+
				     " from tbl_member ";

		try {

			pstmt = conn.prepareStatement(sql);

			rs = pstmt.executeQuery();

			while(rs.next()) {
				MemberDTO mbrdto = new MemberDTO();

				mbrdto.setUserid(rs.getString(1));
				mbrdto.setName(rs.getString(2));
				mbrdto.setBirthdate(rs.getString(3));
				mbrdto.setMobile(rs.getString(4));
				mbrdto.setAddress(rs.getString(5));
				mbrdto.setEmail(rs.getString(6));

				mbrList.add(mbrdto);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			close();
		}
		
		return mbrList;
	}

	
	// 연체 회원 조회
	@Override
	public List<YeoncheDTO> showAllYeonche() {
		
		List<YeoncheDTO> yList = new ArrayList<>();

		conn = ProjectDBConnection.getConn();

		String sql = " select y.fk_userid as userid, "+
					 "        name, "+
					 "        yc_date, "+
					 "        yc_fee "+
					 " from tbl_yeonche Y join tbl_member M "+
					 " on y.fk_userid = m.userid ";

		try {

			pstmt = conn.prepareStatement(sql);

			rs = pstmt.executeQuery();

			while(rs.next()) {
				YeoncheDTO ydto = new YeoncheDTO();

				ydto.setFk_userid(rs.getString(1));
				ydto.setName(rs.getString(2));
				ydto.setYc_date(rs.getString(3));
				ydto.setYc_fee(rs.getInt(4));
				

				yList.add(ydto);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			close();
		}
		
		return yList;
		
	}
	
	
	

 // 회원 탈퇴하기전 대여 있는지 확인 메소드
 @Override
 public List<Map<String, String>> memberLendCheck(MemberDTO member) {
    
    List<Map<String, String>> memberLendCheck = new ArrayList<>();
    
       try {
             
             conn = ProjectDBConnection.getConn();
             
             
             String sql = "     select A.lend_code, A.fk_user_id, B.fk_isbn, B.return_date, bookname, writer, publisher, price "+
             "   from tbl_lend A JOIN lend_detail B "+
             "   on A.lend_code = B.fk_lend_code "+
             "   JOIN tbl_lib C "+
             "   on B.fk_isbn = C.isbn "+
             "   where fk_user_id = ? ";
             
             pstmt = conn.prepareStatement(sql);
             pstmt.setString(1, member.getUserid());
             rs = pstmt.executeQuery();
             
             while(rs.next()) {
                
                Map<String, String> map = new HashMap<>();
                
                map.put("A.lend_code", String.valueOf(rs.getInt(1)));
                map.put("A.fk_user_id", rs.getString(2));
                map.put("B.fk_isbn",rs.getString(3));
                map.put("B.return_date", rs.getString(4));
                map.put("bookname", rs.getString(5));
                map.put("writer", rs.getString(6));
                map.put("publisher", rs.getString(7));
                map.put("price", rs.getString(8));

                memberLendCheck.add(map);
           
             }
             
          } catch(SQLException e) {
             System.out.println(">> SQL구문 오류!! <<");
             e.printStackTrace();
          } finally {
             close();
          }
    
    
    
    return memberLendCheck;
    
 }// end of public void memberLendCheck(MemberDTO member, LendDTO lenddto, YeoncheDTO ydto)-------------------
 
 
 
 
 //탈퇴하기전 연체있는지 확인 메소드
 @Override
 public List<Map<String, String>> memberYCheck(MemberDTO member) {
    
    List<Map<String, String>> memberYCheck = new ArrayList<>();
    
       try {
             
             conn = ProjectDBConnection.getConn();
             
             

             String sql = " select yc_code, yc_date, yc_fee, fk_lend_d_code, M.userid, name, mobile, email "+
                   " from TBL_YEONCHE Y JOIN tbl_member M "+
                   " on Y.fk_userid = M.userid "+
                   " where M.userid = ? ";
             
             
             pstmt = conn.prepareStatement(sql);
             pstmt.setString(1, member.getUserid());
             rs = pstmt.executeQuery();
             
             while(rs.next()) {
                
                Map<String, String> map = new HashMap<>();
                
                map.put("yc_code", rs.getString(1));
                map.put("yc_date", rs.getString(2));
                map.put("yc_fee",String.valueOf(rs.getString(3)));
                map.put("fk_lend_d_code", String.valueOf(rs.getString(4)));
                map.put("M.userid", rs.getString(5));
                map.put("name", rs.getString(6));
                map.put("mobile", rs.getString(7));
                map.put("email", rs.getString(8));

                memberYCheck.add(map);
           
             }
             
          } catch(SQLException e) {
             System.out.println(">> SQL구문 오류!! <<");
             e.printStackTrace();
          } finally {
             close();
          }
    
    
    return memberYCheck;
    
    
 } // end of public List<Map<String, String>> memberYCheck(MemberDTO member)--------------------------
	
	

 // 회원 아이디 삭제
 @Override
 public int memberDelete(MemberDTO member) {
    
    int result = 0;
    
       try {
             
             conn = ProjectDBConnection.getConn();
             

           String sql = " delete from tbl_member "+
                      " where userid = ? ";
             pstmt = conn.prepareStatement(sql);
             pstmt.setString(1, member.getUserid());

             
             result = pstmt.executeUpdate();
             conn.commit();

             
          } catch(SQLException e) {
             System.out.println(">> SQL구문 오류!! <<");
             result = 2;
             e.printStackTrace();
          } finally {
             close();
          }
          
    
    
    
    
    return result;
 }// end of public int memberDelete(MemberDTO member) 
 




}
