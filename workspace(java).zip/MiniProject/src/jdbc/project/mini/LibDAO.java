package jdbc.project.mini;

import java.sql.*;
import java.util.*;

import jdbc.project.connection.ProjectDBConnection;

public class LibDAO implements InterLibDAO {

	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;

	// === 자원반납 메소드 === //
	private void close() {
		try {
			if( rs != null )    rs.close();
			if( pstmt != null ) pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}// end of private void close()---------------------------



	@Override
	// 전체도서조회하기
	public List<LibDTO> bookList() {

		List<LibDTO> bookList = new ArrayList<>();



		conn = ProjectDBConnection.getConn();
		
		String sql = "select isbn, fk_sub_code, bookname, writer, publisher, price, status "+
				" from tbl_lib A JOIN ( "+
				" select fk_isbn, status "+
				" from tbl_book "+
				" ) B "+
				" on a.isbn = b.fk_isbn "
				+ " order by 1 asc ";

		try {

			pstmt = conn.prepareStatement(sql);

			rs = pstmt.executeQuery();

			while(rs.next()) {
				LibDTO libdto = new LibDTO();

				libdto.setIsbn(rs.getString(1));
				libdto.setFk_sub_code(rs.getString(2));
				libdto.setBookname(rs.getString(3));
				libdto.setWriter(rs.getString(4));
				libdto.setPublisher(rs.getString(5));
				libdto.setPrice(rs.getString(6));
				libdto.setStatus(rs.getString(7));

				bookList.add(libdto);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			close();
		}



		return bookList;
	}// end of public List<LibraryDTO> bookList()----------------------------


	// 도서등록 메소드 //
		@Override
		public int libRegister(LibDTO ldto, Scanner sc) {

			int result = 0;

			try {
				conn = ProjectDBConnection.getConn(); // getConn에서 받아와 여기 conn에 넣어준다.

				String sql = " insert into tbl_lib(isbn, bookname, writer, publisher, price, fk_sub_code) "+
						" values(?,?,?,?,?,?) ";

				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, ldto.getIsbn());
				pstmt.setString(2, ldto.getBookname());
				pstmt.setString(3, ldto.getWriter());
				pstmt.setString(4, ldto.getPublisher());
				pstmt.setString(5, ldto.getPrice());
				pstmt.setString(6, ldto.getFk_sub_code());


				result = pstmt.executeUpdate();



				if(result ==1 ) {
					String yn = "";

					do {
						System.out.print(">> 도서등록을 정말로 하시겠습니까?[Y/N] : ");
						yn = sc.nextLine();

						if("y".equalsIgnoreCase(yn)) {
							conn.commit();
						}
						else if("n".equalsIgnoreCase(yn)) {
							conn.rollback();
							result = 0; // 롤백했으므로 성공했다는 뜻인 1이 넘어가면 안되므로 0으로 해준다
						}
						else {
							System.out.println(">>> Y 또는 N 만 입력하세요!!\n");
						}
					} while( !("y".equalsIgnoreCase(yn) || "n".equalsIgnoreCase(yn) ) );
					//do_while문 ----------------------------------

				}//end of if(result == 1)-----------------------


			} catch(SQLIntegrityConstraintViolationException e) {
				if(e.getErrorCode() == 2291) { // 오라클의 제약조건에 위배가 된경우 발생함.
					result = -1; // -1 이라는  -1. ==>isbn이 중복되어 프라이머리 키 제약 위배하여 등록실패한 것임.(Unique 제약에 위배 된 것임) 이거에 대한 에러코드를 만들자.
				}

			} catch (SQLException e) {
				result = -2; // -2  ==> SQL구문에 오류발생한 것임.
			} finally{
				close();
			}


			return result;
		} // end of public int libRegister(LibDTO ldto, Scanner sc)-------------------------------
		
		
		
		   //도서 상세정보에 등록
		   @Override
		   public int libdetailRegister(LibDTO libdto) {
		      
		      int result = 0;
		      
		      try {
		         conn = ProjectDBConnection.getConn(); // getConn에서 받아와 여기 conn에 넣어준다.
		         
		         String sql = " insert into tbl_book(bookno, fk_isbn, status) "+
		                    " values(seq_tbl_book.nextval,?,0) ";
		         
		         pstmt = conn.prepareStatement(sql);
		         pstmt.setString(1, libdto.getIsbn());
		         
		         result = pstmt.executeUpdate();
		         
		         conn.commit();

		            
		            
		         
		            
		         
		      
		      } catch(SQLIntegrityConstraintViolationException e) {
		         if(e.getErrorCode() == 2291) { // 오라클의 제약조건에 위배가 된경우 발생함.
		            result = -1; // -1 이라는  -1. ==>isbn이 중복되어 프라이머리 키 제약 위배하여 등록실패한 것임.(Unique 제약에 위배 된 것임) 이거에 대한 에러코드를 만들자.
		         }
		         
		      } catch (SQLException e) {
		            result = -2; // -2  ==> SQL구문에 오류발생한 것임.
		      } finally{
		         close();
		      }

		      return result;
		      
		      
		      
		   }//   end of public int libdetailRegister(LibDTO libdto) 
		   
		   


		// 도서검색 - 제목검색(보유테이블)
		@Override
		public List<LibDTO> searchTitle(String title) {


			List<LibDTO> titleList = new ArrayList<>();

			try {

				conn = ProjectDBConnection.getConn();

				String sql = " select *  "+
						" from TBL_lib " + 
						" where bookname like '%'|| ? ||'%' ";

				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, title);

				rs = pstmt.executeQuery();


				while(rs.next()) {

					LibDTO libdto = new LibDTO();

					libdto.setIsbn(rs.getString(1));
					libdto.setFk_sub_code(rs.getString(2));
					libdto.setBookname(rs.getString(3));
					libdto.setWriter(rs.getString(4));
					libdto.setPublisher(rs.getString(5));
					libdto.setPrice(rs.getString(6));

					titleList.add(libdto);

				}

			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				close();
			}


			return titleList;

		}// end of 	public List<LibDTO> searchTitle(String title)---------------------

		// 저자 검색
		@Override
		public List<LibDTO> searchWriter(String writer) {

			List<LibDTO> writerList = new ArrayList<>();

			try {

				conn = ProjectDBConnection.getConn();

				String sql = " select *  "+
						" from TBL_lib " + 
						" where writer like '%'|| ? ||'%' ";

				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, writer);

				rs = pstmt.executeQuery();

				while(rs.next()) {

					LibDTO libdto = new LibDTO();

					libdto.setIsbn(rs.getString(1));
					libdto.setFk_sub_code(rs.getString(2));
					libdto.setBookname(rs.getString(3));
					libdto.setWriter(rs.getString(4));
					libdto.setPublisher(rs.getString(5));
					libdto.setPrice(rs.getString(6));

					writerList.add(libdto);

				}

			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				close();
			}

			return writerList;
		}


		// 장르 목록 가져오기
		@Override
		public List<String> showGenre() {

			List<String> genreCodeList = new ArrayList<>();

			try {

				conn = ProjectDBConnection.getConn();


				String sql = " select genre_code, case when fk_country_code=1 then '한국' else '외국' end AS country, genre_name "+
						" from tbl_genre ";


				pstmt = conn.prepareStatement(sql);

				rs = pstmt.executeQuery();

				StringBuilder sb = new StringBuilder();

				while(rs.next()) {
					String genre_code = rs.getString(1);
					genreCodeList.add(rs.getString(1));

					String country = rs.getString(2);
					String genre_name = rs.getString(3);

					sb.append(country + "\t" + genre_code + "\t" + genre_name + "\n");

				}
				System.out.println("==========[장르목록표]========== \n");
				System.out.println(sb.toString());
				System.out.println("==============================");

			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				close();
			}

			return genreCodeList;

		}// end of public void showGenre()

		// 장르 검색하기
		@Override
		public List<LibDTO> searchGenre(String genre) {

			List<LibDTO> genreList = new ArrayList<>();

			try {

				conn = ProjectDBConnection.getConn();

				String sql = " select * "+
						" from tbl_lib "+
						" where fk_sub_code like '%' || lower( ? ) || '%' ";


				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, genre);

				rs = pstmt.executeQuery();

				while(rs.next()) {

					LibDTO libdto = new LibDTO();

					libdto.setIsbn(rs.getString(1));
					libdto.setFk_sub_code(rs.getString(2));
					libdto.setBookname(rs.getString(3));
					libdto.setWriter(rs.getString(4));
					libdto.setPublisher(rs.getString(5));
					libdto.setPrice(rs.getString(6));

					genreList.add(libdto);

				}




			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				close();
			}

			return genreList;


		}// end of public void searchGenre(String genre)--------------------------

	// 도서 정보 보기
	@Override
	public LibDTO viewContents(Map<String, String> paraMap) {

		LibDTO libdto = null;

		try {
			conn = ProjectDBConnection.getConn(); // conn은 수동 commit으로 되어져 있다.

			String sql = " select * from tbl_lib "+
					" where isbn = ? ";

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, paraMap.get("isbn"));

			rs = pstmt.executeQuery();

			if(rs.next()) {

				libdto = new LibDTO();

				libdto.setIsbn(rs.getString(1));
				libdto.setFk_sub_code(rs.getString(2));
				libdto.setBookname(rs.getString(3));
				libdto.setWriter(rs.getString(4));
				libdto.setPublisher(rs.getString(5));
				libdto.setPrice(rs.getString(6));

			}

		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}

		return libdto;
	} // end of public LibDTO viewContents(Map<String, String> paraMap)----------------------



	// 도서 정보 변경하기
	@Override
	public int updateLib(Map<String, String> paraMap) {

		int result = 0;

		try {
			conn = ProjectDBConnection.getConn(); // conn은 수동 commit으로 되어져 있다.

			String sql = " update tbl_lib set fk_sub_code = ?, "
					+ " bookname = ?, writer = ?, "
					+ " publisher = ?, price = ? "
					+ " where isbn = ? ";

			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, paraMap.get("fk_sub_code"));
			pstmt.setString(2, paraMap.get("bookname"));
			pstmt.setString(3, paraMap.get("writer"));
			pstmt.setString(4, paraMap.get("publisher"));
			pstmt.setString(5, paraMap.get("price"));
			pstmt.setString(6, paraMap.get("isbn"));

			result = pstmt.executeUpdate();

			conn.commit();

		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}

		return result;
	} // end of public int updateLib(Map<String, String> paraMap)------------------------




	// 도서 정보 삭제하기
	@Override
	public int deleteLib(Map<String, String> paraMap) {

		int result = 0;

		try {
			conn = ProjectDBConnection.getConn(); // conn은 수동 commit으로 되어져 있다.

			String sql = " delete from tbl_lib "
					+    " where isbn = ? ";

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, paraMap.get("isbn"));

			result = pstmt.executeUpdate();

			if(result == 1) {
				conn.commit();
			}
			else {
				conn.rollback();
			}

		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}

		return result;
	} // end of public int deleteLib(Map<String, String> paraMap)----------------------------

	// 대여신청하는 책 유/무 확인
		@Override
		public LibDTO lendBookSearch(String isbn, Scanner sc) {

			conn = ProjectDBConnection.getConn();
			
			LibDTO libdto = null;
			
			String sql = "select isbn, fk_sub_code, bookname, writer, publisher, price, status "+
						" from tbl_lib A JOIN ( "+
						" select fk_isbn, status "+
						" from tbl_book "+
						" ) B "+
						" on a.isbn = b.fk_isbn "+
						" where isbn = ? ";

			try {

				pstmt = conn.prepareStatement(sql);
				
				pstmt.setString(1, isbn);

				rs = pstmt.executeQuery();

				while(rs.next()) {
					
					libdto = new LibDTO();
					libdto.setIsbn(rs.getString(1));
					libdto.setFk_sub_code(rs.getString(2));
					libdto.setBookname(rs.getString(3));
					libdto.setWriter(rs.getString(4));
					libdto.setPublisher(rs.getString(5));
					libdto.setPrice(rs.getString(6));
					libdto.setStatus(rs.getString(7));
				}
				
				

			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				close();
			}

		return libdto;

		}// end of public LibDTO lendBook(String isbn, Scanner sc)------------------------------------------


		// 대여해간 책 tbl_book에서 상태값 1(대여중)으로 바꿔주는거 
		@Override
		public int updateLendBook(Map<String, String> paraMap) {
			int result = 0;
			
			
			try {
				conn = ProjectDBConnection.getConn(); // conn은 수동 commit으로 되어져 있다.

				String sql = " update tbl_book set status = 1 "
						   + " where fk_isbn = ? ";

				pstmt = conn.prepareStatement(sql);
				
				pstmt.setString(1, paraMap.get("isbn"));

				result = pstmt.executeUpdate();
				
				conn.commit();

			} catch(SQLException e) {
				result = -3;
			} finally {
				close();
			}
			
			return result;
		}// end of public int updateLendBook(Map<String, String> paraMap)---------------------------------------------------------
		
		
		
		
		   // 대여해간 책 tbl_book에서 상태값 0(보유중)으로 바꿔주는거 
		   @Override
		   public int updateLendBook2(Map<String, String> paraMap) {
		      int result = 0;
		      
		      
		      try {
		         conn = ProjectDBConnection.getConn(); // conn은 수동 commit으로 되어져 있다.

		         String sql = " update tbl_book set status = 0 "
		                  + " where fk_isbn = ? ";

		         pstmt = conn.prepareStatement(sql);
		         
		         pstmt.setString(1, paraMap.get("isbn"));

		         result = pstmt.executeUpdate();
		         
		         conn.commit();

		      } catch(SQLException e) {
		         
		         e.printStackTrace();
		         
		      } finally {
		         
		         close();
		      }
		      
		      return result;
		   }// end of public int updateLendBook2(Map<String, String> paraMap)---------------------------------------------------------


	
	// 나의 대여 현황 보기
	@Override
	public List<Map<String, String>> showMyLend(MemberDTO member) {
		
		List<Map<String, String>> resultList = new ArrayList<>();
		
		try {
			conn = ProjectDBConnection.getConn(); // conn은 수동 commit으로 되어져 있다.
			
			String sql = " select lend_code, userid, isbn, bookname, lend_date, return_date "+
						 " from  "+
						 " ( "+
						 "    select A.lend_code AS lend_code "+
						 "    , A.fk_user_id AS userid "+
						 "    , A.lend_date AS lend_date "+
						 "    , B.fk_isbn AS isbn "+
						 "    , B.return_date AS return_date "+
						 "    , C.bookname AS bookname "+
						 "    from tbl_lend A "+
						 "    join lend_detail B "+
						 "    on A.lend_code = B.fk_lend_code "+
						 "    join tbl_lib C "+
						 "    on B.fk_isbn = C.isbn "+
						 " ) D "+
						 " where userid = ? ";
			
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, member.getUserid());
			rs = pstmt.executeQuery();
			
			
			while(rs.next()) {
				
				Map<String, String> map = new HashMap<>();
				
				map.put("lend_code", rs.getString(1));
			    map.put("userid", rs.getString(2));
			    map.put("isbn", rs.getString(3));
			    map.put("bookname", rs.getString(4));
			    map.put("lend_date", rs.getString(5));
			    map.put("return_date", rs.getString(6));
			    
			    resultList.add(map);
				
			} // end of while--------------------------
			
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		
		return resultList;
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
