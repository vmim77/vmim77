package jdbc.project.mini;

import java.util.*;

public interface InterLibDAO {
	
	
	// 전체 도서 조회
	public List<LibDTO> bookList();
	
	// 도서 등록
	public int libRegister(LibDTO ldto, Scanner sc);
	
	// 도서 제목 검색
	public List<LibDTO> searchTitle(String title);

	// 도서 저자 검색
	public List<LibDTO> searchWriter(String writer);
	
	// 장르 목록 가져오기
	public List<String> showGenre();
	
	// 장르 검색 
	public List<LibDTO> searchGenre(String genre);
	
	// 도서 대여하기
	//public int lendMyBook(MemberDTO member, String bookName, Scanner sc);
	
	int updateLib(Map<String, String> paraMap); // 도서 정보 변경하기

	LibDTO viewContents(Map<String, String> paraMap); // 도서 정보 보여주기

	int deleteLib(Map<String, String> paraMap); // 도서 정보 삭제하기
	
	public LibDTO lendBookSearch(String isbn, Scanner sc); // 도서 대여하기

	List<Map<String, String>> showMyLend(MemberDTO member); // 나의 대여 현황 보기

	int libdetailRegister(LibDTO libdto);  //도서 상세정보에 등록하기
 
	int updateLendBook(Map<String, String> paraMap); // 대여해간 책 tbl_book에서 상태값 1(대여중)으로 바꿔주는거 

	int updateLendBook2(Map<String, String> paraMap); // 대여해간 책 tbl_book에서 상태값 0(보유중)으로 바꿔주는거 
	
}
