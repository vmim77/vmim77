package jdbc.project.mini;

public class YeoncheDTO {

   private String yc_code;  // 연체 번호
   private String yc_date;  // 연체기간
   private int yc_fee;      // 연체료
   private String fk_userid; // 회원아이디				select용
   private int fk_lend_d_code; // 대여상세일련번호		select용
   private String name;	// 연체회원이름				select용
   
   
   
   
   

public String getYc_code() {
      return yc_code;
   }
   
   public void setYc_code(String yc_code) {
      this.yc_code = yc_code;
   }
   
   public String getYc_date() {
      return yc_date;
   }
   
   public void setYc_date(String yc_date) {
      this.yc_date = yc_date;
   }
   
   public int getYc_fee() {
      return yc_fee;
   }
   
   public void setYc_fee(int yc_fee) {
      this.yc_fee = yc_fee;
   }
   
   public String getFk_userid() {
      return fk_userid;
   }
   
   public void setFk_userid(String fk_userid) {
      this.fk_userid = fk_userid;
   }
   
   public int getFk_lend_d_code() {
      return fk_lend_d_code;
   }
   
   public void setFk_lend_d_code(int fk_lend_d_code) {
      this.fk_lend_d_code = fk_lend_d_code;
   }
   
   public String getName() {
		return name;
   }

	public void setName(String name) {
		this.name = name;
	}
   
}