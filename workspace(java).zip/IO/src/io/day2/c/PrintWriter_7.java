package io.day2.c;

import java.io.*;

public class PrintWriter_7 {

/*
  
 	소스 -- 파일 "C:/iotestdata/오늘의날씨.txt"
	 	노드스트림 -- FileReader -- 파일로 부터 읽어들이겠다.
	 	+ 필터스트림(보조스트림, 오리발) -- BufferedReader -- 읽기 속도향상
 	
 	목적지 -- 파일 "C:/iotestdata/오늘의날씨_copy본.txt"
	 	노드스트림 -- FileWriter -- 파일에 쓰겠다.(기록하겠다)
	 	+ 필터스트림(보조스트림, 오리발) -- BufferdWriter | PrintWriter -- 쓰기 속도향상
 	
 */
	
	
	
	public static void main(String[] args) {
		
		try {
			// 소스 파일 이름
			String srcFileName = "C:/iotestdata/오늘의날씨.txt";
			
			// 2byte 기반의 입력 노드스트림 생성(빨대꽂기)
			FileReader fr = new FileReader(srcFileName);
			
			// 입력 필터스트림(보조스트림, 오리발)을 노드스트림에 장착하기
			BufferedReader bufReader = new BufferedReader(fr, 1024); // 1kb
			
			//------------------------------------------------------//
			
			// 소스 파일 이름
			String targetFileName = "C:/iotestdata/오늘의날씨_copy본.txt";
			
			// 2byte 기반의 출력 노드스트림 생성(빨대꽂기)
			FileWriter fw = new FileWriter(targetFileName);
			
			// 출력 필터스트림(보조스트림, 오리발)을 노드스트림에 장착하기
			PrintWriter prtWriter = new PrintWriter(fw, true);
			/*
			 new PrintWriter(fw, true);
			 두번째 파라미터인 값에 true 를 주면 개행문자(엔터)를 만날때 마다
			 자동으로 flush() 메소드가 작동한다는 말이다.
			 */
			
			
			
			String strLine = null;
			while( (strLine = bufReader.readLine()) != null ) {
				   // bufReader.readLine() 메소드는 1줄 단위로 읽어와서
				   // 읽어온 내용은 String 타입이므로 strLine 변수에 넣어준다.
				   // 1줄을 읽어오되 엔터전까지 읽어온다.
				
				prtWriter.println(strLine);
				
				
			}// end of while------------------------
			
			System.out.println("\n>> 파일복사 완료!! <<\n");
			
			prtWriter.close();
			fw.close();
			
			bufReader.close();
			fr.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		

	}// end of maint(String[] args)----------------------------

}

/*
실행은 명령프롬프트에서 아래와 같이 한다.

C:\Users\User>cd C:\NCS\workspace(java)\IO\bin

C:\NCS\workspace(java)\IO\bin>java io.day2.c.PrintWriter_7


>> 파일복사 완료!! <<

C:\NCS\workspace(java)\IO\bin>

*/