package io.day2.c;

import java.io.FileNotFoundException;
import java.io.IOException;
import io.util.FileManager;

public class FileReaderWriter_3 {

	public static void main(String[] args) {
		
		try {
			FileManager.charFileCopy(args[0], args[1]);
			
			// args[0]은 원본파일 args[1]은 복사되어 붙여넣기해질 파일
			// args[0] 은 C:/iotestdata/애국가.txt으로 하고
			// args[1] 은 C:/iotestdata/애국가_복사본.txt으로 한다.
			
			System.out.println(args[0]+"을 "+args[1]+"로 복사완료함!!");
			
		} catch (FileNotFoundException e) {
			System.out.println("파일 " + args[0] +"이 존재하지 않습니다." );
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("파일 " + args[0] +"이 손상되었습니다." );
			e.printStackTrace();
		}
		
		
		/*
		  	실행은 명령프롬프트에서 아래와 같이 한다.
			C:/Users/박성현>cd C:\NCS\workspace(java)\IO\bin
			
			실행은 명령프롬프트에서 아래와 같이 한다.
			C:\NCS\workspace(java)\IO\bin>java io.day2.c.FileReaderWriter_3 C:/iotestdata/애국가.txt C:/iotestdata/애국가_복사본.txt
			
			애국가.txt 파일은 저장시 인코딩을 ANSI 로 해야 한다.
		 */
		
		
		
		
	}// end of main(String[] args)------------------------------

}




