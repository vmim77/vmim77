package io.day2.c;

import java.io.FileNotFoundException;
import java.io.IOException;
import io.util.FileManager;

public class FileReader_2 {

	public static void main(String[] args) {
		
		String fileName = null;
		try {
			fileName = args[0];
			
			String str = FileManager.reading2(fileName);
			// args[0]에 C:/iotestdata/애국가.txt 로 할 것이다.
			
			System.out.println(str);
			
		} catch (FileNotFoundException e) {
			System.out.println("파일 " + fileName +"이 존재하지 않습니다." );
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("파일 " + fileName +"이 손상되었습니다." );
			e.printStackTrace();
		}
		
		
		/*
		  	실행은 명령프롬프트에서 아래와 같이 한다.
			C:/Users/박성현>cd C:\NCS\workspace(java)\IO\bin
			
			실행은 명령프롬프트에서 아래와 같이 한다.
			C:\NCS\workspace(java)\IO\bin>java io.day2.c.FileReader_2 C:/iotestdata/애국가.txt
			
			애국가.txt 파일은 저장시 인코딩을 ANSI 로 해야 한다.
		 */
		
		
		
		
	}// end of main(String[] args)------------------------------

}




