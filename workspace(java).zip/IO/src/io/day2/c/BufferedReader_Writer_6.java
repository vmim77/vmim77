package io.day2.c;

import java.io.*;

public class BufferedReader_Writer_6 {

/*
  
 	소스 -- 파일 "C:/iotestdata/오늘의날씨.txt"
	 	노드스트림 -- FileReader -- 파일로 부터 읽어들이겠다.
	 	+ 필터스트림(보조스트림, 오리발) -- BufferedReader -- 읽기 속도향상
 	
 	목적지 -- 파일 "C:/iotestdata/오늘의날씨_복사본.txt"
	 	노드스트림 -- FileWriter -- 파일에 쓰겠다.(기록하겠다)
	 	+ 필터스트림(보조스트림, 오리발) -- BufferdWriter | PrintWriter -- 쓰기 속도향상
 	
 */
	
	
	
	public static void main(String[] args) {
		
		try {
			// 소스 파일 이름
			String srcFileName = "C:/iotestdata/오늘의날씨.txt";
			
			// 2byte 기반의 입력 노드스트림 생성(빨대꽂기)
			FileReader fr = new FileReader(srcFileName);
			
			// 입력 필터스트림(보조스트림, 오리발)을 노드스트림에 장착하기
			BufferedReader bufReader = new BufferedReader(fr, 1024); // 1kb
			
			//------------------------------------------------------//
			
			// 소스 파일 이름
			String targetFileName = "C:/iotestdata/오늘의날씨_복사본.txt";
			
			// 2byte 기반의 출력 노드스트림 생성(빨대꽂기)
			FileWriter fw = new FileWriter(targetFileName);
			
			// 출력 필터스트림(보조스트림, 오리발)을 노드스트림에 장착하기
			BufferedWriter bufWriter = new BufferedWriter(fw, 1024); // 1kb
			
			String strLine = null;
			
			while( (strLine = bufReader.readLine()) != null ) {
				   // bufReader.readLine() 메소드는 1줄 단위로 읽어와서
				   // 읽어온 내용은 String 타입이므로 strLine 변수에 넣어준다.
				   // 1줄을 읽어오되 엔터전까지 읽어온다.
				
				bufWriter.write(strLine);
				bufWriter.newLine(); // 줄바꿈을 해야 한다.
				// 또는
				// bufWriter.write("\r\n");
				
				bufWriter.flush();
				
				
				
			}// end of while------------------------
			System.out.println("\n>> 파일복사 완료!! <<\n");
			
			bufWriter.close();
			fw.close();
			
			bufReader.close();
			fr.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		

	}// end of maint(String[] args)----------------------------

}

/*
실행은 명령프롬프트에서 아래와 같이 한다.

C:\Users\User>cd C:\NCS\workspace(java)\IO\bin

C:\NCS\workspace(java)\IO\bin>java io.day2.c.BufferedReader_Writer_6


>> 파일복사 완료!! <<

C:\NCS\workspace(java)\IO\bin>

*/