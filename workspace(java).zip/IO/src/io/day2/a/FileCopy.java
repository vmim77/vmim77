package io.day2.a;

import java.io.*;
import java.util.Scanner;

/*
※ Data Source (File, 키보드, 원격 컴퓨터)
: 데이터의 근원

※ Data Destination (파일, 모니터, 프린터, 메모리)
: 데이터가 최종적으로 도착하는 곳

Data Sourceㅇ======>ㅇ 프로그램 ㅇ======>ㅇ Data Destination
                         입력스트림                    출력스트림
          InputStream       OutputStream          

  
  === 파일로 부터 입력받은 것을 파일에 기록(출력)하는 예제 ===
              
  1. 데이터소스    : 파일로 부터 입력받음             (노드스트림: FileInputStream) 
  2. 데이터목적지 : 결과를 특정 파일에 출력함      (노드스트림: FileOutputStream)
           
*/

public class FileCopy {
	
	// 원본파일의 크기가 10mb 초과하거나 또는
	// 원본파일의 확장자가 .exe .txt .png 일경우 복사를 하지 못하도록 한다.

	public static void main(String[] args) {
		
		String[] extensionArr = {"exe","txt","png"}; // 파일복사를 못하도록 하는 확장자이다.
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print(">> 복사할 원본파일명(절대경로) 입력 ==> ");
		String srcFileName = sc.nextLine();
		
		System.out.print(">> 목적 파일명(절대경로) 입력 ==> ");
		String targetFileName = sc.nextLine();

		System.out.println("소스파일 : " + srcFileName);
		System.out.println("목적파일 : " + targetFileName);
		
		
		byte[]dataArr = new byte[4096]; // 4096 byte == 4kb
		
		int inputLength = 0;
		int totalByte = 0; // byte 수 누적용도
		int cnt = 0;
		
		
		
		try {
			
			// 소스 File 객체 생성하기
			// String 타입인 srcFileName(파일경로명/파일명)이 실제 File 클래스의 객체로 되어진다.
			File srcFile = new File(srcFileName);
			
			long srcFileSize = srcFile.length(); // 파일의 크기를 알려준다.
			System.out.println(">> 원본 파일 크기 : "+ srcFileSize + " byte");
			
			long maxSize = 1024*1024*10; // 10mb
			
			if(srcFileSize > maxSize) {
				// 원본 파일의 크기가 10mb 를 초과한 경우
				System.out.println(">> 원본 파일의 크기가 10mb 초과했으므로 복사할 수 없습니다. <<");
				sc.close();
				// return; // main() 메소드 종료
				System.exit(0); // 프로그램 종료     0 은 정상적인 종료를 뜻하는 것이다.
								// 0 이 아닌, 1 또는 2 또는 10 또는 -1 을 넣어주더라도 동일하게 프로그램이 종료되지만 그 뜻은 비정상적인 종료라는 뜻이다.
				
			}
			/////////////////////////// 용량제한하기 
			
			
			String fileName = srcFile.getName(); // 경로명을 제외한 파일명만 알아오는 것이다.
			
			int index = fileName.lastIndexOf(".");
			
			if(index >= 0) { // 확장자가 존재하는 경우
				String extensionName = fileName.substring(index+1);
				
				for(String ext : extensionArr) {
					if( ext.equalsIgnoreCase(extensionName) ) {
						
						System.out.println(">> 확장자 " + extensionName +" 은 복사가 불가능 합니다. <<");
						System.exit(0); // 프로그램 강제종료
					}
				}// end of for---------------------------
				
			} 
			else { // 확장자가 없는 경우
				System.out.println(">> 확장자가 없는 파일은 복사할 수 없습니다. <<");
				System.exit(0); // 프로그램 강제종료
			}
			
			/////////////////////////// 특정 확장자, 없는 확장자 제한하기 
			
			FileInputStream fist = new FileInputStream(srcFile);
			// FileInputStream 생성 : 접속점이 파일인 것으로 특정 파일에 빨대를 꽂아 파일의 내용물을 1byte 기반으로 빨아들이는 입력노드 스트림이다. 
			
			File targetFile = new File(targetFileName);
			FileOutputStream fost = new FileOutputStream(targetFile);
			// FileOutputStream 생성 : 접속점이 파일인 것으로 특정 파일에 빨대를 꽂아 파일의 내용물을 1byte 기반으로 기록해주는(써주는) 출력노드 스트림이다.
			
			while( (inputLength = fist.read(dataArr)) != -1 ) {
				// 키보드에서 입력한 것을 dataArr의 길이만큼 읽어들여서 
				// 다시 dataArr에 값을 넣어주고, 읽어들인 크기(int)는 inputLength에 넣어준다.
				
				fost.write(dataArr, 0, inputLength); // 입력받은 것을 fost에 적는다.
				// (저장시킨 곳/ 시작점 / 읽어들일 길이)
				
				fost.flush();
				
				totalByte+=inputLength;
				
				
				double percent = ( (double)totalByte/srcFileSize )*100;
				
				
				System.out.printf("\n%4.1f%% 복사중...\n", percent);
				// printf 에서 %를 나타내려면 %% 로 하면 됩니다.
				
				
				cnt++; //반복횟수
			}// end of while-------------------------------
			fist.close();
			fost.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println(targetFileName + "에 쓰기 완료!! " + totalByte + "byte 복사됨.");
		System.out.println("반복회수 : " + cnt + "번 반복함.");
		sc.close();
	}//end of main(String[] args)---------------------------------------

}
