package io.day2.a;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class File_Main {
	
	/*
	   >> File 클래스 <<
	   자바에서 File 클래스의 객체라 함은 파일 및 폴더(디렉토리)를 다 포함한다.
	 */

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("탐색기에 존재하는 파일명을 입력하세요 : ");
		String pathfileName = sc.nextLine();
		// C:/iotestdata/사진/아스키코드표_copy.png
		// C:/iotestdata/텍스트/나의소개_2021.07.13일자.txt
		
		File file1 = new File(pathfileName);
		
		System.out.println("파일명만 : " + file1.getName());
		// file1.getName(); 은 파일명만 알려주는 것이다.
		// 파일명만 : 아스키코드표_copy.png
		// 파일명만 : 나의소개_2021.07.13일자.txt
		
		// === Quiz1 파일 확장자명만 표시하기 == //
		String fileName = file1.getName();
		int index = fileName.lastIndexOf(".");
		String extensionName = "확장자가 없습니다.";
		
		if(index >= 0) {
			extensionName = fileName.substring(index+1);
		}
		System.out.println("확장자명 : " + extensionName );
		// 확장자명 : jpg
		// 확장자명 : txt
		
		long fileSize = file1.length(); 
		System.out.println("파일크기 : " + fileSize + " byte");
		// 파일크기 : 15500 byte
		
		String absolutePath = file1.getAbsolutePath();
		System.out.println("파일의 절대경로 : " + absolutePath);
		// 파일의 절대경로 : C:\iotestdata\사진\아스키코드표_copy.png
		
		String Path = file1.getPath();
		System.out.println("파일의 경로 : " + Path);
		// 파일의 경로 : C:\iotestdata\사진\아스키코드표_copy.png
		
		
		System.out.println("\n================================================\n");
		
		System.out.println(">>> 디렉토리(폴더) 생성하기 <<<");
		
		File dir = new File("C:/iotestdata/MyDir");
		
		boolean bool = false;
		
		if( !dir.exists() ) {
			// 해당 디렉토리(폴더)가 없으면
			
			bool = dir.mkdir(); // 해당 디렉토리(폴더)를 생성해라 // 만들면 true 반환
			
			String result = bool?" 디렉토리(폴더) 생성 성공!!":" 디렉토리(폴더) 생성 실패!!";
			
			System.out.println("C:/iotestdata/MyDir" + result);
		}
		
		
		// >> dir 이 디렉토리(폴더)인지 알아오기 <<
		if(dir.isDirectory()) {
			System.out.println("C:/iotestdata/MyDir 은 디렉토리(폴더) 입니다.");
		}
		
		
		System.out.println("\n================================================\n");
		
		System.out.println(">>> 파일 생성하기 <<<");
		
		File file2 = new File("C:/iotestdata/MyDir/테스트1.txt");
		
		if( !file2.exists() ) {
			// 해당 파일이 존재하지 않으면
			
			try {
				bool = file2.createNewFile(); // 파일 생성하기 
				
				if(bool) {
					// 해당 파일이 정상적으로 생성되었다면
					System.out.println("테스트1.txt 파일의 절대경로 : " + file2.getPath());
					
				}
				
				
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
		
		// >> file2 가 파일인지 알아오기 <<
		if(file2.isFile()) {
			System.out.println("C:/iotestdata/MyDir/테스트1.txt 은 파일입니다.");
		}
		
		
		System.out.println("\n================================================\n");
		
		System.out.println(">>> 파일 삭제하기 <<<");
		
		
		bool = file2.delete(); // 파일 삭제하기
		
		String sp = File.separator;  // 운영체제가 Windows 이라면 File.separator; 은 "\" 이고
									 // 운영체제가 Linux, UNIX 이라면 File.separator; 은 "/" 이고
		
		String result = bool?"C:"+sp+"iotestdata"+sp+"MyDir"+sp+"테스트1.txt 파일삭제 성공!!":"C:/iotestdata/MyDir/테스트1.txt 파일삭제 실패!!";
		System.out.println(result);
		
		System.out.println("\n================================================\n");
		
		System.out.println(">>> 텅빈디렉토리(폴더) 삭제하기 <<<");
		
		if( dir.exists() ) { // Mydir 폴더가 있으면 
			bool = dir.delete(); // 폴더삭제하기

			result = bool?"C:"+sp+"iotestdata"+sp+"MyDir 폴더삭제 성공!!":"C:/iotestdata/MyDir 폴더삭제 실패!!";
			System.out.println(result);
			// C:\iotestdata\MyDir 폴더삭제 성공!!
		}
		
		System.out.println("\n================================================\n");
		
		System.out.println(">>> 내용물이 들어있는 디렉토리(폴더) 삭제하기 <<<");
		/*
		   먼저 아래의 실습을 하려면 탐색기에서 C:\iotestdata\ 밑에 images 라는 폴더를 생성하고 
		   그 images 폴더 속에 파일을 몇 개 올려둔다.
		 */
		
		System.out.println(">>> 내용물이 들어있는 디렉토리(폴더) 삭제하기 실패한 예제 <<<");
		
		File imagesDir = new File("C:/iotestdata/images");
		
		if( imagesDir.exists() ) { // images 폴더가 있으면 
			bool = imagesDir.delete(); // 텅빈디렉토리(폴더) 삭제하는 것이지 내용물이 들어있는 디렉토리(폴더) 삭제하는 것이 아니다.

			result = bool?"C:"+sp+"iotestdata"+sp+"images 폴더삭제 성공!!":"C:/iotestdata/images 폴더삭제 실패!!";
			System.out.println(result);
			// C:/iotestdata/images 폴더삭제 실패!!
		}

		
		System.out.println("\n================================================\n");
		
		System.out.println(">>> 내용물이 들어있는 디렉토리(폴더) 삭제하기 성공한 예제 <<<");
		
		// 1. 내용물이 들어있는 디렉토리(폴더)내에 존재하는 내용물을 파악한다.
		
		if( imagesDir.exists() ) { // NullPointerException을 예방하기위해, 진짜로 저 폴더가 있는지 없는지 확인부터 한다.
		
		
			
			
			File[] fileArr = imagesDir.listFiles();
			// fileArr = { 이미지파일1.png, 이미지파일2.jpg, 이미지파일3.png }
			// 배열의 길이는 이미지 파일들의 갯수만큼 설정된다.
			
			if(fileArr != null) { // NullPointerException을 예방하기위해, 파일이 진짜 있는지 없는지 확인한다.
				
				for(int i=0; i<fileArr.length; i++) {
					if( fileArr[i].isFile() ) { // 이게 파일인지 아닌지 확인한다.
						System.out.println(fileArr[i].getAbsolutePath());
						// 파일이 맞다면, 경로를 출력
						
					}
				}// end of for----------------------------------
				
				/*
				C:\iotestdata\images\ASCII(아스키코드표).png
				C:\iotestdata\images\아스키코드표_copy.png
				 */
				
				// 2. C:\iotestdata\images 폴더내의 파일들을 모두 삭제한다.
				for(int i=0; i<fileArr.length; i++) {
					if( fileArr[i].isFile() ) { // 이게 파일인지 아닌지 확인한다.
						fileArr[i].delete();
					}
				}// end of for----------------------------------
				
				System.out.println("=================================");
				
				// 3. 텅빈 폴더를 삭제한다.
				bool = imagesDir.delete(); //C:\iotestdata\images 폴더는 텅빈 폴더이므로 폴더삭제가 가능하다.
				
				result = bool?"C:"+sp+"iotestdata"+sp+"images 폴더삭제 성공!!":"C:/iotestdata/images 폴더삭제 실패!!";
				System.out.println(result);
				// C:\iotestdata\images 폴더삭제 성공!!
			
			}
		
		}

		
		sc.close();
	}// end of main(String[] args)-------------------------------------

}
