package io.day3.a;

import java.io.Serializable;

public class Student implements Serializable {     // c:/iotestdata/객체저장용/student.dat 파일에 저장함.
												   // UID ==> 1001
	
	// UID ==> 1001
	// 클래스에서 뭔가 내용이 변경됨.
	// UID ==> 1002 로 변경
	
	// 역직렬화하는데 UID값이 일치하지 않아서, 역직렬화가 불가함
	// 이를 방지하고자, UID 값을 final로 선언한다.
	
	private static final long serialVersionUID = 8675905008779484622L;
	private String name;
	private int age; // 원래는 생년월일만 받아서 나이를 구해와야한다. 왜냐면 매년 바뀌니깐
	private String address;
	
	public Student() {} // 기본생성자 안 쓰겠다면 굳이 안 만들어도 된다. 허나 나중에 JSP에서는 꼭 넣어줘야한다.
	
	public Student(String name, int age, String address) {
		this.name = name;
		this.age = age;
		this.address = address;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	@Override
	public String toString() { // 원래는 객체명을 쓰면 메모리주소가 나오는데, 그렇게 나오지말고 재정의한대로 나오게한다.
		return "학생명 : " + name +", 나이 : " + age + ", 주소 : " + address;
	}
	
	
}
