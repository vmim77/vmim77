package io.day3.a;

import java.io.*;
import java.util.*;
import io.util.FileManager;

public class Main {
	
	static List<Student> studList = null;
	
	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		
		try {
			String saveFileName =  "C:/iotestdata/객체저장용/studList.dat";
			
			File savefile = new File(saveFileName);
			
			System.out.println("savefile.exists() : " + savefile.exists());
			// savefile.exists() 은 savefile 이 존재하면 true
			// savefile.exists() 은 savefile 이 존재하지 않으면 false
			
			if( !savefile.exists() ) { // savefile 이 존재하지 않으면 
				
				studList = new ArrayList<>();
				
				Student stud_1 = new Student("한석규",20,"서울시 강동구");
				Student stud_2 = new Student("두석규",21,"서울시 강서구");
				
				studList.add(stud_1);
				studList.add(stud_2);
				
				// 직렬화(Serialization) List<Student> studList 을 "C:/iotestdata/객체저장용/studList.dat" 파일에 저장시키자.
				
				FileManager.objectToFileSave(studList, saveFileName);
			}
			
			
			// 역직렬화 ==> "C:/iotestdata/객체저장용/studList.dat" 파일에 저장되어져 있던 데이터를 읽어서 실제로 List<Student> studList 로 만들겠습니다. 
			
			showAll(saveFileName); // 역직렬화 + 학생정보출력 메소드
			
			///////////////////////////////////////////////////////////////////////////////
			
			Scanner sc = new Scanner(System.in);
			
			System.out.println("\n=== 신입생 추가하기 ===");
			
			System.out.print("학생명 : ");
			String name = sc.nextLine();		// 엄정화		이순신
	
			System.out.print("나이 : ");
			String str_age = sc.nextLine();		// 22		23
			int age = Integer.parseInt(str_age); 
			
			System.out.print("주소 : ");	
			String address = sc.nextLine();		// 서울시 강남구		서울시 강북구
			
			Student stud = new Student(name, age, address);
			
			studList = (List<Student>) FileManager.getObjectFromFile(saveFileName);  // 파일속에 넣어두었던 List를 다시 불러서 넣어줘야한다.
			studList.add(stud);// 두번째 실행할 땐, 파일이 존재하기 때문에 List가 생성이 안된다. 그래서 NullPointerException 유발됨
			
			FileManager.objectToFileSave(studList, saveFileName);
			
			///////////////////////////////////////////////////////
			
			showAll(saveFileName); // 역직렬화 + 학생정보출력 메소드
			
			sc.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} 
		
	}// end of main(String[] args)---------------------------
	
	@SuppressWarnings("unchecked")
	static void showAll(String saveFileName) {
		
		try {
			Object obj = FileManager.getObjectFromFile(saveFileName);
			
			if( obj != null) {
				System.out.println("\n================== 모든 학생들 정보 출력하기 ==================\n");
				
				List<Student> studList = (List<Student>)obj; // 오브젝트타입에서 List 타입으로 다시 형변환시킨다.
			
				for(Student st : studList) {
					System.out.println(st);
				}// end of for----------------------
			
			
			
			}
			
			else { // 파일 속에 아무것도 없는 경우
				System.out.println(">> 파일에 저장된 객체정보가 없습니다. <<");
			}
			
			
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		

		
	}// end of static void static void showAll(String saveFileName)--------------------

}
