package io.day1;

import java.io.*;
import java.util.Scanner;

/*
※ Data Source (File, 키보드, 원격 컴퓨터)
: 데이터의 근원

※ Data Destination (파일, 모니터, 프린터, 메모리)
: 데이터가 최종적으로 도착하는 곳

Data Sourceㅇ======>ㅇ 프로그램 ㅇ======>ㅇ Data Destination
                         입력스트림                    출력스트림
          InputStream       OutputStream          

  
  === 파일로 부터 입력받은 것을 파일에 기록(출력)하는 예제 ===
              
  1. 데이터소스    : 파일로 부터 입력받음             (노드스트림: FileInputStream) 
  2. 데이터목적지 : 결과를 특정 파일에 출력함      (노드스트림: FileOutputStream)
           
*/

public class FileCopy1_9 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print(">> 복사할 원본파일명(절대경로) 입력 ==> ");
		String srcFileName = sc.nextLine();
		
		System.out.print(">> 목적 파일명(절대경로) 입력 ==> ");
		String targetFileName = sc.nextLine();

		System.out.println("소스파일 : " + srcFileName);
		System.out.println("목적파일 : " + targetFileName);
		
		
		byte[]dataArr = new byte[1024]; // 1024 byte == 1kb
		
		int inputLength = 0;
		int totalByte = 0; // byte 수 누적용도
		int cnt = 0;
		
		
		
		try {
			FileInputStream fist = new FileInputStream(srcFileName);
			// FileInputStream 생성 : 접속점이 파일인 것으로 특정 파일에 빨대를 꽂아 파일의 내용물을 1byte 기반으로 빨아들이는 입력노드 스트림이다. 
			
			FileOutputStream fost = new FileOutputStream(targetFileName);
			// FileOutputStream 생성 : 접속점이 파일인 것으로 특정 파일에 빨대를 꽂아 파일의 내용물을 1byte 기반으로 기록해주는(써주는) 출력노드 스트림이다.
			
			while( (inputLength = fist.read(dataArr)) != -1 ) {
				// 파일에 입력된 것을 dataArr의 길이만큼 읽어들여서 
				// 다시 dataArr에 값을 넣어주고, 읽어들인 크기(int)는 inputLength에 넣어준다.
				
				fost.write(dataArr, 0, inputLength); // 입력받은 것을 fost에 적는다.
				// (저장시킨 곳/ 시작점 / 읽어들일 길이)
				
				fost.flush();
				
				totalByte+=inputLength;
				cnt++; //반복횟수
			}// end of while-------------------------------
			fist.close();
			fost.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println(targetFileName + "에 쓰기 완료!! " + totalByte + "byte 복사됨.");
		System.out.println("반복회수 : " + cnt + "번 반복함.");
		sc.close();
	}//end of main(String[] args)---------------------------------------

}
