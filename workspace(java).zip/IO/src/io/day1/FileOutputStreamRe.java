package io.day1;

import java.io.*;

/*
※ Data Source (File, 키보드, 원격 컴퓨터)
: 데이터의 근원

※ Data Destination (파일, 모니터, 프린터, 메모리)
: 데이터가 최종적으로 도착하는 곳

Data Sourceㅇ======>ㅇ 프로그램 ㅇ======>ㅇ Data Destination
                         입력스트림                    출력스트림
          InputStream       OutputStream          

  
  === 키보드로 부터 입력받은 것을 파일 (C:\iotestdata\result.txt)에 기록(출력)하는 예제 ===
              
  1. 데이터소스    : 키보드로 부터 입력받음          (노드스트림: System.in) 
  2. 데이터목적지 : 결과를 특정 파일에 출력함      (노드스트림: FileOutputStream)
           
*/

public class FileOutputStreamRe {

	public static void main(String[] args) {
		
		System.out.println("기록할 내용을 입력하세요 => ");
		String fileName = "C:\\iotestdata\\result.txt";
		boolean append = true;
		
		
		try {
			FileOutputStream fost = new FileOutputStream(fileName, append);
			
			
			int input = 0, totalByte = 0;
			
			while( (input = System.in.read()) != -1) {
				fost.write(input);
				fost.flush();
				totalByte++;
				
			}
			
			System.out.println(fileName + " 에 입력이 완료됐습니다.");
			System.out.println(totalByte + " byte 입력됐습니다.");
			System.out.println("반복횟수 : " + totalByte + "번");
			fost.close();
			System.in.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
		
		
		
		
	}//end of main(String[] args)---------------------------------------

}
