set hidden param parseThreshold = 150000;

show user;
-- USER이(가) "HR"입니다.

create table jdbc_tbl_memo
(no             number(4)
,name           varchar2(20) not null
,msg            varchar2(200) not null
,writeday       date default sysdate
,constraint PK_jdbc_tbl_memo_no primary key(no)
);
-- Table JDBC_TBL_MEMO이(가) 생성되었습니다.

create sequence jdbc_seq_memo
start with 1
increment by 1
nomaxvalue
nominvalue
nocycle
nocache;
-- Sequence JDBC_SEQ_MEMO이(가) 생성되었습니다.

select *
from jdbc_tbl_memo
order by no desc;

insert into jdbc_tbl_memo(no, name, msg) values(jdbc_seq_memo.nextval, '호호', '하하하');
-- 1 행 이(가) 삽입되었습니다.

commit;
-- 커밋 완료.


select no, name, msg, to_char(writeday, 'yyyy-mm-dd hh24:mi:ss') AS writeday
from jdbc_tbl_memo
order by no desc;


select no, name, msg, to_char(writeday, 'yyyy-mm-dd hh24:mi:ss') AS writedayfrom
from jdbc_tbl_memo
-- where no = '2';
-- where name = '';
where msg like '%안녕%'
order by no desc;


-------------------------------------------------------------------------------
-- 08월 04일 

select *
from user_tables
where table_name = 'JDBC_TBL_EXAMTEST';

drop table jdbc_tbl_examtest purge;
-- 만약 동일한 이름의 테이블이 있다면 drop

create table jdbc_tbl_examtest
(no         number(4)
,name       varchar2(40)
,msg        varchar2(200)
,writeday   date default sysdate
,constraint PK_jdbc_tbl_examtest_no primary key(no)
);
-- 위의 SQL문을 자바에서 실행할 것이다.

select *
from user_sequences
where sequence_name = 'JDBC_SEQ_EXAMTEST';

drop sequence jdbc_seq_examtest;
-- 만약 동일한 이름의 시퀀스가 있다면 drop

create sequence jdbc_seq_examtest
start with 1
increment by 1
nomaxvalue
nominvalue
nocycle
nocache;
-- 위의 SQL문을 자바에서 실행할 것이다.








