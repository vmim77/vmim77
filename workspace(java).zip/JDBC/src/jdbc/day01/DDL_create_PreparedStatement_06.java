package jdbc.day01;

import java.sql.*;

public class DDL_create_PreparedStatement_06 {

	public static void main(String[] args) {
		
		Connection conn = null;
		// Connection conn 이 오라클 데이터베이스 서버와 연결을 맺어주는 객체이다.
		
		PreparedStatement pstmt = null;
		// PreparedStatement 이 Connection conn(특정 오라클 서버)에 전송할 SQL문(편지)을 전송해주는 객체(우편배달부)이다. 
		
		ResultSet rs = null;
		// ResultSet rs 은 select 되어진 결과물이 저장되어지는 곳.
		
		
		try {
			// >>> 1. 오라클 드라이버 로딩 <<<
			/*
			  === OracleDriver(오라클 드라이버)의 역할 ===
			  1). OracleDriver 를 메모리에 로딩시켜준다.
			  2). OracleDriver 객체를 생성해준다.
			  3). OracleDriver 객체를 DriverManager에 등록시켜준다.
			      -->  DriverManager 는 여러 드라이버들을 Vector 에 저장하여 관리해주는 클래스이다.
			 */
		
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			// >>> 2. 어떤 오라클 서버에 연결을 할래? <<<
			
			conn = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:xe", "HR", "cclass");
			// 자기 IP의 로컬서버에 접속
			
			
			// >>> 3. SQL문(편지)을 작성한다. <<<
			String sql1 = " select * " + 
						  " from user_tables " + 
						  " where table_name = 'JDBC_TBL_EXAMTEST' ";
			
			String sql2 = " drop table jdbc_tbl_examtest purge ";
			
			String sql3 = " create table jdbc_tbl_examtest " + 
						  " (no         number(4) " + 
						  " ,name       varchar2(40) " + 
						  " ,msg        varchar2(200) " + 
						  " ,writeday   date default sysdate " + 
						  " ,constraint PK_jdbc_tbl_examtest_no primary key(no) " + 
						  " ) ";
			
			String sql4 = " select * " + 
						  " from user_sequences " + 
						  " where sequence_name = 'JDBC_SEQ_EXAMTEST' ";
			
			String sql5 = " drop sequence jdbc_seq_examtest ";
			
			String sql6 = " create sequence jdbc_seq_examtest " + 
						  " start with 1 " + 
						  " increment by 1 " + 
						  " nomaxvalue " + 
						  " nominvalue " + 
						  " nocycle " + 
						  " nocache ";
			
			String sql7 = " insert into JDBC_TBL_EXAMTEST(no, name, msg) "
					    + " values(jdbc_seq_examtest.nextval, '이순신', '안녕하세요? 이순신입니다.') "; 
					
			String sql8 = " select no, name, msg, to_char(writeday, 'yyyy-mm-dd hh24:mi:ss') AS writeday "
					    + " from JDBC_TBL_EXAMTEST "
					    + " order by no asc ";
			
			// >>> 4. 연결한 오라클서버(conn)에 SQL문(편지)을 전달해줄 PreparedStatement 객체(우편배달부) 생성하기 <<<
			// "JDBC_TBL_EXAMTEST" 테이블이 있나 없나 먼저 확인한다.
			pstmt = conn.prepareStatement(sql1);
			
			
			
			// >>> 5. PreparedStatement pstmt 객체(우편배달부)는 작성한 SQL문(편지)을 오라클 서버에 보내서 실행이 되도록 해야 한다.  <<<
			rs = pstmt.executeQuery();
			// 리턴타입은 ResultSet인데 select되어진 결과물이 담겨질 곳이다.
			//   SQL문이 DQL문(select) 이므로 executeQuery(); 이다.
	        //   pstmt.executeQuery(); 을 실행하면 select 되어진 결과물을 가져오는데 그 타입은 ResultSet 으로 가져온다.
			
			
			int n = 0;
			
			if(rs.next()) { // select 되어진 결과가 있냐 없냐를 판단한다. 
							// select 되어진 행이 있다면 true 반환, 없으면 false 반환
				
				// "JDBC_TBL_EXAMTEST" 테이블이 존재하는 경우
				
				// >>> 4. 연결한 오라클서버(conn)에 SQL문(편지)을 전달해줄 PreparedStatement 객체(우편배달부) 생성하기 <<<
				// "JDBC_TBL_EXAMTEST" 테이블을 먼저 drop 해야 한다.
				pstmt.close();
				pstmt = conn.prepareStatement(sql2);
				
				// >>> 5. PreparedStatement pstmt 객체(우편배달부)는 작성한 SQL문(편지)을 오라클 서버에 보내서 실행이 되도록 해야 한다.  <<<
				n = pstmt.executeUpdate();
				/*    pstmt.executeUpdate()은  
	                  DML(insert, update, delete, merge)문 및 DDL(create table, create view, drop table 등)문을 수행해주는 메소드로서 
	                                    결과값은 int 형태로서 DML문 이라면 적용된 행의 갯수가 나오고 DDL문 이라면 0이 나온다.
				 */
				
				System.out.println("drop table : " + n);
				
			}
			
			// >>> 4. 연결한 오라클서버(conn)에 SQL문(편지)을 전달해줄 PreparedStatement 객체(우편배달부) 생성하기 <<<
			// "JDBC_TBL_EXAMTEST" 테이블을 create 해야 한다.
			
			pstmt = conn.prepareStatement(sql3);
			
			// >>> 5. PreparedStatement pstmt 객체(우편배달부)는 작성한 SQL문(편지)을 오라클 서버에 보내서 실행이 되도록 해야 한다.  <<<
			n = pstmt.executeUpdate();
			/*    pstmt.executeUpdate()은  
                  DML(insert, update, delete, merge)문 및 DDL(create table, create view, drop table 등)문을 수행해주는 메소드로서 
                                    결과값은 int 형태로서 DML문 이라면 적용된 행의 갯수가 나오고 DDL문 이라면 0이 나온다.
			 */
			
			System.out.println("create table : " + n);
			
			
			//// 여기까지가 테이블 만들기
			//////////////////////////////////////////////////////////////////////////////
			//// 이제부터 시퀀스 만들기
			
			// >>> 4. 연결한 오라클서버(conn)에 SQL문(편지)을 전달해줄 PreparedStatement 객체(우편배달부) 생성하기 <<<
			// "JDBC_SEQ_EXAMTEST" 시퀀스가 있나 없나 알아본다.
			pstmt = conn.prepareStatement(sql4);
			
			// >>> 5. PreparedStatement pstmt 객체(우편배달부)는 작성한 SQL문(편지)을 오라클 서버에 보내서 실행이 되도록 해야 한다.  <<<
			rs.close();
			rs = pstmt.executeQuery();
			
			if(rs.next()) { 

				// "JDBC_SEQ_EXAMTEST" 시퀀스가 존재하는 경우
				
				// >>> 4. 연결한 오라클서버(conn)에 SQL문(편지)을 전달해줄 PreparedStatement 객체(우편배달부) 생성하기 <<<
				// "JDBC_SEQ_EXAMTEST" 시퀀스를 drop해야 한다.
				pstmt = conn.prepareStatement(sql5);
				
				// >>> 5. PreparedStatement pstmt 객체(우편배달부)는 작성한 SQL문(편지)을 오라클 서버에 보내서 실행이 되도록 해야 한다.  <<<
				n = pstmt.executeUpdate();

				
				System.out.println("drop sequence : " + n);
	
			}

			
			// >>> 4. 연결한 오라클서버(conn)에 SQL문(편지)을 전달해줄 PreparedStatement 객체(우편배달부) 생성하기 <<<
			// "JDBC_SEQ_EXAMTEST" 시퀀스를 create 해야 한다.
			pstmt = conn.prepareStatement(sql6);
			
			// >>> 5. PreparedStatement pstmt 객체(우편배달부)는 작성한 SQL문(편지)을 오라클 서버에 보내서 실행이 되도록 해야 한다.  <<<
			n = pstmt.executeUpdate();
			
			System.out.println("create sequence : " + n);
			
			
			
			///// 여기까지 시퀀스 만들기
			///////////////////////////////////////////////////////////////////////////
			///// insert 하기
			
			pstmt = conn.prepareStatement(sql7);
			n = pstmt.executeUpdate();
			System.out.println("insert 를 한 DML문의 n : " + n );
			
			
			pstmt = conn.prepareStatement(sql8);
			rs = pstmt.executeQuery();
			
			StringBuilder sb = new StringBuilder();
			
			int cnt = 0;
			while(rs.next()) {
				cnt++;
				sb.append( rs.getInt("NO") + "\t" + rs.getString("NAME") + "\t" + rs.getString("MSG") + "\t" + rs.getString("WRITEDAY") + "\n" );
			}// end of while(rs.next())----------------------------------
			
			if(cnt > 0) {
				System.out.println("------------------------------------------------------");	
				System.out.println("글번호\t글쓴이\t글내용\t작성일자");	
				System.out.println("------------------------------------------------------");	
			
				System.out.println(sb.toString()); // 스트링빌더에 쌓아뒀던 값을 출력하자
				System.out.println("==== 조회된 건수 : " + cnt + " 개");
			}
			
			else {
				System.out.println(">>> JDBC_TBL_EXAMTEST 테이블에 입력된 데이터가 없습니다.!! <<<");
			}
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println(">> SQL구문 오류!! <<");
			e.printStackTrace();
		} finally {
			// >>> 6. 사용하였던 자원을 반납하기 << //
			// 반납의 순서는  생성순서의 역순으로 한다.
			
			try {
				if(rs != null)
					rs.close();
				
				
				if(pstmt != null) // default가 null이여서 null.close는 안 된다.
					pstmt.close(); 
					
				if(conn != null)
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				} 
			}
		
		System.out.println("~~~ 프로그램 종료 ~~~");
		
	}// end of main(String[] args)--------------------------------------------

}
