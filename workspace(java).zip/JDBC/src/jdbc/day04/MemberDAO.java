package jdbc.day04;

import java.sql.*;
import java.util.*;
import jdbc.day04.singleton.dbconnection.MyDBConnection;

public class MemberDAO implements InterMemberDAO {
	
	// field, attribute, property, 속성을 정의한다.
	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;
		 
	// === 자원반납 메소드 === //
	private void close() {
		try {
			if( rs != null )    rs.close();
			if( pstmt != null ) pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}// end of private void close()
	
	// 회원가입(insert) 메소드 구현하기 // 
	@Override
	public int memberRegister(MemberDTO member, Scanner sc) {
		// 입력할 회원의 정보와 스캐너 기능을 Ctrl에게서 받는다.
		
		int result = 0;
		
		try {
			
			conn = MyDBConnection.getConn();
			// 이 메소드를 호출하면 conn을 리턴해준다.
			// 리턴해주는 conn은 DB서버(127.0.0.1)에 연결을 하고, 수동 commit으로 전환한 conn이다.
			
			String sql = " insert into jdbc_member(userseq, userid, passwd, name, mobile) "+
				     " values(userseq.nextval, ?, ?, ?, ?) ";
		
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, member.getUserid());
			pstmt.setString(2, member.getPasswd());
			pstmt.setString(3, member.getName());
			pstmt.setString(4, member.getMobile());
		
			result = pstmt.executeUpdate();
			
			if(result == 1) { //  정상적으로 insert됐으니, commit과 rollback을 고르게 해준다.
				
				String yn = "";
				
				do {
					System.out.print("▷ 회원가입을 정말로 하시겠습니까?[Y/N] : ");
					yn = sc.nextLine(); // << 요렇게 회원에게 물어보고 값을 읽어오려고 스캐너가 넘어온 것이다.
					
					if("y".equalsIgnoreCase(yn)) {
						conn.commit(); // 커밋
						// 현재 result == 1이니 그냥 넘어가게 한다.
					}
					else if("n".equalsIgnoreCase(yn)) {
						conn.rollback(); // 롤백
						result = 0;
						// rollback이면 0을 반환하게 한다.
					}
					else {
						System.out.println(">>> Y 또는 N 만 입력하세요!! \n");
					}
				} while( !( "y".equalsIgnoreCase(yn) || "n".equalsIgnoreCase(yn) ) );
				// end of do~while------------------------------------------------------
				
			}// end of if(result == 1)--------------------------------------------------
			
			
		} catch(SQLIntegrityConstraintViolationException e) { // 오라클의 제약조건에 위백 된경우 발생함.
			
			if(e.getErrorCode() == 1)  // Unique 제약조건 위배 == ID가 중복됨
				result = -1;
		} catch (SQLException e) {
			result = -2;
		}
		
		return result;
	}// end of public int memberRegister(MemberDTO member, Scanner sc) --------------------------------

	@Override
	public MemberDTO login(Map<String, String> paraMap) {
		
		
		MemberDTO member = null;
		
		try {
			
			conn = MyDBConnection.getConn();
			
			String sql = " select userseq, userid, passwd, name, mobile, point, to_char(registerday, 'yyyy-mm-dd') AS registerday, status "+
					     " from jdbc_member "+
					     " where userid = ? and passwd = ? ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setNString(1, paraMap.get("userid")); // 사용자가 입력한 ID --> Key값의 Value값이 나온다.
			pstmt.setNString(2, paraMap.get("passwd")); // 사용자가 입력한 PW --> Key값의 Value값이 나온다.
			
			rs = pstmt.executeQuery(); // 알맞은 아이디와 비밀번호를 넣었다면 행이 1개, 이상한거면 행이 0개
			
			if(rs.next()) {
				member = new MemberDTO();
				
				member.setUserseq(rs.getInt(1));
				member.setUserid(rs.getString(2));
				member.setPasswd(rs.getString(3));
				member.setName(rs.getString(4));
				member.setMobile(rs.getString(5));
				member.setPoint(rs.getInt(6));
				member.setRegisterday(rs.getString(7));
				member.setStatus(rs.getInt(8));
			} 
			
		} catch (SQLException e) {
			System.out.println(">> SQL구문 오류!! <<");
			e.printStackTrace();
		}  finally {
			close();
		}
		
		return member;
	}// end of public MemberDTO login(Map<String, String> paraMap) -------------------------------------
	
	// 게시판에 글을 쓴 작성자에게 point 를 10 올려주기
	@Override
	public int updateMemberPoint(String userid) {
		
		int result = 0;
		
		try {
			conn = MyDBConnection.getConn(); // conn 은 수동 commit 으로 되어져 있다.
			
			String sql = " update jdbc_member set point = point + 10 "
					   + " where userid = ? ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userid);
			
			result = pstmt.executeUpdate();
			// update 가 성공되어지면 result 에는 1 이 들어간다.
			
			
		} catch (SQLException e) {
			
		} finally {
			close();
		}
		
		
		return result;
		// result 는  1 또는 0 을 리턴할 것이다.
		
		
		
	} // end of public int updateMemberPoint(String userid)------------------------
	
	
	// (관리자전용)모든회원정보조회
	@Override
	public List<MemberDTO> selectAllMember(String sortChoice) {
		
		List<MemberDTO> memberList = new ArrayList<>();
		
		try {
			
			conn = MyDBConnection.getConn();
			
			String sql = " select userseq, userid, name, mobile, point, to_char(registerday, 'yyyy-mm-dd') AS REGISTERDAY "+
					     " from jdbc_member "+
					     " where userid != 'admin' ";
					     
			switch (sortChoice) {
			
			case "1": // 회원명의 오름차순
				
				sql += " order by name asc ";
				
				break;
				
			case "2": // 회원명의 내림차순
				
				sql += " order by name desc ";
				
				break; 
				
			case "3": // 가입일자의 오름차순
				
				sql += " order by REGISTERDAY asc ";
				
				break;
				
			case "4": // 가입일자의 내림차순
				
				sql += " order by REGISTERDAY desc ";
				
				break;

			}// end of switch-----------------------------------------------
			
			
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery(); 
			
			while(rs.next()) {
				
				MemberDTO member = new MemberDTO();
				
				member.setUserseq(rs.getInt(1));
				member.setUserid(rs.getString(2));
				member.setName(rs.getString(3));
				member.setMobile(rs.getString(4));
				member.setPoint(rs.getInt(5));
				member.setRegisterday(rs.getString(6));
				
				memberList.add(member);
				
				
			}// end of while-------------------------------------------------
			
		} catch (SQLException e) {
			System.out.println(">> SQL구문 오류!! <<");
			e.printStackTrace();
		}  finally {
			close();
		}
		
		
		return memberList;
	}// end of public List<MemberDTO> selectAllMember(String sortChoice)------------------------------
}
