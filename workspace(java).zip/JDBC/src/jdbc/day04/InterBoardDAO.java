package jdbc.day04;

import java.util.*;

public interface InterBoardDAO {
	
	// 게시판 글쓰기(insert)
	int write(BoardDTO bdto);
	
	// 글목록보기
	List<BoardDTO> boardList();
	
	// 글내용보기
	BoardDTO viewContents(Map<String, String> paraMap);
	
	// 조회수 1 증가 시키기
	void updateViewCount(String boardno);
	
	// 댓글쓰기(jdbc_comment 테이블에 insert)
	int writeComment(BoardCommentDTO cmdto, Scanner sc); 
	
	// 원글에 대한 댓글을 가져오는 것(특정 게시글 글번호에 대한 jdbc_comment 테이블과 jdbc_member 테이블을 JOIN 해서 보여준다.)
	List<BoardCommentDTO> commentList(String boardno);
	
	// 글 수정하기
	int updateBoard(Map<String, String> paraMap);
	
	// 글 삭제하기
	int deleteBoard(Map<String, String> paraMap);
	
	// 이번주 일자별 게시글 작성건수
	Map<String, Integer> statisticsByWeek();
	
	// 이번달 일자별 게시글 작성건수
	List<Map<String, String>> statisticsByCurrentMonth();
}
