package jdbc.day04;

public class BoardCommentDTO { // BoardCommentDTO 가 오라클의 jdbc_comment(자식 테이블)에 해당한다.
	
	private int commentno; 		// 댓글번호 
	private String fk_boardno; 	// 원글의 글번호   * 원래 number타입이라 int 해야하는데, String의 호환성을 보여주려고 일부러 String으로 선언
	private String fk_userid; 	// 작성자 회원아이디
	private String contents; 	// 댓글내용 
	private String writeday; 	// 작성일자
	
	private MemberDTO member; // select 용 (jdbc_member 테이블과 jdbc_comment 테이블의 JOIN). 글쓴이에 대한 모든 정보
	  						  // MemberDTO 가 오라클의 jdbc_member(부모테이블)에 해당함.
	
	
	
	

	public int getCommentno() {
		return commentno;
	}
	
	public void setCommentno(int commentno) {
		this.commentno = commentno;
	}
	
	public String getFk_boardno() {
		return fk_boardno;
	}
	
	public void setFk_boardno(String fk_boardno) {
		this.fk_boardno = fk_boardno;
	}
	
	public String getFk_userid() {
		return fk_userid;
	}
	
	public void setFk_userid(String fk_userid) {
		this.fk_userid = fk_userid;
	}
	
	public String getContents() {
		return contents;
	}
	
	public void setContents(String contents) {
		this.contents = contents;
	}
	
	public String getWriteday() {
		return writeday;
	}
	
	public void setWriteday(String writeday) {
		this.writeday = writeday;
	}
	
	public MemberDTO getMember() {
		return member;
	}
	
	public void setMember(MemberDTO member) {
		this.member = member;
	}

	
	////////////////////////////////////////////////////////////////
	
	public String viewInfo() { // 댓글내용\t\t작성자\t작성일자
		

		
		return contents+"\t\t"+member.getName()+"\t"+writeday;
	}
	
	
	
	
	
	
	
	
}
