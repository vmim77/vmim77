set hidden param parseThreshold = 150000;

show user;
-- USER이(가) "HR"입니다.

---- **** 회원 테이블 생성하기 **** ----

select *
from user_tables
where table_name = 'JDBC_MEMBER';

create table jdbc_member
(userseq       number        not null    -- 회원번호
,userid        varchar2(30)  not null    -- 회원아이디
,passwd        varchar2(30)  not null    -- 회원암호
,name          varchar2(20)  not null    -- 회원명
,mobile        varchar2(20)              -- 연락처
,point         number(10) default 0      -- 포인트
,registerday   date default sysdate      -- 가입일자 
,status        number(1) default 1       -- status 컬럼의 값이 1 이면 정상, 0 이면 탈퇴 
,constraint PK_jdbc_member primary key(userseq)
,constraint UQ_jdbc_member unique(userid)
,constraint CK_jdbc_member check( status in(0,1) )
);
-- Table JDBC_MEMBER이(가) 생성되었습니다.


create sequence userseq
start with 1
increment by 1
nomaxvalue
nominvalue
nocycle
nocache;
-- Sequence USERSEQ이(가) 생성되었습니다.


select *
from jdbc_member
order by userseq asc;


---- *** 게시판 테이블 생성하기 *** ----
create table jdbc_board
(boardno       number        not null          -- 글번호
,fk_userid     varchar2(30)  not null          -- 작성자 회원아이디
,subject       varchar2(100) not null          -- 글제목
,contents      varchar2(200) not null          -- 글내용
,writeday      date default sysdate not null   -- 작성일자
,viewcount     number default 0 not null       -- 조회수 
,boardpasswd   varchar2(20) not null           -- 글암호 
,constraint PK_jdbc_board primary key(boardno)
,constraint FK_jdbc_board foreign key(fk_userid) references jdbc_member(userid) 
);
-- Table JDBC_BOARD이(가) 생성되었습니다.


create sequence board_seq
start with 1
increment by 1
nomaxvalue
nominvalue
nocycle
nocache;
-- Sequence BOARD_SEQ이(가) 생성되었습니다.

desc jdbc_board;

select *
from jdbc_board
order by boardno desc;



---- *** 댓글 테이블 생성하기 *** ----
create table jdbc_comment 
(commentno   number        not null    -- 댓글번호 
,fk_boardno  number        not null    -- 원글의 글번호 
,fk_userid   varchar2(30)  not null    -- 작성자 회원아이디
,contents    varchar2(200) not null    -- 댓글내용 
,writeday    date default sysdate      -- 작성일자
,constraint  PK_jdbc_comment  primary key(commentno) 
,constraint  FK_jdbc_comment_fk_boardno foreign key(fk_boardno) 
             references jdbc_board(boardno) on delete cascade 
,constraint  FK_jdbc_comment_fk_userid  foreign key(fk_userid) 
             references jdbc_member(userid) 
);
-- Table JDBC_COMMENT이(가) 생성되었습니다.


create sequence seq_comment
start with 1
increment by 1
nomaxvalue
nominvalue
nocycle
nocache;
-- Sequence SEQ_COMMENT이(가) 생성되었습니다.


select *
from jdbc_comment; 

--------------------------------------------------------------------------------

/*
     Transaction(트랜잭션) 처리 실습을 위해서 
     jdbc_member 테이블의 point 컬럼의 값은 최대 30을 넘지 못하도록 check 제약을 걸도록 하겠습니다.
*/

alter table jdbc_member
add constraint CK_jdbc_member_point check( point between 0 and 30 );
-- Table JDBC_MEMBER이(가) 변경되었습니다.

select *
from jdbc_board;


select *
from jdbc_member
order by userseq asc;

select B.boardno
, case when length(B.subject) > 10 then substr(B.subject, 1, 8) || '..' 
  else B.subject end AS subject
, M.name, to_char(B.writeday, 'yyyy-mm-dd hh24:mi:ss') AS writeday, b.viewcount
from jdbc_board B JOIN jdbc_member M
on B.fk_userid = M.userid
order by 1 desc


select subject, contents, fk_userid, boardpasswd
from jdbc_board
where boardno = 2;


select subject, contents, fk_userid, boardpasswd
from jdbc_board
where boardno = 2123565;

insert into jdbc_comment(commentno, fk_boardno, fk_userid, contents)
values(seq_comment.nextval, 2342, 'leess', '댓글 연습 입니다. ㅎㅎㅎㅎ');
/*
오류 보고 -
ORA-02291: integrity constraint (HR.FK_JDBC_COMMENT_FK_BOARDNO) violated - parent key not found
*/

select *
from jdbc_comment;


show user;

select *
from tab;



-- 목록보기시 댓글의 개수를 보여주도록 한다.
select B.boardno
, case when length(B.subject) > 10 then substr(B.subject, 1, 8) || '..' 
  else B.subject end AS subject
, M.name, to_char(B.writeday, 'yyyy-mm-dd hh24:mi:ss') AS writeday, b.viewcount
, nvl(c.commentcnt, 0) AS commentcnt
from jdbc_board B JOIN jdbc_member M
on B.fk_userid = M.userid
LEFT JOIN 
(select fk_boardno, count(*) AS commentcnt
 from jdbc_comment
 group by fk_boardno) C
on B.boardno = C.fk_boardno
order by 1 desc;

select *
from jdbc_comment
where fk_boardno = 3;

select *
from jdbc_comment
where fk_boardno = 6;

select *
from jdbc_comment
where fk_boardno = 2;


-- 해당 글번호의 댓글 보기
select C.contents, M.name, C.writeday
from
(
select contents
    ,  to_char(writeday, 'yyyy-mm-dd hh24:mi:ss') AS writeday
    ,  fk_userid
from jdbc_comment
where fk_boardno = 5
) C JOIN jdbc_member M
on C.fk_userid = M.userid;



---- ==== 최근 1주일간 일자별 게시글 작성건수 조회하기 ==== ----

select boardno, subject, to_char(writeday, 'yyyy-mm-dd hh24:mi:ss')
from jdbc_board
order by boardno desc;


/*
----------------------------------------------------------------------------------------------
 TOTAL   PREVIOUS6   PREVIOUS5   PREVIOUS4   PREVIOUS3   PREVIOUS2   PREVIOUS1   TODAY
----------------------------------------------------------------------------------------------
   4        3            0           0           0           0           1         0

*/


select boardno, subject, to_char(writeday, 'yyyy-mm-dd hh24:mi:ss')
    , sysdate - writeday
    , to_char(sysdate, 'yyyy-mm-dd')
    , to_char(writeday, 'yyyy-mm-dd')
    , to_date(to_char(sysdate, 'yyyy-mm-dd')) - to_date(to_char(writeday, 'yyyy-mm-dd'))
from jdbc_board
order by boardno desc;


select writeday
      , to_date(to_char(sysdate, 'yyyy-mm-dd')) - to_date(to_char(writeday, 'yyyy-mm-dd')) AS 날짜뺄셈
      , decode( to_date(to_char(sysdate, 'yyyy-mm-dd')) - to_date(to_char(writeday, 'yyyy-mm-dd')), 6, 1) AS PREVIOUS6 
      , decode( to_date(to_char(sysdate, 'yyyy-mm-dd')) - to_date(to_char(writeday, 'yyyy-mm-dd')), 5, 1) AS PREVIOUS5
      , decode( to_date(to_char(sysdate, 'yyyy-mm-dd')) - to_date(to_char(writeday, 'yyyy-mm-dd')), 4, 1) AS PREVIOUS4
      , decode( to_date(to_char(sysdate, 'yyyy-mm-dd')) - to_date(to_char(writeday, 'yyyy-mm-dd')), 3, 1) AS PREVIOUS3
      , decode( to_date(to_char(sysdate, 'yyyy-mm-dd')) - to_date(to_char(writeday, 'yyyy-mm-dd')), 2, 1) AS PREVIOUS2
      , decode( to_date(to_char(sysdate, 'yyyy-mm-dd')) - to_date(to_char(writeday, 'yyyy-mm-dd')), 1, 1) AS PREVIOUS1
      , decode( to_date(to_char(sysdate, 'yyyy-mm-dd')) - to_date(to_char(writeday, 'yyyy-mm-dd')), 0, 1) AS TODAY
from jdbc_board
where to_date(to_char(sysdate, 'yyyy-mm-dd')) - to_date(to_char(writeday, 'yyyy-mm-dd')) < 7;

select writeday
      , decode( to_date(to_char(sysdate, 'yyyy-mm-dd')) - to_date(to_char(writeday, 'yyyy-mm-dd')), 6, 1, 0) AS PREVIOUS6 
      , decode( to_date(to_char(sysdate, 'yyyy-mm-dd')) - to_date(to_char(writeday, 'yyyy-mm-dd')), 5, 1, 0) AS PREVIOUS5
      , decode( to_date(to_char(sysdate, 'yyyy-mm-dd')) - to_date(to_char(writeday, 'yyyy-mm-dd')), 4, 1, 0) AS PREVIOUS4
      , decode( to_date(to_char(sysdate, 'yyyy-mm-dd')) - to_date(to_char(writeday, 'yyyy-mm-dd')), 3, 1, 0) AS PREVIOUS3
      , decode( to_date(to_char(sysdate, 'yyyy-mm-dd')) - to_date(to_char(writeday, 'yyyy-mm-dd')), 2, 1, 0) AS PREVIOUS2
      , decode( to_date(to_char(sysdate, 'yyyy-mm-dd')) - to_date(to_char(writeday, 'yyyy-mm-dd')), 1, 1, 0) AS PREVIOUS1
      , decode( to_date(to_char(sysdate, 'yyyy-mm-dd')) - to_date(to_char(writeday, 'yyyy-mm-dd')), 0, 1, 0) AS TODAY
from jdbc_board
where to_date(to_char(sysdate, 'yyyy-mm-dd')) - to_date(to_char(writeday, 'yyyy-mm-dd')) < 7;

select COUNT(*) TOTAL
      , SUM( decode( to_date(to_char(sysdate, 'yyyy-mm-dd')) - to_date(to_char(writeday, 'yyyy-mm-dd')), 6, 1, 0) ) AS PREVIOUS6 
      , SUM( decode( to_date(to_char(sysdate, 'yyyy-mm-dd')) - to_date(to_char(writeday, 'yyyy-mm-dd')), 5, 1, 0) ) AS PREVIOUS5
      , SUM( decode( to_date(to_char(sysdate, 'yyyy-mm-dd')) - to_date(to_char(writeday, 'yyyy-mm-dd')), 4, 1, 0) ) AS PREVIOUS4
      , SUM( decode( to_date(to_char(sysdate, 'yyyy-mm-dd')) - to_date(to_char(writeday, 'yyyy-mm-dd')), 3, 1, 0) ) AS PREVIOUS3
      , SUM( decode( to_date(to_char(sysdate, 'yyyy-mm-dd')) - to_date(to_char(writeday, 'yyyy-mm-dd')), 2, 1, 0) ) AS PREVIOUS2
      , SUM( decode( to_date(to_char(sysdate, 'yyyy-mm-dd')) - to_date(to_char(writeday, 'yyyy-mm-dd')), 1, 1, 0) ) AS PREVIOUS1
      , SUM( decode( to_date(to_char(sysdate, 'yyyy-mm-dd')) - to_date(to_char(writeday, 'yyyy-mm-dd')), 0, 1, 0) ) AS TODAY
from jdbc_board
where to_date(to_char(sysdate, 'yyyy-mm-dd')) - to_date(to_char(writeday, 'yyyy-mm-dd')) < 7;


create or replace function func_midnight
(p_date     IN  date) -- 이 함수에 날짜를 넣어주면, 자정으로 만든 날짜를 리턴해줄 것이다.
return DATE
is
begin
    return to_date( to_char(p_date, 'yyyy-mm-dd' ), 'yyyy-mm-dd' );
end func_midnight;
-- Function FUNC_MIDNIGHT이(가) 컴파일되었습니다.


select COUNT(*) TOTAL
      , SUM( decode( func_midnight(sysdate) - func_midnight(writeday), 6, 1, 0) ) AS PREVIOUS6 
      , SUM( decode( func_midnight(sysdate) - func_midnight(writeday), 5, 1, 0) ) AS PREVIOUS5
      , SUM( decode( func_midnight(sysdate) - func_midnight(writeday), 4, 1, 0) ) AS PREVIOUS4
      , SUM( decode( func_midnight(sysdate) - func_midnight(writeday), 3, 1, 0) ) AS PREVIOUS3
      , SUM( decode( func_midnight(sysdate) - func_midnight(writeday), 2, 1, 0) ) AS PREVIOUS2
      , SUM( decode( func_midnight(sysdate) - func_midnight(writeday), 1, 1, 0) ) AS PREVIOUS1
      , SUM( decode( func_midnight(sysdate) - func_midnight(writeday), 0, 1, 0) ) AS TODAY
from jdbc_board
where func_midnight(sysdate) - func_midnight(writeday) < 7;




-- 이번달 일자별 게시글 작성건수

select decode(grouping( to_char(writeday, 'yyyy-mm-dd') ), 0, to_char(writeday, 'yyyy-mm-dd'), '전체') AS WRITEDAY
     , count(*) AS CNT
from jdbc_board
where to_char(writeday, 'yyyy-mm') = to_char(sysdate, 'yyyy-mm')
group by rollup ( to_char(writeday, 'yyyy-mm-dd') );

String sql = "select decode(grouping( to_char(writeday, 'yyyy-mm-dd') ), 0, to_char(writeday, 'yyyy-mm-dd'), '전체') AS WRITEDAY\n"+
"     , count(*) AS CNT\n"+
"from jdbc_board\n"+
"where to_char(writeday, 'yyyy-mm') = to_char(sysdate, 'yyyy-mm')\n"+
"group by rollup ( to_char(writeday, 'yyyy-mm-dd') )";



-- (ADMIN) 모든 회원정보 조회하기
select userseq, userid, name, mobile, point, to_char(registerday, 'yyyy-mm-dd') AS registerday
from jdbc_member
where userid != 'admin';

String sql = "select userseq, userid, name, mobile, point, to_char(registerday, 'yyyy-mm-dd') AS registerday\n"+
"from jdbc_member\n"+
"where userid != 'admin'";