package jdbc.day04.singletonPattern;

public class NoSingletonNumber {
	
	// 인스턴스 변수
	private int cnt = 0;
	
	// === 기본생성자 ===
	// public NoSingletonNumber() {} 이 생략되어짐.
	
	// 인스턴스 메소드 
	
	public int getNextNumber() {
		return ++cnt;	// 인스턴스 변수
	}// end of getNextNumber()
	
}
