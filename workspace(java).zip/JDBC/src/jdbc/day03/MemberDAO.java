package jdbc.day03;

import java.sql.*;
import java.util.Map;

// DAO(Database Access Obejct) ==> 데이터베이스에 연결하여 SQL구문을 실행시켜주는 객체

public class MemberDAO implements InterMemberDAO {
	
	// field, attribute, property, 속성을 정의한다.
	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;
	 
	
	
	// === 자원반납 메소드 === //
	private void close() {
		
		try {
			if( rs != null )    rs.close();
			if( pstmt != null ) pstmt.close();
			if( conn != null )  conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}// end of private void close()
	
	
	
	// === 회원가입(insert) 메소드 구현하기 ===
	@Override
	public int memberRegister(MemberDTO member) {
		int result = 0;
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			conn = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:xe", "HR", "cclass");
			
			String sql = " insert into jdbc_member(userseq, userid, passwd, name, mobile) "+
					     " values(userseq.nextval, ?, ?, ?, ?) ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, member.getUserid());
			pstmt.setString(2, member.getPasswd());
			pstmt.setString(3, member.getName());
			pstmt.setString(4, member.getMobile());
			// 회원가입 메소드에서 DTO에 넣어둔(set) 데이터들을 다시 가져온다(get)
			
			result = pstmt.executeUpdate();
			// 정상이라면 1, 비정상이라면 0 
			
		} catch (ClassNotFoundException e) {
			System.out.println(">> ojdbc6.jar 파일이 없습니다. <<");
		} catch (SQLException e) {
			
			if(e.getErrorCode() == 1) {
				System.out.println(">> 아이디가 중복되었습니다. 새로운 아이디를 입력하세요!! <<");
			}
			else {
				System.out.println(">> SQL구문 오류!! <<");
				e.printStackTrace();
			}
			
		}  finally {
			close();
		}
		
		
		
		
		return result;
	}// end of public int memberRegister(MemberDTO member) ------------------------


	// === 로그인처리(select) 메소드 구현하기 ===
	@Override
	public MemberDTO login(Map<String, String> paraMap) {
		
		MemberDTO member = null;
		
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			conn = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:xe", "HR", "cclass");
			
			String sql = " select name, to_char(registerday, 'yyyy-mm-dd') AS registerday, status "+
					     " from jdbc_member "+
					     " where userid = ? and passwd = ? ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setNString(1, paraMap.get("userid")); // 사용자가 입력한 ID --> Key값의 Value값이 나온다.
			pstmt.setNString(2, paraMap.get("passwd")); // 사용자가 입력한 PW --> Key값의 Value값이 나온다.
			
			rs = pstmt.executeQuery(); // 알맞은 아이디와 비밀번호를 넣었다면 행이 1개, 이상한거면 행이 0개
			
			if(rs.next()) {
				member = new MemberDTO();
				member.setName(rs.getString(1));
				member.setRegisterday(rs.getString(2));
				member.setStatus(rs.getInt(3));
			} 
			
		} catch (ClassNotFoundException e) {
			System.out.println(">> ojdbc6.jar 파일이 없습니다. <<");
		} catch (SQLException e) {
			System.out.println(">> SQL구문 오류!! <<");
			e.printStackTrace();
		}  finally {
			close();
		}
		
		return member;
	}// end of public MemberDTO login(Map<String, String> paraMap) ----------------
	
}
