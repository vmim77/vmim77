package jdbc.day02;



/*

>>>> Stored Procedure 란? <<<<<
Query 문을 하나의 파일형태로 만들거나 데이터베이스에 저장해 놓고 함수처럼 호출해서 사용하는 것임.
Stored Procedure 를 사용하면 연속되는 query 문에 대해서 매우 빠른 성능을 보이며, 
코드의 독립성과 함께 보안적인 장점도 가지게 된다.

create or replace procedure pcd_student_insert
(p_name   IN   jdbc_tbl_student.name%type
,p_tel    IN   jdbc_tbl_student.tel%type
,p_addr   IN   jdbc_tbl_student.addr%type
,p_fk_classno IN jdbc_tbl_student.fk_classno%type
)
is
begin
  insert into jdbc_tbl_student(stno, name, tel, addr, fk_classno) 
  values(jdbc_seq_stno.nextval, p_name, p_tel, p_addr, p_fk_classno);
end pcd_student_insert;
-- Procedure PCD_STUDENT_INSERT이(가) 컴파일되었습니다.

*/

import java.sql.*;
import java.util.Scanner;

public class Procedure_insert_CallableStatement_02 {

	public static void main(String[] args) {
		
		Connection conn = null;
		// Connection conn 은 오라클 데이터베이스 서버와 연결을 맺어주는 객체이다. 
		
		CallableStatement cstmt = null;
		// CallableStatement cstmt 은 Connection conn(특정 오라클 서버)에 존재하는 Procedure 를 호출할 객체(우편배달부)이다.  
		
		Scanner sc = new Scanner(System.in);
		
		int n_fk_classno = 0;
		try {
			
			
			// >>> 1. 오라클 드라이버 로딩 <<< //
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			// >>> 2. 어떤 오라클 서버에 연결을 할래? <<< //
			conn = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:xe", "HR", "cclass");
			
			// >>> 3. Connection conn 객체를 사용하여 prepareCall() 메소드를 호출함으로써 CallableStatement cstmt 객체를 생성한다. <<< //
			//		  CallableStatement cstmt 객체가 프로시저를 호출해주는 우편배달부 이다.
			cstmt = conn.prepareCall("{call pcd_student_insert(?,?,?,?)}");
			/*
			  	오라클 서버에서 생성한 프로시저 pcd_student_insert 의 매개변수 개수가 4개 이므로 ? 를 4개 준다. 
				
				프로시저의 IN mode 로 되어진 파라미터에 값을 넣어줄때는 cstmt.setXXX() 메소드를 사용한다.
			*/
			
			
			System.out.print("▷학생명 : ");
			String name = sc.nextLine();
			
			System.out.print("▷연락처 : ");
			String tel = sc.nextLine();
			
			System.out.print("▷주소 : ");
			String addr = sc.nextLine();
			
			System.out.print("▷학급번호 : ");
			String fk_classno = sc.nextLine();
			n_fk_classno = Integer.parseInt(fk_classno);
			
			cstmt.setString(1, name);
			cstmt.setString(2, tel);
			cstmt.setString(3, addr);
			cstmt.setInt(4, n_fk_classno);
			
			
			// >>> 4. CallableStatement cstmt 객체를 사용하여 오라클의 프로시저를 실행하기 <<< //
			int n = cstmt.executeUpdate(); // 오라클 서버에게 해당 프로시저를 실행해라는 것이다.
			// 프로시저의 실행은 cstmt.executeUpdate(); 또는 cstmt.execute(); 이다. 
			
			if(n == 1) {
				System.out.println(">>> 데이터 입력성공!! <<<");
			}
			
			
			
		} catch (ClassNotFoundException e) {
			System.out.println(">> ojdbc6.jar 파일이 없습니다. <<");
		} catch (SQLException e) {
			
			if(e.getErrorCode() == 2291) { // 이런 오라클 오류가 발생되어지면 다음과 같이해라
				System.out.println("\n>> 학급번호  "+ n_fk_classno + " 은 우리학교에 존재하지 않는 학급번호 입니다. 학급번호를 올바르게 입력하세요!! <<\n");
			}
			else {
				System.out.println(">> SQL구문 오류!! <<");
				e.printStackTrace();
			}
			
		} finally {
			try {
				if(cstmt != null)
					cstmt.close();
				if(conn != null)
					conn.close();
			} catch (SQLException e){
				e.printStackTrace();
			}
		}
		
		sc.close();
		System.out.println("\n~~~ 프로그램 종료 ~~~");
	}// end of main--------------------------------

}
