package jdbc.day02;

import java.sql.*;
import java.util.Scanner;

public class DML_insert_exception_PreparedStatement_01 {

	public static void main(String[] args) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		Scanner sc = new Scanner(System.in);
		
		int n_fk_classno = 0;
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver"); // 오라클 드라이버 로딩
			
			
			conn = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:xe", "HR", "cclass");
			
			conn.setAutoCommit(false); // 수동 commit 으로 전환
			
			System.out.print("▷학생명 : ");
			String name = sc.nextLine();
			
			System.out.print("▷연락처 : ");
			String tel = sc.nextLine();
			
			System.out.print("▷주소 : ");
			String addr = sc.nextLine();
			
			System.out.print("▷학급번호 : ");
			String fk_classno = sc.nextLine();
			n_fk_classno = Integer.parseInt(fk_classno);
			
			// 학번은 시퀀스, 가입일자는 default sysdate

			String sql = " insert into jdbc_tbl_student(stno, name, tel, addr, registerdate, fk_classno) "+
					     " values(jdbc_seq_stno.nextval, ?, ?, ?, default, ?) ";
			
			// conn(이 오라클 서버의) + .prepareStatement(전달해줄 우편부를) + (sql) (이 SQL문을 전달해줄 만든다.)
			pstmt = conn.prepareStatement(sql);
			
			// 위치홀더에 값을 넣어준다.
			pstmt.setString(1, name);
			pstmt.setString(2, tel);
			pstmt.setString(3, addr);
			pstmt.setInt(4, n_fk_classno);
			
			// 우편배달부가 오라클에서 DML문을 실행시킨다.
			int n = pstmt.executeUpdate();
			
			if(n == 1) { // DML문이 정상적으로 실행됐다면
				
				String yn = "";
				do {
					////////////////////////////////////////////////////
					System.out.print("▷ 정말로 입력하시겠습니까?[Y/N] : ");
					yn = sc.nextLine();
					
					if("y".equalsIgnoreCase(yn)) {
						conn.commit();
						System.out.println(">> 데이터 입력 성공!! <<");
					}
					else if("n".equalsIgnoreCase(yn)) {
						conn.rollback();
						System.out.println(">> 데이터 입력 취소!! <<");
					}
					
					else {
						System.out.println(">> Y 또는 N만 입력하세요!! <<\n");
					}
					////////////////////////////////////////////////////
				} while( !("y".equalsIgnoreCase(yn)|| "n".equalsIgnoreCase(yn)) );
				// !(탈출조건)
				// 탈출조건이 참이여야 전체가 거짓이되서 do~while을 탈출한다.
				
			}// end of if(n == 1)-----------------------------------
			
			
		} catch (ClassNotFoundException e) {
			System.out.println(">> ojdbc6.jar 파일이 없습니다. <<");
		} catch (SQLException e) {
			
			if(e.getErrorCode() == 2291) { // 이런 오라클 오류가 발생되어지면 다음과 같이해라
				System.out.println("\n>> 학급번호  "+ n_fk_classno + " 은 우리학교에 존재하지 않는 학급번호 입니다. 학급번호를 올바르게 입력하세요!! <<\n");
			}
			else {
				System.out.println(">> SQL구문 오류!! <<");
				e.printStackTrace();
			}
			
		} finally {
			try {
				if(pstmt != null)
					pstmt.close();
				
				if(conn != null)
					conn.close();
			} catch (SQLException e){
				e.printStackTrace();
			}
		}
		
		
		
		
		sc.close();
		System.out.println("\n~~~ 프로그램 종료 ~~~");
	}// end of main-------------------------------------------------

}
