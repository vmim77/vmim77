package jdbc.day02;
/*

create or replace procedure pcd_tbl_member_test1_insert
(p_userid    IN   tbl_member_test1.userid%type
,p_passwd    IN   tbl_member_test1.passwd%type
,p_name      IN   tbl_member_test1.name%type
)
is
  error_dayTime      exception;
  v_length           number(20);
  error_insert       exception;
  v_ch               varchar2(1);
  v_flag_alphabet    number(1) := 0;
  v_flag_number      number(1) := 0;
  v_flag_special     number(1) := 0;
  
begin
    
    -- 입력(insert)이 불가한 요일명과 시간대를 알아본다. --
    if( to_char(sysdate, 'd') in('1','7') OR        -- to_char(sysdate, 'd') ==> '1'(일), '2'(월), '3'(화), '4'(수), '5'(목), '6'(금), '7'(토)
        to_char(sysdate, 'hh24') < '09' OR to_char(sysdate, 'hh24') > '13'
    )  then raise error_dayTime;   
    
    
    else  
        v_length := length(p_passwd);
        
        if(v_length < 5 OR  v_length > 20) then
            raise  error_insert;   -- 사용자가 정의하는 예외절(EXCEPTION)을 구동시켜라.
        else
            for i in 1..v_length loop
                v_ch := substr(p_passwd, i, 1);
                
                if( (v_ch between 'a' and 'z') OR (v_ch between 'A' and 'Z') ) then  -- 영문자 이라면 
                    v_flag_alphabet := 1;
                elsif( v_ch between '0' and '9' ) then  -- 숫자 이라면 
                    v_flag_number := 1;
                else  -- 특수문자 이라면 
                    v_flag_special := 1;
                end if;
            end loop;
            
            if(v_flag_alphabet * v_flag_number * v_flag_special = 1) then
                 insert into tbl_member_test1(userid, passwd, name) values(p_userid, p_passwd, p_name);
            else  
                 raise error_insert;  -- 사용자가 정의하는 예외절(EXCEPTION)을 구동시켜라.
            end if;     
            
        end if;
        
    
    end if;
    
    
    
    exception  
        when error_dayTime then
            raise_application_error(-20003, '영업시간(월~금 09:00 ~ 13:59:59 까지) 아니므로 입력불가함!!');
        
        when  error_insert  then
              raise_application_error(-20002, '암호는 최소 5글자 이상이면서 영문자 및 숫자 및 특수기호가 혼합되어져야 합니다.');

end pcd_tbl_member_test1_insert; 

 */

import java.sql.*;
import java.util.Scanner;

public class Procedure_insert_exception_quiz_05 {

	public static void main(String[] args) {
		
		Connection conn = null;
		// Connection conn 은 오라클 데이터베이스 서버와 연결을 맺어주는 객체이다. 
		
		CallableStatement cstmt = null;
		// CallableStatement cstmt 은 Connection conn(특정 오라클 서버)에 존재하는 Procedure 를 호출할 객체(우편배달부)이다.  
		
		Scanner sc = new Scanner(System.in);
		
		String userid = "";
		
		try {
			// >>> 1. 오라클 드라이버 로딩 <<< //
			Class.forName("oracle.jdbc.driver.OracleDriver");
						
			// >>> 2. 어떤 오라클 서버에 연결을 할래? <<< //
			conn = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:xe", "HR", "cclass");
			
			// >>> 3. Connection conn 객체를 사용하여 prepareCall() 메소드를 호출함으로써 CallableStatement cstmt 객체를 생성한다. <<< //
			//		  CallableStatement cstmt 객체가 프로시저를 호출해주는 우편배달부 이다.
			cstmt = conn.prepareCall("{call pcd_tbl_member_test1_insert(?,?,?)}");
			
			System.out.print("▷아이디 : ");
			userid = sc.nextLine();
			
			System.out.print("▷비밀번호 : ");
			String passwd = sc.nextLine();
			
			System.out.print("▷이름 : ");
			String name = sc.nextLine();
			
			
			cstmt.setString(1, userid);
			cstmt.setString(2, passwd);
			cstmt.setString(3, name);
			
			int n = cstmt.executeUpdate();
			
			
			if(n == 1) {
				System.out.println(">>> 데이터 입력성공!! <<<");
			}
			
			
		} catch (ClassNotFoundException e) {
			System.out.println(">> ojdbc6.jar 파일이 없습니다. <<");
		} catch (SQLException e) {
			
				if(e.getErrorCode() == 20003) {
					System.out.println("\n>>> "+e.getMessage()+" <<<");
				}
				else if(e.getErrorCode() == 20002) {
					System.out.println("\n>>> "+e.getMessage()+" <<<");
				}
				else if(e.getErrorCode() == 1) {
					System.out.println("\n=== 아이디 " + userid + " 은 이미 사용중입니다. 다른 아이디로 가입하세요!! ===");
				}
				else {
					System.out.println(">> SQL구문 오류!! <<");
					e.printStackTrace();
				}
			
		} finally {
			try {
				if(cstmt != null)
					cstmt.close();
				if(conn != null)
					conn.close();
			} catch (SQLException e){
				e.printStackTrace();
			}
		}
		
		
		sc.close();
		System.out.println("\n~~~ 프로그램 종료 ~~~");
	}// end of main-------------------------------------

}
