package my.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class MyUtil {
	
	public static String addDay(int n) {
		
		Calendar currentDate = Calendar.getInstance();
		// 현재 날짜와 시간을 얻어온다.
		
		currentDate.add(Calendar.DATE, n);
		// currentDate.add(Calendar.DATE, 1); 
	    // ==> currentDate(현재 날짜)에서 두번째 파라미터에 입력해준 숫자(그 단위는 첫번째 파라미터인 것이다. 지금은 Calendar.DATE 이므로 날짜수이다)만큼 더한다.
	    // ==> 위의 결과는  currentDate 값이 1일 더한 값으로 변한다.   
		
		SimpleDateFormat sdateFmt = new SimpleDateFormat("yyyy-MM-dd");
		
		// Calendar타입인 currentDate를 currentDate.getTime()으로 Date로 바꿔서 sdateFmt.fomat에 사용한다.
		// 그러면 String 타입으로 변환된다.
		// sdateFmt.format()에는 Date타입만 들어올 수 있다.
		
		return sdateFmt.format(currentDate.getTime());
	}
	
}
