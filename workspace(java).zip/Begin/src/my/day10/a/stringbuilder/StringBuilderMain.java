package my.day10.a.stringbuilder;

public class StringBuilderMain {

	public static void main(String[] args) {

		
		
		String name = "일순신"; // 메모리상에 name 1개 소모
		// String은 변수선언 같지만, 클래스(객체)이다.
		
		name += ",이순신";    // 메모리상에 name 1개 소모
		name += ",삼순신";    // 메모리상에 name 1개 소모
		name += ",사순신";    // 메모리상에 name 1개 소모
		name += ",오순신";    // 메모리상에 name 1개 소모
		name += ",육순신";    // 메모리상에 name 1개 소모
		name += ",칠순신";    // 메모리상에 name 1개 소모
		name += ",팔순신";    // 메모리상에 name 1개 소모
		name += ",구순신";    // 메모리상에 name 1개 소모
		
							  // 누적되어진 메모리상의 name 은 9개가 소모된다고 한다.
							  // 이 방법은 메모리낭비가 심하여 권장치 않는다.
		
		System.out.println(name);
		// 일순신,이순신,삼순신,사순신,오순신,육순신,칠순신,팔순신,구순신
		
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		// StringBuffer sb = new StringBuffer();
		// 또는
		StringBuilder sb = new StringBuilder();
		// StringBuffer 와 StringBuilder 는 이름은 다르지만 사용하는 방법은 똑 같다.
		// StringBuffer 는 multi thread 를 지원해주므로 주로 게임프로그래밍에서 사용한다.
		// StringBuilder 는 multi thread 를 지원해주지 않기에 주로 웹프로그래밍에서 사용한다.
		// 그런데 StringBuffer 는 StringBuilder 보다 무거워서 빨리 동작하지 못한다. 
		// 그래서 웹프로그래밍이라면  StringBuilder 를 더 선호한다.
		
		sb.append("일순신");
		sb.append(",이순신"); // name += ",이순신"; 와 같다.
		sb.append(",삼순신");
		sb.append(",사순신");
		sb.append(",오순신");
		sb.append(",육순신");
		sb.append(",칠순신");
		sb.append(",팔순신");
		sb.append(",구순신");
		
		System.out.println(sb.toString()); // StringBuilder에 쌓여진 것들을 실제 String 타입으로 바꿔준다.
		// 일순신,이순신,삼순신,사순신,오순신,육순신,칠순신,팔순신,구순신
		
		// 결과물은 똑같지만, 위에는 메모리가 매 번 소모되지만, StringBuilder는 메모리 소모가 적다.
		 
		
		// StringBuilder를 만들어서 append로 StringBuilder에 쌓고, toString으로 String으로 바꿔서 출력한다.
		// 누적해줄게 2~3개 정도면 name+=",이순신"; 을 쓰는게 낫지만, 누적해줄게 엄청 많다면(ex. 배열, for문) StringBuilder를 쓰는게 좋다.
		// 무게 : StringBuffer > StringBuilder > String
		
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		// StringBuilder sb 의 초기화
		
		// sb = new StringBuilder();
		// 또는
		sb.setLength(0); // 길이를 0으로 하면 된다.
		
		sb.append("한정화");
		sb.append(",두정화");
		sb.append(",세정화");
		sb.append(",네정화");
		sb.append(",오정화");
		
		System.out.println(sb.toString());
		// "일순신,이순신,삼순신,사순신,오순신,육순신,칠순신,팔순신,구순신한정화,두정화,세정화,네정화,오정화" 가 아니라
		// "한정화,두정화,세정화,네정화,오정화" 가 나와야 한다.
		
		
		
	}// end of main(String[] args)----------------------------

}
