package my.day11.a.abstractionTeacher;

import java.util.Scanner;

public class GujikjaMainTeacher {

	public static void main(String[] args) {
		
		GujikjaTeacher[] guArr = new GujikjaTeacher[5];
		
		GujikjaTeacher gu1 = new GujikjaTeacher();
		gu1.userid = "eomjh";
		gu1.passwd = "qwer1234$A";
		gu1.name = "엄정화";
		
		String jubun = "9506302"; // null, "9506", "9506302234567", "abc30fg", "9513302", "9506312", "9506308" 
		                          // "9506301"  "9506302"
		
		if(gu1.isCheckJubun(jubun)) {
			gu1.jubun = jubun;
			
			guArr[GujikjaTeacher.count++] = gu1;
		}
		else {
			System.out.println(">>> "+jubun+"은 잘못된 주민번호 7자리 앞자리 입니다. <<<");
		}
		
		
		GujikjaTeacher gu2 = new GujikjaTeacher();
		gu2.userid = "leess";
		gu2.passwd = "qwer1234$A";
		gu2.name = "이순신";
		
		jubun = "9407011"; 
		
		if(gu2.isCheckJubun(jubun)) {
			gu2.jubun = jubun;
			
			guArr[GujikjaTeacher.count++] = gu2;
		}
		else {
			System.out.println(">>> "+jubun+"은 잘못된 주민번호 7자리 앞자리 입니다. <<<");
		}
		
		
		GujikjaTeacher gu3 = new GujikjaTeacher();
		gu3.userid = "youks";
		gu3.passwd = "qwer1234$A";
		gu3.name = "유관순";
		
		jubun = "9603012"; 
		
		if(gu3.isCheckJubun(jubun)) {
			gu3.jubun = jubun;
			
			guArr[GujikjaTeacher.count++] = gu3;
		}
		else {
			System.out.println(">>> "+jubun+"은 잘못된 주민번호 7자리 앞자리 입니다. <<<");
		}
		
		////////////////////////////////////////////////////////
		
		Scanner sc = new Scanner(System.in);
		String smenuNo = "";
		
		GujikjaCtrlTeacher ctrl = new GujikjaCtrlTeacher();
		
		do {
			
			System.out.println("\n >>> === 메인메뉴 === <<< \n"
			         + "1.구직자 회원가입   2.구직자 모두 보기  3.검색   4.프로그램 종료 \n");
	
			System.out.print("▷ 메뉴번호 선택 => "); 
			smenuNo = sc.nextLine();
			
			switch (smenuNo) {
				case "1": // 구직자 회원가입
					boolean result = ctrl.register(sc, guArr); 
					
					if(result) {
						System.out.println(">> 회원가입 성공!! \n");
					}
					
					break;   // switch 의 break; 이다	
				
					
				case "2": // 구직자 모두 보기
					ctrl.showAll(guArr);
					
					break;	 // switch 의 break; 이다	
					
				case "3": // 검색
					searchMenu(sc);
					
					break;   // switch 의 break; 이다	
					
				case "4": // 프로그램 종료
					
					break;	 // switch 의 break; 이다			
	
				default:  
					System.out.println("\n>> 메뉴에 없는 번호 입니다. <<\n");
					break;   // switch 의 break; 이다	
			}// end of switch-----------------------
			
		} while (!("4".equals(smenuNo)));
				
		
		sc.close();
		
		System.out.println("\n~~~~~ 프로그램 종료 ~~~~~~");

	}// end of main(String[] args)------------------------
	
	
	
	
	static void searchMenu(Scanner sc) {
		
		String sMenuNo = "";
		
		do {
		
			System.out.println("\n ==== *** 검색메뉴 *** ==== \n"
			                + "1.연령대검색   2.성별검색   3.연령대및성별검색   4.메인으로 돌아가기\n");
			
			System.out.print("▷ 검색메뉴번호 선택 => ");
			sMenuNo = sc.nextLine();
			
			switch (sMenuNo) {
				case "1":  // 연령대검색
					
					break; // switch 문의 break; 이다.
					
				case "2":  // 성별검색
					
					break; // switch 문의 break; 이다. 
					
				case "3":  // 연령대및성별검색
					
					break; // switch 문의 break; 이다.
					
				case "4":  // 메인으로 돌아가기
					
					break;	// switch 문의 break; 이다.
		
				default:
					System.out.println("\n>> 메뉴에 없는 번호 입니다. <<\n");
					break; // switch 문의 break; 이다.
			}// end of switch (sMenuNo)--------------
		
		} while(!("4".equals(sMenuNo)));
		
		
	} // end of static void searchMenu()----------------------
	

}
