package my.day11.a.abstractionTeacher;

import java.util.Scanner;

import my.util.MyUtil;

public class GujikjaCtrlTeacher {

	// == 구직자(Gujikja) 신규 회원가입을 해주는 메소드 생성하기 == 
	boolean register(Scanner sc, GujikjaTeacher[] guArr) {
		
		boolean result = false;
		
		if( GujikjaTeacher.count < guArr.length) {
		
			GujikjaTeacher gu = new GujikjaTeacher();
			
			// == 아이디 중복검사 하기 == //
			do {
				System.out.print("1. 아이디 : ");  
				String userid = sc.nextLine(); 
				// 그냥엔터 ""     "      "
				// "youks"  "eomjh"  "leess"    "seokj"
				
				if( userid != null && userid.trim().isEmpty() ) {
					System.out.println("\n>> 아이디는 공백만으로는 될 수가 없습니다.<<\n"); 
					continue;
				}
				
				boolean isDuplicate = false; 
				
			    for(int i=0; i<GujikjaTeacher.count; i++) {
			    	
			    	if(guArr[i].userid.equals(userid)) {
			    		isDuplicate = true;
			    		break;
			    	}
			    	
			    }// end of for-------------------
			    
			    if(isDuplicate) {
			    	System.out.println("\n>> "+userid+"는 이미 사용중 입니다. 새로운 아이디를 입력하세요!! <<\n");     
			    }
			    else {
			    	gu.userid = userid;
			    	break;
			    }
		    
			} while(true);
		    
			
			do {
				System.out.print("2. 암호 : ");
				String passwd = sc.nextLine();
				
				if( !MyUtil.isCheckPasswd(passwd) ) 
					System.out.println("\n>> 암호는 8글자 이상 15글자 이하의 대문자,소문자,숫자,특수기호가 혼합되어야만 합니다. <<\n"); 
				
				else {
					gu.passwd = passwd;
					break;
				}
			} while(true);
						
			
			do {
				System.out.print("3. 성명 : ");
				String name = sc.nextLine();
				// 그냥엔터 ""   "          "
				
				if(name != null && name.trim().isEmpty()) {
					System.out.println("\n>> 성명은 공백만으로 될 수가 없습니다. <<\n");   
				}
				else {
					gu.name = name;
					break;
				}
			} while(true);
			
			
			do {
				System.out.print("4. 주민번호 앞의 7자리만 : ");
				String jubun = sc.nextLine();
				
				if(gu.isCheckJubun(jubun)) {
					gu.jubun = jubun;
					break;
				}
				else {
					System.out.println(">>> "+jubun+"은 잘못된 주민번호 7자리 앞자리 입니다. <<<");
				}
			} while(true);
			
			
			guArr[GujikjaTeacher.count++] = gu;
			result = true;
			
		} // end of if-----------------------
		
		else {
			System.out.println("\n>>> 구직자 정원마감으로 신규회원 가입은 불가합니다. <<<\n");
		}
		
		return result;
		
	}

	
	// === 구직자 모두 보기 ===
	public void showAll(GujikjaTeacher[] guArr) {
		
		for(int i=0; i<GujikjaTeacher.count; i++) {
			System.out.println(guArr[i].showInfo()); 
		}
		
	}

	
	 
	
	
}
