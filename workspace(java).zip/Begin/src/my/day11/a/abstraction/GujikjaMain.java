package my.day11.a.abstraction;

import java.util.Scanner;

public class GujikjaMain {

	public static void main(String[] args) {

		Gujikja[] guArr = new Gujikja[5]; // Gujikja 타입의 값(구직자의 필드 값들) 5개를 저장할 수 있는 배열
										  // 배열 또한 객체이다.
		
		Gujikja gu1 = new Gujikja(); // Gujikja 인스턴스를 생성한 후, 생성된  Gujikja인스턴스 주소를 gu1에 저장
									 // gu1을 통하여 Gujikja에 생성된 필드와 메서드를 호출할 수 있다.
		gu1.userid = "eomjh";
		gu1.passwd = "qwer1234$A";
		gu1.name = "엄정화";
		
		String jubun = "9506302";// 9506, 9506302234567, abc30fg, 951303, 951200
		
		if(gu1.isCheckJubun(jubun)) { // true이면 올바른 주번이니, 필드에 넣어준다.
			gu1.jubun = jubun;
			
			guArr[Gujikja.count++] = gu1; // 주민번호가 규칙까지 올바르면 0번 방에 넣어주고, count를 1 증가시킨다.
		}
		else { 
			System.out.println(">>> " + jubun + "은 잘못된 주민번호 7자리 앞자리 입니다. <<<");
		}
		
		Gujikja gu2 = new Gujikja();
		gu2.userid = "leess";
		gu2.passwd = "qwer1234$A";
		gu2.name = "이순신";
		
		jubun = "9407011";
		
		if(gu2.isCheckJubun(jubun)) { 
			gu2.jubun = jubun;
			
			guArr[Gujikja.count++] = gu2; // 주민번호가  규칙까지 올바르면 1번 방에 넣어주고, count를 1 증가시킨다.
		}
		else { 
			System.out.println(">>> " + jubun + "은 잘못된 주민번호 7자리 앞자리 입니다. <<<");
		}
		
		Gujikja gu3 = new Gujikja();
		gu3.userid = "youks";
		gu3.passwd = "qwer1234$A";
		gu3.name = "유관순";
		
		jubun = "8603012";
		
		if(gu3.isCheckJubun(jubun)) { 
			gu3.jubun = jubun;
			
			guArr[Gujikja.count++] = gu3; // 주민번호가  규칙까지 올바르면 2번 방에 넣어주고, count를 1 증가시킨다.
		}
		else { 
			System.out.println(">>> " + jubun + "은 잘못된 주민번호 7자리 앞자리 입니다. <<<");
		}
		
		///////////////////////////////////////////////////////////////////////////////////////
		
		Scanner sc = new Scanner(System.in);
		String smenuNo = "";
		
		GujikjaCtrl ctrl = new GujikjaCtrl(); // GujikjaCtrl에 설계된 기능과 필드를 사용할 수 있는 인스턴스를 생성한다.
		
		
		do {
			
			System.out.println("\n >>> === 메인메뉴 ===  <<< \n"
					+ "1.구직자 회원가입   2.구직자 모두 보기  3.검색   4.프로그램 종료 \n");

			System.out.print("▷ 메뉴번호 선택 => "); 
			smenuNo = sc.nextLine();
			
			switch (smenuNo) {
			case "1": // 구직자 회원가입
				
				boolean result = ctrl.register(sc, guArr);  // GujikjaCtrl에 설계된 메소드를 호출하여 사용한다.
										  
				// GujikjaMain의 콘솔에서 입력된 스캐너 값(ID, PWD, 이름, 주민번호)들이 GujikjaCtrl 인스턴스로 넘겨서 가공이 된다.
				// 지금까지 GujikjaMain에서 사용된 guArr의 값들도 넘겨줌 (여기서 guArr과 GujikjaCtrl의 guArr은 서로 연결된 것)
				// 그리고 GujikjaCtrl에서 처리된 내용들이 guArr에 담겨짐 ( 메모리주소값을 복사해서 줬으니 내용 변경이 가능하다. )
				
				if(result) {
					System.out.println(">> 회원가입 성공 !! \n");
				}
				

				break; // switch 의 break 이다.
				
			case "2": // 구직자 모두 보기
				ctrl.showAll(guArr);
				
				break; // switch 의 break 이다.
				
			case "3": // 검색
				searchMenu(sc, ctrl, guArr);
				
				break; // switch 의 break 이다.
				
				
			case "4": // 프로그램 종료
				
				break; // switch 의 break 이다.
				
			default : 
				System.out.println("\n>> 메뉴에 없는 번호 입니다. <<\n");
				
				break; // switch 의 break 이다.
				
			}// end of switch ---------------------------------------
			
		} while (!("4".equals(smenuNo))); // 4번을 누르면 do~while을 빠져나와라
		
		
		
		sc.close();
		System.out.println("\n~~~~~ 프로그램 종료 ~~~~~ \n");

		

		
	}// end of main(String[] args)---------------------------------------------------

	
	static void searchMenu(Scanner sc, GujikjaCtrl ctrl, Gujikja[] guArr) {
		// 얘는 스캐너값과 컨트롤러에서의 검색 메소드, 저장장소들을 넘겨받는다.
		
		String sMenuNo = "";
		
		do {
			System.out.println("\n *** ====== 검색메뉴 ====== *** \n"
							+ "1.연령대검색   2.성별검색   3.연령대및성별검색   4.메인으로 돌아가기\n");
			
			System.out.print("▷ 검색메뉴번호 선택 => ");
			sMenuNo = sc.nextLine();
			
			switch (sMenuNo) {
			case "1" : // 연령대검색
				do {
					try {
						System.out.print("▷ 연령대 => ");
						
						// 20엔터 나이가 20세 부터 29세 까지 모두 보여라
						// 30엔터 나이가 30세 부터 39세 까지 모두 보여라
						
						String sAgeline = sc.nextLine();
						int ageline = Integer.parseInt(sAgeline); // 정상 0 10 20 30 40 50 60 70
																  // 비정상 7 80 90 100 24 38
						
						if( ageline%10 == 0 && (0 <= ageline && ageline <= 70) ) {// ageline은 10의 배수이면서, 0~70까지만
							// 정상인 경우
							ctrl.search(ageline, guArr);
							// 여기서 입력받은 연령대와 연령대를 기반으로 찾아야 할 정보들을 컨트롤러에 넘겨주는 것이다.
							// guArr 에서 ageline 연령대에 해당하는 구직자 찾아보기
							
							break; // do~while 의 break
						}
						else { 
							// 비정상인 경우
							System.out.println("\n>> 검색할 수 없는 연령대 입니다.!!\n");
							
						}
						
					} catch(NumberFormatException e) {
						System.out.println("\n>> 정수만 입력하세요 !! <<\n");
					}
				} while(true);
				
				break;
				
			case "2" : // 성별검색
				
				// 남자냐 여자냐를 찾겠다. 컨트롤러에게 보낸다.
				
				do {
				
					System.out.print("▷ 성별[남/여] => ");
											
					String gender = sc.nextLine();
					// 정상 gender ==> "남" "여" "남 " " 여"
					// 비정상 gender ==> "남" 또는 "여" 를 제외한 나머지
					
					gender = gender.trim();
					
					if("남".equals(gender) || "여".equals(gender)) {
						ctrl.search(gender, guArr);
						break; // do~while의 break
					}
					else {
						System.out.println("\n>> 남 또는 여 만 입력하세요!! <<\n");
					}
						
				} while(true);
				
				
				break;
				
			case "3" : // 연령대및성별검색
				// 20대 중에 남자, 30대 중에 여자
				do {
					try {
						System.out.print("▷ 연령대 => ");
						
						String sAgeline = sc.nextLine();
						int ageline = Integer.parseInt(sAgeline); 
																  
						if( ageline%10 == 0 && (0 <= ageline && ageline <= 70) ) {
							String gender = "";
							do {
								System.out.print("▷ 성별[남/여] => ");
								gender = sc.nextLine();
								
								if("남".equals(gender.trim()) || "여".equals(gender.trim())) {
									break; // 가장 가까운 do~while 문을 빠져나가는 break
								}
								else {
									System.out.println("\n>> 남 또는 여 만 입력하세요!! <<\n");
								}
							} while(true);// end of do~while-----------------------------
						
							ctrl.search(ageline, gender, guArr);
							break; // 바깥쪽 do~while 문을 빠져 나간다.
						}
						else { 
							System.out.println("\n>> 검색할 수 없는 연령대 입니다.!!\n");
						}
						
					} catch(NumberFormatException e) { // 문자열, 실수형이 들어오면 여기로 온다.
						System.out.println("\n>> 정수만 입력하세요 !! <<\n");
					}
				} while(true);// end of do~while-----------------------------
				
				break;
				
			case "4" : // 메인으로 돌아가기
				
				break; // switch 문의 break
			
	
			default:
				System.out.println("\n>> 메뉴에 없는 번호 입니다. <<\n");
				break;
			}// end of switch (sMenuNo) -----------------------------------
			
		} while(!("4".equals(sMenuNo)));
		
	} // end of static void searchMenu()-------------------------------------

}