package my.day11.a.abstraction;

import java.util.Scanner;

import my.util.MyUtil;

public class GujikjaCtrl {
	
	// == 구직자(Gujikja) 신규 회원가입을 해주는 메소드 생성하기 ==  
	
	boolean register(Scanner sc, Gujikja[] guArr) { 
		// GujikjaMain에서 입력받아진 스캐너값과 GujikjaMain에서 그동안 사용된 guArr을 넘겨 받아온다.
		
		boolean result = false;
		
		
		if(Gujikja.count < guArr.length) { // 배열에 빈 칸이 남았는지 확인해보고 count가 guArr의 길이보다 작아야 정보를 넣을 수 있게 해줘야 한다.
			
			Gujikja gu = new Gujikja(); // Gujikja에서 설계한 필드들과 메소드를 사용하기 위해서 선언한 것이다.
			
			
			// == 아이디 중복검사를 해주는 메소드 생성 == ////////////////////////////////////////////////////
			do {
				
				System.out.print("1.  아이디 : ");
				String userid = sc.nextLine(); // 이걸 for 안에 넣으면, 제대로 아이디를 썼어도 다시 입력하라는 메세지가 나온다.
				// 그냥엔터 => "",  "     "
				// "youks", "eomjh", "leess" (X)  "seokj" (O)
				
				
				if( userid != null && userid.trim().isEmpty()) {
					// 유저 아이디가 null이 아닌데, 텅 비었으면
					System.out.println("\n>> 아이디는 공백만으로는 될 수가 없습니다. <<\n");
					continue; // while(조건식)으로 보내서 다시 입력하도록 한다.
				}
				
				
				boolean isDuplicate = false; // 아이디가 중복이라면 true로 바꾼다.
				for(int i=0; i<Gujikja.count; i++) { //null과 비교해봐야 nullpointerexception이 뜨기 때문에 배열에 저장된 갯수만큼 비교해야 한다.
					
					if(guArr[i].userid.equals(userid)) {
						isDuplicate = true;
						break;
					}
	
				}// end of for----------------------
				
				if(isDuplicate) { // 중복됐으면 다시 위로 올려서 아이디값을 입력받아야 한다.
					System.out.println("\n>> 당신이 입력하신 "+userid+"는 이미 사용중 입니다. 새로운 아이디를 입력하세요!! <<\n");
				}
				else { // 중복이 없는 아이디를 입력한 경우
					gu.userid = userid;
					break; // 제대로 했으니 while문을 빠져나가게 해준다.
				}
			} while(true);
			// == 아이디 중복검사를 해주는 메소드 생성 == /////////////////////////////////////////////////
			
			
			// == 패스워드가 정책에 맞는지 검사 == ///////////////////////////////////////////
			do {
				System.out.print("2.  암호 : ");
				String passwd = sc.nextLine();
				
				if( !MyUtil.isCheckPasswd(passwd) ) { // 패스워드가 정책에 맞지 않는다면
					System.out.println("\n>> 암호는 8글자 이상 15글자 이하의 대문자,소문자,숫자,특수기호가 혼합되어야만 합니다. <<\n");
				}
				else { // 패스워드가 정책에 맞다면 넘겨준다.
					gu.passwd = passwd;
					break;
				}
			} while(true);
			// == 패스워드가 정책에 맞는지 검사 == ///////////////////////////////////////////
			
			// == 이름에 공백이나 그냥 엔터를 못치게 한다. == ///////////////////////////////
			do {
				System.out.print("3.  성명 : ");
				String name = sc.nextLine();
				if(name != null && name.trim().isEmpty()) {
					// 입력받은 이름이 null이 아니면서, 공백을 다 제거한 다음에 텅비었다면
					System.out.println("\n>> 성명은 공백만으로 될 수 없습니다. <<\n");
				}
				else { // 입력받은 이름이 null이 아니면서, 제대로 입력됐다면 나가게 한다.
					gu.name = name;
					break;
				}
			} while(true);
			// == 이름에 공백이나 그냥 엔터를 못치게 한다. == ///////////////////////////////
			
			
			do {
				System.out.print("4.  주민번호 앞의 7자리만 : "); // 올바르게 넣을 때까지 반복시키기 위해서 do~while 무한반복을 시킨다.
				String jubun = sc.nextLine();
				
				if(gu.isCheckJubun(jubun)) {
					gu.jubun = jubun;
					break; // 입력한 주민번호가 7자리이면서 문제가 없어야 do~while을 빠져나간다.
				}
				else {
					System.out.println(">>> " + jubun + "은 잘못된 주민번호 7자리 앞자리 입니다. <<<");
				}
			} while (true); // end of do~while----------------------------------------
			
			
			
			// 이제 올바르게 입력받은 정보들을 배열 속에 넣어줘야 한다.
			
			guArr[Gujikja.count++] = gu; // gu에 입력받은 정보들이 담겨져 있다.(아이디, 비번, 이름, 주민번호)
			// guArr[3]에 넣어짐
			
			result = true;
			
			
			// 지금까지 GujikjaMain에서 사용된 guArr에 추가저장하여서 내보내려고 파라미터로 선언한 것이다. (서로 연결을 시키기 위해서)
 		
		}// end of if--------------------------------------------		
		
		// 메인메소드에서 입력받아진 스캐너값들을 Gujikja 인스턴스에 넣는다. 그 후에 그 인스턴스를 guArr 배열에 저장시킨다. 

		
		
		else {
			System.out.println("\n>>> 구직자 정원마감으로 신규회원 가입은 불가합니다. <<<\n");
			
			
		}
		return result;
	}
	
	// === 구직자 모두 보기 ===
	void showAll(Gujikja[] guArr) {
		
		for(int i=0; i<Gujikja.count; i++) {
			System.out.println(guArr[i].showInfo()); 
		}
		
	}// end of svoid showAll(Gujikja[] guArr) ------------------------------------
	
	
	
	
	// ageline 연령대에 해당하는 구직자 찾아보기
	void search(int ageline, Gujikja[] guArr) {
		
		boolean isExists = false;
		
		for(int i=0; i<Gujikja.count; i++) {
			if(guArr[i].getAge()/10*10 == ageline) {  // 내 나이가 20 24 29 이건                   => 20이 되야함
													  // 20/10*10 24/10*10 29/10*10  => 20
			
				
				isExists = true; // 내가 찾고자 하는 연령대의 정보가 있다면 배열에 있다면 true를 반환
				
				System.out.println(guArr[i].showInfo()); // 내 나이가 찾고자하는 연령대와 구직자가 같다면 정보를 출력
			}

		}// end of for-------------------
		
		if(!isExists) {
			System.out.println("\n>> 검색하신 연령대 "+ageline +"대는 없습니다.<<\n");
		}
		
	}// end of void search(int ageline, Gujikja[] guArr)-------------------------------
	
	
	
	
	// !!!! === method 의 overloading(메소드의 오버로딩) === !!!! //
	// ==> method 의 이름이 같더라도 
	//     파라미터의 개수나 또는 순서, 타입이 다르면 서로 다른 method 로 인식한다.
	
	
	// === 성별로 구직자 찾아보기 ===

	   void search(String gender, Gujikja[] guArr) {
	      
	      for(int i=0; i<Gujikja.count; i++) {
	      
	         String n_gender = guArr[i].jubun.substring(6);
	         //     "1"   "2"   "3"   "4"
	         
	         if("남".equals(gender)) { // "남"을 검색했는데
	            if("2".equals(n_gender) || "4".equals(n_gender)) { // 꺼낸 구직자가 "여"이면
	               continue; // 그 다음 사람을 검색한다.
	            }
	            else { // 꺼낸 사람도 "남"이면 그 구직자의 정보를 출력
	               System.out.println(guArr[i].showInfo());
	            }
	         }
	         else { // "여"를 검색했는데
	            if("1".equals(n_gender) || "3".equals(n_gender)) { // "꺼낸 구직자가 "남"이면
	               continue; // 그 다음 사람을 검색한다.
	            }
	            else { // 꺼낸 사람도 "여"이면 그 구직자의 정보를 출력
	               System.out.println(guArr[i].showInfo());
	            }
	         }
	         
	      }// end of for----------------------
	            
	   }// end of void search(String gender, Gujikja[] guArr)-------------------------------
	   
	   
	   
	// === 특정 연령대에 해당하는 회원중 특정 성별 회원만 출력해주기 메소드 생성 === //   
	void search(int ageline, String gender, Gujikja[] guArr) {
		for(int i=0; i<Gujikja.count; i++) {
			
			if( ageline != guArr[i].getAge()/10*10 ) { // 일단 연령대가 안 맞으면 다음 사람을 찾아온다.
				continue;
			}
			else { // 내가 찾고자하는 연령대와 가져온 구직자의 연령대가 똑같으면 
				String n_gender = guArr[i].jubun.substring(6); // 그 사람의 주민번호 끝자리를 가져온다.
				// "1" "2" "3" "4"
		
				if("남".equals(gender)) { // 내가 성별 선택을 "남"을 했는데
					if("1".equals(n_gender)||"3".equals(n_gender)) {// 가져온 구직자의 주민번호 끝자리도 "남"이라면
						System.out.println(guArr[i].showInfo()); // 연령대와 성별도 맞으니 그 구직자의 정보를 출력한다.
					}
				}
				else { // 성별 선택을 "여"를 했는데
					if("2".equals(n_gender)||"4".equals(n_gender)) {// 가져온 구직자의 주민번호도 "여"이라면
						System.out.println(guArr[i].showInfo());
					}
				}
			}
		}// end of for-------------------
		
	}// end of void search(int ageline, String gender, Gujikja[] guArr)------------------------
		
}
	

