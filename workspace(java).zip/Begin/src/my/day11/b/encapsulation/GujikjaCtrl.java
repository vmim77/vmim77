package my.day11.b.encapsulation;

import java.util.Scanner;

public class GujikjaCtrl {
	
	// == 구직자(Gujikja) 신규 회원가입을 해주는 메소드 생성하기 ==  
	
	boolean register(Scanner sc, Gujikja[] guArr) { 
		// GujikjaMain에서 입력받아진 스캐너값과 GujikjaMain에서 그동안 사용된 guArr을 넘겨 받아온다.
		
		boolean result = false;
		
		
		if(Gujikja.count < guArr.length) { // 배열에 빈 칸이 남았는지 확인해보고 count가 guArr의 길이보다 작아야 정보를 넣을 수 있게 해줘야 한다.
			
			Gujikja gu = new Gujikja(); // Gujikja에서 설계한 필드들과 메소드를 사용하기 위해서 선언한 것이다.
			
			
			// == 아이디 중복검사 == //
			do {
				System.out.print("1.  아이디 : ");
				String userid = sc.nextLine(); // 이걸 for 안에 넣으면, 제대로 아이디를 썼어도 다시 입력하라는 메세지가 나온다.
				// 그냥엔터 => "",  "     "
				// "youks", "eomjh", "leess", "seokj", "kang#$"
				
				
				gu.setUserid(userid);
				
				if(gu.getUserid() == null) { // 잘못들어온 케이스라면 다시 반복시킨다.
					continue;
				}
					
				boolean isDuplicate = false; // 제대로 입력한 아이디를 검사해서 중복이라면 true를 준다.
				
				for(int i=0; i<Gujikja.count; i++) { //null과 비교해봐야 NullPointerException이 뜨기 때문에 배열에 저장된 갯수만큼 비교해야 한다.
					
					if(guArr[i].getUserid().equals(userid)) {
						isDuplicate = true;
						break;
					}
	
				}// end of for----------------------
				
				if(isDuplicate) { // 중복됐으면 다시 위로 올려서 아이디값을 입력받아야 한다.
					System.out.println("\n>> 당신이 입력하신 "+userid+"는 이미 사용중 입니다. 새로운 아이디를 입력하세요!! <<\n");
				}
				else { // 중복이 없는 아이디를 입력한 경우
					gu.setUserid(userid);
					break; // 제대로 했으니 while문을 빠져나가게 해준다.
				}
			} while(true);
			
			
			// == 패스워드가 정책에 맞는지 검사 == //
			do {
				System.out.print("2.  암호 : ");
				String passwd = sc.nextLine();
				
				gu.setPasswd(passwd); // 정책에 안맞으면 안 들어가고, getPasswd()는 null값이 된다.
				
				if( gu.getPasswd() != null ) { // 잘못 입력됐다고 메세지도 안 떳고, 들어간 값이 null이 아니면 정상이다.
					break;
				}

			} while(true);
			
			
			// == 이름에 공백이나 그냥 엔터를 못치게 한다. == //
			do {
				System.out.print("3.  성명 : ");
				String name = sc.nextLine();
				
				gu.setName(name);
				
				if(gu.getName() != null) { // 잘못 입력됐다고 메세지도 안 떳고, 들어간 값이 null이 아니면 정상이다.
					break;
				}
				
			} while(true);

			
			
			do {
				System.out.print("4.  주민번호 앞의 7자리만 : "); // 올바르게 넣을 때까지 반복시키기 위해서 do~while 무한반복을 시킨다.
				String jubun = sc.nextLine();
				
				gu.setJubun(jubun);
				
				if(gu.getJubun()!= null) {// 제대로 주민번호를 넣었다면 null이 아니다.
					break;
				}
				
			} while (true); // end of do~while----------------------------------------
			
			do {
				System.out.print("5.  연락처 : "); 
				String mobile = sc.nextLine();
				
				gu.setMobile(mobile);
				
				if(gu.getMobile()!= null) {
					break;
				}
				
			} while (true); // end of do~while----------------------------------------
			
			do {
				System.out.print("6.  희망급여 : "); 
				String str_hopeMoney = sc.nextLine(); // String 타입으로 받아왔지만, setHopeMoney는 int로 들어가야한다.
				
				try {
					gu.setHopeMoney(Integer.parseInt(str_hopeMoney)); // 여기는 Exception을 유발시킨다.
					
					if(1000 <= gu.getHopeMoney() && gu.getHopeMoney() <= 9999)  { // getHopeMoney의 초기값은 null이 아닌 0이여서 이렇게 조건을 설정한다.
						break;
					}
					
					
				} catch(NumberFormatException e) {
					System.out.println("\n>>  정수만 입력 가능합니다.!! <<\n");
				}
				
			} while (true); // end of do~while----------------------------------------
			
			
			
			
			// 이제 올바르게 입력받은 정보들을 검사하고 배열 속에 넣어줘야 한다.
			if(checkGujikja(gu)) { // 그동안 gu 인스턴스에 입력한 필드값들을 한 번더 확인해서 null값이 하나도 없다면
								   // 배열에 값들을 넣어준다.
 				
				guArr[Gujikja.count++] = gu;
				result = true;
			}
			// 지금까지 GujikjaMain에서 사용된 guArr에 추가저장하여서 내보내려고 파라미터로 선언한 것이다. (서로 연결을 시키기 위해서)
 		
		}// end of if--------------------------------------------		
		
		// 메인메소드에서 입력받아진 스캐너값들을 Gujikja 인스턴스에 넣는다. 그 후에 그 인스턴스를 guArr 배열에 저장시킨다. 

		
		
		else {
			System.out.println("\n>>> 구직자 정원마감으로 신규회원 가입은 불가합니다. <<<\n");
			
			
		}
		return result;
	}
	
	// === 구직자 모두 보기 ===
	void showAll(Gujikja[] guArr) {
		
		for(int i=0; i<Gujikja.count; i++) {
			System.out.println(guArr[i].showInfo()); 
		}
		
	}// end of svoid showAll(Gujikja[] guArr) ------------------------------------
	
	
	
	
	// ageline 연령대에 해당하는 구직자 찾아보기
	void search(int ageline, Gujikja[] guArr) {
		
		boolean isExists = false;
		
		for(int i=0; i<Gujikja.count; i++) {
			if(guArr[i].getAge()/10*10 == ageline) {  // 내 나이가 20 24 29 이건                   => 20이 되야함
													  // 20/10*10 24/10*10 29/10*10  => 20
			
				
				isExists = true; // 내가 찾고자 하는 연령대의 정보가 있다면 배열에 있다면 true를 반환
				
				System.out.println(guArr[i].showInfo()); // 내 나이가 찾고자하는 연령대와 구직자가 같다면 정보를 출력
			}

		}// end of for-------------------
		
		if(!isExists) {
			System.out.println("\n>> 검색하신 연령대 "+ageline +"대는 없습니다.<<\n");
		}
		
	}// end of void search(int ageline, Gujikja[] guArr)-------------------------------
	
	
	
	
	// !!!! === method 의 overloading(메소드의 오버로딩) === !!!! //
	// ==> method 의 이름이 같더라도 
	//     파라미터의 개수나 또는 순서, 타입이 다르면 서로 다른 method 로 인식한다.
	
	
	// === 성별로 구직자 찾아보기 ===

	   void search(String gender, Gujikja[] guArr) {
	      
	      for(int i=0; i<Gujikja.count; i++) {
	      
	         String n_gender = guArr[i].getJubun().substring(6);
	         //     "1"   "2"   "3"   "4"
	         
	         if("남".equals(gender)) { // "남"을 검색했는데
	            if("2".equals(n_gender) || "4".equals(n_gender)) { // 꺼낸 구직자가 "여"이면
	               continue; // 그 다음 사람을 검색한다.
	            }
	            else { // 꺼낸 사람도 "남"이면 그 구직자의 정보를 출력
	               System.out.println(guArr[i].showInfo());
	            }
	         }
	         else { // "여"를 검색했는데
	            if("1".equals(n_gender) || "3".equals(n_gender)) { // "꺼낸 구직자가 "남"이면
	               continue; // 그 다음 사람을 검색한다.
	            }
	            else { // 꺼낸 사람도 "여"이면 그 구직자의 정보를 출력
	               System.out.println(guArr[i].showInfo());
	            }
	         }
	         
	      }// end of for----------------------
	            
	   }// end of void search(String gender, Gujikja[] guArr)-------------------------------
	   
	   
	   
	// === 특정 연령대에 해당하는 회원중 특정 성별 회원만 출력해주기 메소드 생성 === //   
	void search(int ageline, String gender, Gujikja[] guArr) {
		for(int i=0; i<Gujikja.count; i++) {
			
			if( ageline != guArr[i].getAge()/10*10 ) { // 일단 연령대가 안 맞으면 다음 사람을 찾아온다.
				continue;
			}
			else { // 내가 찾고자하는 연령대와 가져온 구직자의 연령대가 똑같으면 
				String n_gender = guArr[i].getJubun().substring(6); // 그 사람의 주민번호 끝자리를 가져온다.
				// "1" "2" "3" "4"
		
				if("남".equals(gender)) { // 내가 성별 선택을 "남"을 했는데
					if("1".equals(n_gender)||"3".equals(n_gender)) {// 가져온 구직자의 주민번호 끝자리도 "남"이라면
						System.out.println(guArr[i].showInfo()); // 연령대와 성별도 맞으니 그 구직자의 정보를 출력한다.
					}
				}
				else { // 성별 선택을 "여"를 했는데
					if("2".equals(n_gender)||"4".equals(n_gender)) {// 가져온 구직자의 주민번호도 "여"이라면
						System.out.println(guArr[i].showInfo());
					}
				}
			}
		}// end of for-------------------
		
	}// end of void search(int ageline, String gender, Gujikja[] guArr)------------------------

	
	// 모든 구직자 희망급여보기
	public void showAllHopeMoney(Gujikja[] guArr) {
		
		/*
		   -------------------
		            구직자명   희망급여
		   -------------------
		            엄정화       5,000만원
		            이순신       7,000만원
		            유관순       8,000만원
		 */

		
		System.out.println("-------------------------------------");
		System.out.println("구직자명               희망급여");
		System.out.println("-------------------------------------");
		
		for(int i=0; i<Gujikja.count; i++) {
			System.out.println(guArr[i].getName()+"                  "+guArr[i].strHopeMoney() );
		}// end of for----------------------
		
	}// end of public void showAllHopeMoney()-----------------------
		
	
	// 구직자들의 입력받은 필드값(Gujikja)들을 모두 검사하여서, null값이 있는지 없는지 확인한다.
	// 사용은 GujikjaMain에서 써야하니, private는 안 된다.
	// 같은 패키지이든, 다른 패키지이든 모든 곳에서 사용하게 하고싶다면 public로 한다.
	
	// == Gujikja 인스턴스가 제대로 생성되었는지 확인 시캬주는 메소드 생성 == //
	public boolean checkGujikja(Gujikja gu){
		
		if(gu.getUserid() != null &&
		   gu.getPasswd() != null &&
		   gu.getName() != null &&
	       gu.getJubun() != null &&
		   gu.getMobile() != null &&
		   gu.getHopeMoney() > 0) {
			
			return true;
		}
		else {
			return false;
		}
		
		
		
	}
	
	
	
	
}
	

