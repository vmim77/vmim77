package my.day11.b.encapsulation;

import java.util.Scanner;

public class GujikjaMain {

	public static void main(String[] args) {

		Gujikja[] guArr = new Gujikja[5]; 
		GujikjaCtrl ctrl = new GujikjaCtrl(); 
		
		Gujikja gu1 = new Gujikja(); 
		gu1.setUserid("eomjh");
		gu1.setPasswd("qwer1234$A");
		gu1.setName("엄정화");
		gu1.setJubun("9506302");
		gu1.setHopeMoney(5000);
		gu1.setMobile("01098761234");
		
		if( ctrl.checkGujikja(gu1) ) { // 제대로 입력을 다 했다면 true를 반환, 하나라도 이상하다면 false를 반환 
			guArr[Gujikja.count++] = gu1;
		}
		
		////////////////////////////
		
		Gujikja gu2 = new Gujikja();
		gu2.setUserid("leess");
		gu2.setPasswd("qwer1234$A!");
		gu2.setName("이순신");
		gu2.setJubun("9506301");
		gu2.setHopeMoney(7000);
		gu2.setMobile("01078785544");
		
		if( ctrl.checkGujikja(gu2) ) {
			guArr[Gujikja.count++] = gu2;
		}
		
		////////////////////////////
		
		Gujikja gu3 = new Gujikja();
		gu3.setUserid("youks");
		gu3.setPasswd("qwer1234$A!");
		gu3.setName("유관순");
		gu3.setJubun("8606302");
		gu3.setHopeMoney(8000);
		gu3.setMobile("01056788578");
		
		if( ctrl.checkGujikja(gu3) ) {
			guArr[Gujikja.count++] = gu3;
		}
		
		System.out.println("Gujikja.count : " + Gujikja.count);
		
		////////////////////////////
		
		Scanner sc = new Scanner(System.in);
		String smenuNo = "";
		
		
		do {
			
			System.out.println("\n >>> === 메인메뉴 ===  <<< \n"
					+ "1.구직자 회원가입   2.구직자 모두 보기  3.검색  4.모든 구직자 희망급여보기  5.프로그램 종료 \n");

			System.out.print("▷ 메뉴번호 선택 => "); 
			smenuNo = sc.nextLine();
			
			switch (smenuNo) {
			case "1": // 구직자 회원가입
				
				boolean result = ctrl.register(sc, guArr);  
										  
				
				if(result) {
					System.out.println(">> 회원가입 성공 !! \n");
				}
				

				break; // switch 의 break 이다.
				
			case "2": // 구직자 모두 보기
				ctrl.showAll(guArr);
				
				break; // switch 의 break 이다.
				
			case "3": // 검색
				searchMenu(sc, ctrl, guArr);
				
				break; // switch 의 break 이다.
				
			case "4": // 모든 구직자 희망급여보기
				ctrl.showAllHopeMoney(guArr);
				
				break; // switch 의 break 이다.
				
				
			case "5": // 프로그램 종료
				
				break; // switch 의 break 이다.
				
			default : 
				System.out.println("\n>> 메뉴에 없는 번호 입니다. <<\n");
				
				break; // switch 의 break 이다.
				
			}// end of switch ---------------------------------------
			
		} while (!("5".equals(smenuNo))); // 4번을 누르면 do~while을 빠져나와라
		
		
		
		sc.close();
		System.out.println("\n~~~~~ 프로그램 종료 ~~~~~ \n");

		

		
	}// end of main(String[] args)---------------------------------------------------

	
	static void searchMenu(Scanner sc, GujikjaCtrl ctrl, Gujikja[] guArr) {
		
		String sMenuNo = "";
		
		do {
			System.out.println("\n *** ====== 검색메뉴 ====== *** \n"
							+ "1.연령대검색   2.성별검색   3.연령대및성별검색   4.메인으로 돌아가기\n");
			
			System.out.print("▷ 검색메뉴번호 선택 => ");
			sMenuNo = sc.nextLine();
			
			switch (sMenuNo) {
			case "1" : // 연령대검색
				do {
					try {
						System.out.print("▷ 연령대 => ");
						
						
						String sAgeline = sc.nextLine();
						int ageline = Integer.parseInt(sAgeline); 
						
						if( ageline%10 == 0 && (0 <= ageline && ageline <= 70) ) {// ageline은 10의 배수이면서, 0~70까지만
							ctrl.search(ageline, guArr);
							
							break; // do~while 의 break
						}
						else { 
							System.out.println("\n>> 검색할 수 없는 연령대 입니다.!!\n");
							
						}
						
					} catch(NumberFormatException e) {
						System.out.println("\n>> 정수만 입력하세요 !! <<\n");
					}
				} while(true);
				
				break;
				
			case "2" : // 성별검색
				
				
				do {
				
					System.out.print("▷ 성별[남/여] => ");
											
					String gender = sc.nextLine();
					
					gender = gender.trim();
					
					if("남".equals(gender) || "여".equals(gender)) {
						ctrl.search(gender, guArr);
						break; // do~while의 break
					}
					else {
						System.out.println("\n>> 남 또는 여 만 입력하세요!! <<\n");
					}
						
				} while(true);
				
				
				break;
				
			case "3" : // 연령대및성별검색
				do {
					try {
						System.out.print("▷ 연령대 => ");
						
						String sAgeline = sc.nextLine();
						int ageline = Integer.parseInt(sAgeline); 
																  
						if( ageline%10 == 0 && (0 <= ageline && ageline <= 70) ) {
							String gender = "";
							do {
								System.out.print("▷ 성별[남/여] => ");
								gender = sc.nextLine();
								
								if("남".equals(gender.trim()) || "여".equals(gender.trim())) {
									break; // 가장 가까운 do~while 문을 빠져나가는 break
								}
								else {
									System.out.println("\n>> 남 또는 여 만 입력하세요!! <<\n");
								}
							} while(true);// end of do~while-----------------------------
						
							ctrl.search(ageline, gender, guArr);
							break; // 바깥쪽 do~while 문을 빠져 나간다.
						}
						else { 
							System.out.println("\n>> 검색할 수 없는 연령대 입니다.!!\n");
						}
						
					} catch(NumberFormatException e) { // 문자열, 실수형이 들어오면 여기로 온다.
						System.out.println("\n>> 정수만 입력하세요 !! <<\n");
					}
				} while(true);// end of do~while-----------------------------
				
				break;
				
			case "4" : // 메인으로 돌아가기
				
				break; // switch 문의 break
			
	
			default:
				System.out.println("\n>> 메뉴에 없는 번호 입니다. <<\n");
				break;
			}// end of switch (sMenuNo) -----------------------------------
			
		} while(!("4".equals(sMenuNo)));
		
	} // end of static void searchMenu()-------------------------------------

}