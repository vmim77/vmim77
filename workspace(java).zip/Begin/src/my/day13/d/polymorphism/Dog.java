package my.day13.d.polymorphism;

public class Dog extends Animal {
	
	// Dog 만 가지는 field 를 정의(추상화)
	private int weight;
	
	// 생성자(constructor)
	public Dog() {
//		System.out.println("\n>> 자식클래스인  Dog 클래스의 기본생성자를 호출함 <<\n"); // 이렇게 쓰는 건 불가능하다.
		
		super(); // 부모클래스인 Animal 의 기본생성자를 말한다. 
				 // Java에서 소괄호는 딱 두가지, 메소드 & 생성자
		
				 // 부모클래스의 생성자가 자식클래스의 생성자 안에서 가장 윗 줄에 있어야 한다.
				 // 왜냐하면 자바에서는 부모클래스의 기본생성자가 맨처음에 호출 되어져야 하기 때문이다.
		
				 // super(); 을 없애더라도 생략되어져 있으므로 super(); 을 실행해준다.
		
	}

	// Dog 만 가지는 method 를 정의(추상화)
	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		if(weight > 0)
			this.weight = weight;
	}
	
	
	// ================================================== //
	// === 강아지의 정보를 출력해주는 메소드 === //
	// @XXXX 을 애노테이션(어노테이션)이라고 부른다. 
	//Override 애노테이션(어노테이션)은 메소드의 재정의를 할때 쓰이는 것이다.
	// 메소드의 재정의를 메소드의 오버라이딩 이라고 부른다.
	// 메소드의 오버라이딩 이라 함은 부모 클래스에서 정의해둔 메소드를 자식 클래스에서 새롭게 정의해주는 것을 말한다.
	// 조심할 것은, 메소드의 오버라딩시 접근제한자는 부모에서 정의해둔 접근제한자 보다 크든지 또는 같아야 만 하고
	// 내용물{}을 제외한 껍데기는 같아야 한다.
	
	// === 메소드의 재정의(오버라이딩) === //
	@Override		
	public void showInfo() {
		System.out.println("== 강아지정보 == \n"
						+ "1. 성명 : " + super.getName() + "\n"   // 여기에는 super.getNmae(); // this.getName(); // getName(); 중에 아무거나 써도 된다.
						+ "2. 생년 : " + this.getBirthYear() + "년 \n"
						+ "3. 몸무게 : " + weight + "kg");
				
		
	}// end of public void showInfo()--------------------------
	
	// === 강아지의 소리를 출력해주는 메소드로 재정의 === //
	@Override
	public void cry() {
		
		System.out.println(">>> "+getName()+"는 '멍멍' 하며 짖습니다.<<<");
		
	}// end of public void cry()-----------------------
	
	// Dog 만 가지는 메소드
	public void run() {
		System.out.println("== 강아지는 빠르게 달립니다. ==\n");
	}

}
