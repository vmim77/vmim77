package my.day13.c.accessModifier;

import my.day13.b.accessModifier.Parent;

public class Child_2 extends Parent {
	
	void viewInfo() {
		super.id = "leess";          // public      동그라미(초록색) (자기자신클래스내부, 동일패키지에있는다른클래스, 다른패키지에있는하위(자식)클래스, 그외의영역)
		super.passwd = "qwer1234$A"; // protected   마름모(노랑색)   (자기자신클래스내부, 동일패키지에있는다른클래스, 다른패키지에있는하위(자식)클래스)
		// super.name                // default     삼각형(파랑색)   (자기자신클래스내부, 동일패키지에있는다른클래스)
		// super.jubun               // private     사각형(빨강색)   (자기자신클래스내부)
	}

}
