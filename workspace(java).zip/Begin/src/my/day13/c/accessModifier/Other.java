package my.day13.c.accessModifier;

import my.day13.b.accessModifier.Parent; // 누구든지 Parent 클래스를 쓸 수 있으나, 다른패키지여서 import한다.

public class Other {
	
	void test() {
		
		Parent p = new Parent();
		p.id = "leess"; // public은 누구나 다 쓸 수 있다.
		
		
		
	}// end of void test()-------------------------
	
}
