package my.day13.a.multi_inheritance;

public class Father {
	
	String userid = "leess";

}
