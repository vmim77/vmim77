package my.day13.a.multi_inheritance;

public class Me extend Father, Morther { // Me 클래스는 Father 클래스에 있던 필드와 메소드를 전부 상속해온다.


	// public class Me extend Father, Morther (X)
	// 자바는 상속시 여러 클래스를 다중상속 해오는 것은 안된다.!! 
	// 참고로 C++ 언어는 다중상속이 가능하다.
	
	String name = "이순신";
	
}
