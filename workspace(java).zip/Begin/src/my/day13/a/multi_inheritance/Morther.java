package my.day13.a.multi_inheritance;

public class Morther {
	
	String passwd = "1234";

}
