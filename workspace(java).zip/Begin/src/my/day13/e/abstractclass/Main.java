package my.day13.e.abstractclass;

public class Main {
	
	// >>> 다형성(Polymorphism) <<< (형태가 다양하다)
	// ==> 상속을 이용하여 여러 클래스 타입을 하나의 클래스 타입으로 다루는 기술.
	// 자식클래스로 생성되어진 객체를 부모 클래스 타입으로 받을 수 있다는 것이 다형성(Polymorphism)이다.
	
	

	public static void main(String[] args) {
		
		AbstractAnimal [] aniArr = new AbstractAnimal[5];
		// 배열도 객체여서 null이 들어가도 상관없다. String이 null값이 들어갈 수 있듯이
		// 객체이긴하나, 저장소이다. 어떠한 데이터타입을 담는 저장소이다.
		// 추상클래스든 상관없이, 앞에 써진 인스턴스타입은 그냥 그 타입의 정보를 담는다는 뜻일뿐이다.
		
		// AbstractAnimal ani = new AbstractAnimal(); 
		// 추상 클래스(미완성 클래스)를 가지고 바로 인스턴스 생성은 불가하다.
		// AbstractAnimal 혼자서는 인스턴스 생성이 안되지만, 여기에 dog나 cat, duck 등 자식클래스를 저장할 수는 있다.
		
		
		
		
		Dog dog = new Dog();
	//	AbstractAnimal ani1 = new Dog();  // 가능, 이게 다형성이다.
	//	aniArr[0] = new Dog();    // 가능
		dog.setName("뽀삐");
		dog.setBirthYear(2019);
		dog.setWeight(5);
	
	
	//  aniArr[0] = dog;	
		aniArr[AbstractAnimal.count++] = dog;   // count = 0; , 이후 count++;
		
		
		Cat cat = new Cat(); 
	//	AbstractAnimal ani2 = new Cat();  // 가능, 이게 다형성이다.
	//	aniArr[1] = new Cat();    // 가능
		cat.setName("톰");
		cat.setBirthYear(2020);
		cat.setColor("하얀검정");
		
		
		//  aniArr[1] = cat;	
		aniArr[AbstractAnimal.count++] = cat; // count = 1; , 이후 count++;

		
		Duck duck = new Duck(); 
	//	AbstractAnimal ani3 = new Duck();  // 가능, 이게 다형성이다.
	//	aniArr[2] = new Duck();    // 가능
		duck.setName("도널드");
		duck.setBirthYear(2021);
		duck.setPrice(5000);
		
		
		//  aniArr[2] = duck;	
		aniArr[AbstractAnimal.count++] = duck; // count = 2; , 이후 count++;
		
		Dog dog2 = new Dog();
	//	AbstractAnimal ani1 = new Dog();  // 가능, 이게 다형성이다.
	//	aniArr[0] = new Dog();    // 가능
		dog2.setName("쵸코");
		dog2.setBirthYear(2019);
		dog2.setWeight(3);
		
		aniArr[AbstractAnimal.count++] = dog2;   // count = 3; , 이후 count++;
		

			
			
			
		for(int i=0; i<AbstractAnimal.count; i++) {
			aniArr[i].showInfo();
			// dog.showInfo();
			// cat.showInfo();
			// duck.showInfo();
			// aniArr[0] = dog; ==> dog.showInfo() 는 Animal의 showInfo가 아니라 강아지클래스에 재정의된 메소드를 출력한다.
			
			aniArr[i].cry();
			// dog.cry();
			// cat.cry();
			// duck.cry();
			
			
			if( aniArr[i] instanceof Dog ) { // i번째 객체가 실제로 강아지의 인스턴스라면 true
				((Dog)aniArr[i]).run(); // 강제형변환(casting)을 시켜준다. int를 short로....
										// 한번 더 괄호를 더 쳐주고 점(.)을 찍으면 그때는 Dog에 저장된 메소드를 사용할 수 있다.
			}
					
			else if( aniArr[i] instanceof Cat ) { // i번째 객체가 실제로 고양이의 인스턴스라면 true
				((Cat)aniArr[i]).jump();
			}
			
			else if( aniArr[i] instanceof Duck ) { // i번째 객체가 실제로 오리의 인스턴스라면 true
				((Duck)aniArr[i]).swim();
			}
					
					
			
		}
		
			
		
		

	}// end of Main(String[] args)------------------------------------------

}
