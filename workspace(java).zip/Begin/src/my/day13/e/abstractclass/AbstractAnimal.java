package my.day13.e.abstractclass;
/*

-----------------------------------------------------------------------------------------------------------------------
	접근제한자(접근지정자, accessmodifier)   자기자신클래스내부      동일패키지에있는다른클래스      다른패키지에있는하위(자식)클래스        그외의영역  
----------------------------------------------------------------------------------------------------------------------- 
	public                                    O                    O                         O                 O  
	protected                                 O                    O                         O                 X
	default                                   O                    O                         X                 X
	private                                   O                    X                         X                 X

*/
public abstract class AbstractAnimal {
	// abstract class == 추상 클래스 == 미완성 클래스
	// 추상 클래스(미완성 클래스)란? 추상 메소드(미완성 메소드)를 가지고 있는 클래스를 말한다.
	// 추상 클래스(미완성 클래스)를 가지고 바로 인스턴스 생성은 불가하다.
	// 하지만 추상 클래스(미완성 클래스)를 부모 클래스로 하는 자식 클래스의 인스턴스는 추상 클래스(미완성 클래스)로 저장이 가능하다.
	
	
	
	
	// Dog, Cat, Duck 의 공통 field(속성) (추상화)
	private String name;  // (은닉화)
	private int birthYear; // (은닉화)
	static int count;
	
	// 기본생성자
	public AbstractAnimal() {
		
	}
	
	// Dog, Cat, Duck 의 공통 method(기능) (추상화)
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		if(name != null && !name.trim().isEmpty()) // 이름은 null이 아니면서, 공백도 아니고, ""도 안 된다.
			this.name = name;
		
	}
	
	public int getBirthYear() {
		return birthYear;
	}
	
	public void setBirthYear(int birthYear) {
		if(birthYear > 0) 
			this.birthYear = birthYear;
		
	}
	
	
	// === 동물들(강아지, 고양이, 오리)의 정보를 출력해주는 메소드 === //
	
	protected void showInfo() {
		System.out.println("== 동물정보 == \n"
				+ "1. 성명 : " + name + "\n"
				+ "2. 생년 : " + birthYear + "년");
		
		
	}// end of public void showInfo()--------------------------
	
	
	// === 추상(미완성) 메소드 === //
	// Animal 클래스를 부모클래스로 사용하는 자식 클래스에서 반드시 cry() 메소드를 재정의(Override)를 해야 할 경우에는
	// 부모클래스인 Animal 클래스에서는 cry() 메소드를 추상메소드(미완성 메소드)로 만들면 된다.
	// 추상메소드를 가지고 있는 클래스는 미완성 클래스(추상 클래스)이니깐, 위에서 반드시 abstract를 public class 사이에 넣어야 한다. ==> public abstract class Animal
	
	public abstract void cry();
		
	// end of public void cry()-----------------------
	
	

}
