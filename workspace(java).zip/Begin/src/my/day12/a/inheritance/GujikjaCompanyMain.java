package my.day12.a.inheritance;

import java.util.Scanner;

public class GujikjaCompanyMain {

	public static void main(String[] args) {
		
		GujikjaCompanyCtrl ctrl = new GujikjaCompanyCtrl(); 

		Gujikja[] guArr = new Gujikja[5]; 
		
		Gujikja gu1 = new Gujikja(); 
		gu1.setId("eomjh");
		gu1.setPasswd("qwer1234$A");
		gu1.setName("엄정화");
		gu1.setMobile("01098761234"); // 여기까지는 부모클래스에 있는 메소드
		gu1.setJubun("9506302"); // 여기부터는 자식클래스에 있는 메소드
		gu1.setHopeMoney(5000); 
		
		if( ctrl.checkGujikja(gu1) ) { // 제대로 입력을 다 했다면 true를 반환, 하나라도 이상하다면 false를 반환 
			guArr[Gujikja.count++] = gu1;
		}
		
		////////////////////////////
		
		Gujikja gu2 = new Gujikja();
		gu2.setId("leess");
		gu2.setPasswd("qwer1234$A");
		gu2.setName("이순신");
		gu2.setMobile("01078785544");
		gu2.setJubun("9506301");
		gu2.setHopeMoney(7000);
		
		if( ctrl.checkGujikja(gu2) ) {
			guArr[Gujikja.count++] = gu2;
		}
		
		////////////////////////////
		
		Gujikja gu3 = new Gujikja();
		gu3.setId("youks");
		gu3.setPasswd("qwer1234$A");
		gu3.setName("유관순");
		gu3.setMobile("01056788578");
		gu3.setJubun("8606302");
		gu3.setHopeMoney(8000);
		
		if( ctrl.checkGujikja(gu3) ) {
			guArr[Gujikja.count++] = gu3;
		}
		
		System.out.println("Gujikja.count : " + Gujikja.count);
		
		////////////////////////////////////////////////////////////////////////////////////
		
		Company [] compArr = new Company[3]; // 회사 정보를 담을 저장소 생성 compArr[0] = comp1; compArr[1] = comp2; compArr[2] = null;
		
		Company comp1 = new Company(); // 새로운 회사를 하나 만든다.
		comp1.setId("LG"); // 동일하게 5~10글자에, 영문자 또는 숫자만 가능
		comp1.setPasswd("qwer1234$A"); // 동일하게 8~15글자에, 대문자&소문자&숫자&특수기호
		comp1.setName("엘지"); // 동일하게 2~5글자에, 한글로만 가능
		comp1.setMobile("01034567890"); // 인사담당자의 연락처
		
		comp1.setJobType("전자");
		comp1.setSeedMoney(500000000000L);
		
		if( ctrl.checkCompany(comp1) ) {
			compArr[Company.count++] = comp1;
		}
		
		Company comp2 = new Company(); // 새로운 회사를 하나 만든다.
		comp2.setId("samsung"); // 동일하게 5~10글자에, 영문자 또는 숫자만 가능
		comp2.setPasswd("qwer1234$A"); // 동일하게 8~15글자에, 대문자&소문자&숫자&특수기호
		comp2.setName("삼성"); // 동일하게 2~5글자에, 한글로만 가능
		comp2.setMobile("01079795678"); // 인사담당자의 연락처
		
		comp2.setJobType("반도체");
		comp2.setSeedMoney(500000000000L);
		
		if( ctrl.checkCompany(comp2) ) {
			compArr[Company.count++] = comp2;
		}
		
		System.out.println("Company.count : " + Company.count);
		
		////////////////////////////////////////////////////////////////////////////////////
		
		Scanner sc = new Scanner(System.in);
		String smenuNo = "";
		
		Gujikja loginGu = null; // 구직자로 로그인 되어지면  로그인 되어진 구직자 인스턴스를 저장할 용도임.
		Company loginComp = null; // 구인회사로 로그인 되어지면  로그인 되어진 구인회사 인스턴스를 저장할 용도임.
		String title = "";
		
		
		do {
			
			if(loginGu == null && loginComp == null) {
			
				title = "\n >>> === 메인메뉴 ===  <<< \n";
			}
			
			else if(loginGu != null && loginComp == null) { // loginGu 에는 로그인성공한 guArr[i]이 담겨져있어서 이름을 호출가능
				
				
				// 구직자로만 로그인한 케이스 
				// 둘중 하나는 null이 아닌 상황
				title ="\n>>> === 메인메뉴[구직자 "+loginGu.getName()+" 로그인중..] ===  <<<\n";
				
			}
			
			else if(loginGu == null && loginComp != null) { 
				// 회사로만 로그인한 케이스 
				// 둘중 하나는 null이 아닌 상황
				title ="\n>>> === 메인메뉴[구인회사 "+loginComp.getName()+" 로그인중..] ===  <<<\n";
				
			}
			
			System.out.println(title
					+ "1.구직자 회원가입    2.구인회사 회원가입 \n"
					+ "3.구직자 로그인       4.구인회사 로그인 \n"
					+ "5.모든 구직자 보기   6.모든 구인회사 보기 \n"
					+ "7.로그아웃              8.내정보 변경하기 \n"
					+ "9.검색                    10.모든 구직자 희망급여보기 \n"
					+ "11.프로그램 종료 ");

			System.out.print("\n▷ 메뉴번호 선택 => "); 
			smenuNo = sc.nextLine();
			
			switch (smenuNo) {
			case "1": // 구직자 회원가입
				
				boolean result = ctrl.register(sc, guArr);  
				
				if(result) {
					System.out.println(">> 구직자 회원가입 성공 !! \n");
				}
				

				break; // switch 의 break 이다.
				
			case "2": // 구인회사 회원가입
				
				result = ctrl.register(sc, compArr);  
										  
				
				if(result) {
					System.out.println(">> 구인회사 회원가입 성공 !! \n");
				}
				
				break;
			case "3": // 구직자 로그인
				

				
				
				loginGu = ctrl.login(sc, guArr); // 성공되어지면 그 인스턴스를 저기에 넣어준다.
											     // 실패하면 null값을 넣어준다.
											     // Gujikja의 필드값들이 들어있는 정보들일테니, Gujikja 타입으로
				
				// 로그인을 성공했다면 loginGu에는 구직자가 담겨진다(구직자의 아이디, 비번, 전번, 성명 등)
				// 로그인을 실패했다면 loginGU에는 null이 들어가 있다.
				
				if(loginGu == null) {
					System.out.println("\n>> 로그인 실패!! <<\n");
				}
				
				
				
				break; // switch 의 break 이다.	
				
				
			case "4": // 구인회사 로그인
				

				
				loginComp = ctrl.login(sc, compArr); // 성공되어지면 그 인스턴스를 저기에 넣어준다.
			     									 // 실패하면 null값을 넣어준다.
				
				if(loginComp == null) {
					System.out.println("\n>> 로그인 실패!! <<\n");
				}

				break; // switch 의 break 이다.
				
			case "5": // 구직자 모두 보기
				
				if(loginComp != null && loginGu == null) {// 구직회사로 로그인을 안했다면, loginComp == null 이다. 
					// 구인회사로 로그인 했을 경우에만 보여주도록 한다.
					ctrl.showAll(guArr); // method의 overloading (파라미터의 순서, 갯수, 타입만 다르면 된다.)
				}
				else {
					System.out.println("\n>> 먼저 구인회사 계정으로 로그인을 하세요!! <<\n");
				}
				
				break; // switch 의 break 이다.
				
			case "6": // 구인회사 모두 보기
				
				if(loginGu != null && loginComp == null) {// 구직자로 로그인을 안했다면, loginGu == null 이다. 
					// 구직자로 로그인 했을 경우에만 보여주도록 한다.
					ctrl.showAll(compArr);
				}
				else {
					System.out.println("\n>> 먼저 구직자 계정으로 로그인을 하세요!! <<\n");
				}
				
				break; // switch 의 break 이다.
				
			case "7": // 로그아웃
				
				loginGu = null;
				loginComp = null;
				System.out.println("\n>> 로그아웃 되었습니다. <<\n");
				
				break; // switch 의 break 이다.
				
			case "8": // 내정보 변경하기
				if(loginGu == null && loginComp ==null){
					System.out.println("\n>> 먼저 로그인 부터 하세요!! <<\n");
				}
				else if(loginGu != null && loginComp ==null) {
		
					loginGu = ctrl.update(sc, loginGu);  // 현재 로그인된 사람이 누구인지를 알아야 하니 loginGu, 변경하려는 정보 입력받아야 하니 sc, 정보를 찾아와서 변경해야하니 guArr
					// 변경되어진 정보들을 현재 로그인된 loginGu에 넣어준다.
					
					System.out.println("\n>>=== 변경후 구직자 나의 정보 ===<<");
					System.out.println(loginGu.showInfo());// 변경된 정보를 출력한다.
					

					
					
				}
				else if(loginGu == null && loginComp != null) {
					// System.out.println("\n>> 확인용 : 구인회사로 로그인하셨군요!! <<\n");
					
					//암호, 업종, 자본금
					
					loginComp = ctrl.update(sc,  loginComp);
					
					System.out.println("\n>>=== 변경후 구인회사 정보 ===<<");
					System.out.println(loginComp.showInfo());// 변경된 정보를 출력한다.
					
					
					
				}
				break; // switch 의 break 이다.
				
			case "9": // 검색
				searchMenu(sc, ctrl, guArr);
				
				break; // switch 의 break 이다.
				
			case "10": // 모든 구직자 희망급여보기
				ctrl.showAllHopeMoney(guArr);
				
				break; // switch 의 break 이다.
				
				
			case "11": // 프로그램 종료
				
				break; // switch 의 break 이다.
				
			default : 
				System.out.println("\n>> 메뉴에 없는 번호 입니다. <<\n");
				
				break; // switch 의 break 이다.
				
			}// end of switch ---------------------------------------
			
		} while (!("11".equals(smenuNo))); // 4번을 누르면 do~while을 빠져나와라
		
		
		
		sc.close();
		System.out.println("\n~~~~~ 프로그램 종료 ~~~~~ \n");

		

		
	}// end of main(String[] args)---------------------------------------------------

	
	static void searchMenu(Scanner sc, GujikjaCompanyCtrl ctrl, Gujikja[] guArr) {
		
		String sMenuNo = "";
		
		do {
			System.out.println("\n *** ====== 검색메뉴 ====== *** \n"
							+ "1.연령대검색   2.성별검색   3.연령대및성별검색   4.메인으로 돌아가기\n");
			
			System.out.print("▷ 검색메뉴번호 선택 => ");
			sMenuNo = sc.nextLine();
			
			switch (sMenuNo) {
			case "1" : // 연령대검색
				do {
					try {
						System.out.print("▷ 연령대 => ");
						
						
						String sAgeline = sc.nextLine();
						int ageline = Integer.parseInt(sAgeline); 
						
						if( ageline%10 == 0 && (0 <= ageline && ageline <= 70) ) {// ageline은 10의 배수이면서, 0~70까지만
							ctrl.search(ageline, guArr);
							
							break; // do~while 의 break
						}
						else { 
							System.out.println("\n>> 검색할 수 없는 연령대 입니다.!!\n");
							
						}
						
					} catch(NumberFormatException e) {
						System.out.println("\n>> 정수만 입력하세요 !! <<\n");
					}
				} while(true);
				
				break;
				
			case "2" : // 성별검색
				
				
				do {
				
					System.out.print("▷ 성별[남/여] => ");
											
					String gender = sc.nextLine();
					
					gender = gender.trim();
					
					if("남".equals(gender) || "여".equals(gender)) {
						ctrl.search(gender, guArr);
						break; // do~while의 break
					}
					else {
						System.out.println("\n>> 남 또는 여 만 입력하세요!! <<\n");
					}
						
				} while(true);
				
				
				break;
				
			case "3" : // 연령대및성별검색
				do {
					try {
						System.out.print("▷ 연령대 => ");
						
						String sAgeline = sc.nextLine();
						int ageline = Integer.parseInt(sAgeline); 
																  
						if( ageline%10 == 0 && (0 <= ageline && ageline <= 70) ) {
							String gender = "";
							do {
								System.out.print("▷ 성별[남/여] => ");
								gender = sc.nextLine();
								
								if("남".equals(gender.trim()) || "여".equals(gender.trim())) {
									break; // 가장 가까운 do~while 문을 빠져나가는 break
								}
								else {
									System.out.println("\n>> 남 또는 여 만 입력하세요!! <<\n");
								}
							} while(true);// end of do~while-----------------------------
						
							ctrl.search(ageline, gender, guArr);
							break; // 바깥쪽 do~while 문을 빠져 나간다.
						}
						else { 
							System.out.println("\n>> 검색할 수 없는 연령대 입니다.!!\n");
						}
						
					} catch(NumberFormatException e) { // 문자열, 실수형이 들어오면 여기로 온다.
						System.out.println("\n>> 정수만 입력하세요 !! <<\n");
					}
				} while(true);// end of do~while-----------------------------
				
				break;
				
			case "4" : // 메인으로 돌아가기
				
				break; // switch 문의 break
			
	
			default:
				System.out.println("\n>> 메뉴에 없는 번호 입니다. <<\n");
				break;
			}// end of switch (sMenuNo) -----------------------------------
			
		} while(!("4".equals(sMenuNo)));
		
	} // end of static void searchMenu()-------------------------------------

}