package my.day09.a.array;

public class BubbleSortMain {
	
	/*
	   == 입사문제 ==
	   >> 버블 정렬(Bubble Sort)은 
	    정렬 대상 리스트(배열)의 항목을 수평방향으로 나열했다고 가정했을 때, 
	    왼쪽 끝에서부터 시작해서 인접하는 두 항목의 값을 비교하여 
	    올바른 순서(오름차순 또는 내림차순)로 되어있지 않으면 서로 위치를 교환하는 정렬방법이다.
	    
	    이렇게 인접하는 항목의 값을 비교해서 위치를 교환하는 과정을 
	    리스트(배열)의 마지막 항목까지 반복해서 제일 큰(또는 작은) 값이 끝에 오도록 한다.
	    
	    각 회전(Pass)과정이 끝날때마다 정렬은 뒤에서부터 하나씩 완료된다. 
	 */   

	public static void main(String[] args) {
		
		int[] numArr = {9, 7, 3, 5, 1};
		
		/*
			numArr[0] => 9
			numArr[1] => 7
			numArr[2] => 3
			numArr[3] => 5
			numArr[4] => 1
		 */
		
		System.out.println("=== 정렬하기 전 ===");
		for(int i=0; i<numArr.length; i++) {
			String str = (i<numArr.length-1)?",":"\n";
			System.out.print(numArr[i]+str);
		}// end of for-------------------------
		
		/*
		  === 정렬하기 전 ===
		   9,7,3,5,1
			
			
			
		       ----------------------
	데이터값 =>   | 9 | 7 | 3 | 5 | 1 |
			   ----------------------
			   
	index =>     0    1   2   3   4
	
			    ---------------------
	데이터값 =>   | 7 | 3 | 5 | 1 | 9 |
			   ----------------------
			   
	index =>     0    1   2   3   4
	
				---------------------
	데이터값 =>   | 3 | 5 | 1 | 7 | 9 |
			   ----------------------
			   
	index =>     0    1   2   3   4
	
			   ---------------------
	데이터값 =>   | 3 | 1 | 5 | 7 | 9 |
			   ----------------------
			   
	index =>     0    1   2   3   4
	
				---------------------
	데이터값 =>   | 1 | 3 | 5 | 7 | 9 |
			   ----------------------
			   
	index =>     0    1   2   3   4
	
	
	
		 */
		
		
		// === 오름차순 정렬하기 === //
		for(int i=0; i<numArr.length-1; i++) { // 숫자를 하나씩 뽑는 for문
			
			// numArr.length-1은 비교할 대상을 추출할 개수 ==>  (9, 7, 3, 5)
			// 비교할 대상을 추출할 개수는 4개가 된다.(※1은 자기와 비교할 필요가 없으니 뺀다.)
			
			for(int j=0; j<numArr.length-1-i; j++) { // 하나 뽑은 숫자로 비교하는 for문
				
			// i=0; 일때는 조건식이 j<4; 되어야만 4번 비교함. (9는 7, 3, 5, 1과 비교해야한다.)
			// i=1; 일때는 조건식이 j<3; 되어야만 3번 비교함. (7은 3, 5, 1과 비교해야한다.)
			// i=2; 일때는 조건식이 j<2; 되어야만 2번 비교함. (3은 5, 1과 비교해야한다.)
			// i=3; 일때는 조건식이 j<1; 되어야만 1번 비교함. (5는 1과 비교해야한다.)
				
				if(numArr[j] > numArr[j+1]) {// 여기서 이제 하나씩 비교를 할 것이다.
					// 9 와 7을 비교해서 9가 값이 더 크다면, 9을 임시저장소에 넣고  7을 0번째 배열에 넣고, 9을 1번째 배열에 넣는다.
					// numArr[0]  > numArr[1]
					//   9      >      7	

					/*
					   int tempArr = numArr[0]; // temp <= 9
					   numArr[0] = numArr[1];   // numArr[0] <= 7
					   numArr[1] = temp;        // numArr[1] <= 9

   					   {7, "9", 3, 5, 1}
					 */

					// numArr[1]  > numArr[2]
					//   9      >      3

					/*
					   int tempArr = numArr[1]; // temp <= 9
					   numArr[1] = numArr[2];   // numArr[1] <= 3
					   numArr[2] = temp;        // numArr[2] <= 9

					   9는 맨처음에 numArr[0]에 있었지만 점점 뒤로 넘어간다.
   					   {7, 3, "9", 5, 1}
					 */

					// numArr[2]  > numArr[3]
					//   9      >      5	

					/*
					   int tempArr = numArr[2]; // temp <= 9
					   numArr[2] = numArr[3];   // numArr[2] <= 5
					   numArr[3] = temp;        // numArr[3] <= 9
					   
					   {7, 3, 5, "9", 1}
					 */   
					
					// numArr[3]  > numArr[4]
					//   9      >      1	

					/*

					 
					   int tempArr = numArr[3]; // temp <= 9
					   numArr[3] = numArr[4];   // numArr[3] <= 1
					   numArr[4] = temp;        // numArr[4] <= 9
					   
					   {7, 3, 5, 1, "9"}
					 */   
					
//					   9,7,3,5,1
					
					 int temp = numArr[j]; 
					 numArr[j] = numArr[j+1];
					 numArr[j+1] = temp; 
					
				}
													
			}// end of for---------------------
			
		}// end of for-------------------------
		
		System.out.println("\n === 오름차순 정리한 후 === ");
		
		for(int i=0; i<numArr.length; i++) {
			String str = (i<numArr.length-1)?",":"\n";
			System.out.print(numArr[i]+str);
		}
		
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		int[] numArr2 = {9, 7, 3, 5, 1};
		
		System.out.println("=== 정렬하기 전 ===");
		for(int i=0; i<numArr2.length; i++) {
			String str = (i<numArr2.length-1)?",":"\n";
			System.out.print(numArr2[i]+str);
		}// end of for-------------------------
		
		// 9, 7, 5, 3, 1
		
		// == 내림차순 정렬하기 == //
		for(int i=0; i<numArr2.length-1; i++) { // 9 7 3 5 추출
			
			for(int j=0; j<numArr2.length-1-i; j++) {
				
				if(numArr2[j] < numArr2[j+1]) {
					int temp = numArr2[j];
					numArr2[j] = numArr2[j+1];
					numArr2[j+1] = temp;
					
					//	   9,7,3,5,1
					
					
				}
				
				
			}//end of for-------------------------
			
		}//end of for---------------------------
		
		System.out.println("\n === 내림차순 정리한 후 === ");
		
		for(int i=0; i<numArr2.length; i++) {
			String str = (i<numArr2.length-1)?",":"\n";
			System.out.print(numArr2[i]+str);
		}// end of for-------------------------
		
		
		
	}// end of main(String args)-------------------------------------------

}
