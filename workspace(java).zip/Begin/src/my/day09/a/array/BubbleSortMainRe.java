package my.day09.a.array;

public class BubbleSortMainRe {
	
	/*
	   == 입사문제 ==
	   >> 버블 정렬(Bubble Sort)은 
	    정렬 대상 리스트(배열)의 항목을 수평방향으로 나열했다고 가정했을 때, 
	    왼쪽 끝에서부터 시작해서 인접하는 두 항목의 값을 비교하여 
	    올바른 순서(오름차순 또는 내림차순)로 되어있지 않으면 서로 위치를 교환하는 정렬방법이다.
	    
	    이렇게 인접하는 항목의 값을 비교해서 위치를 교환하는 과정을 
	    리스트(배열)의 마지막 항목까지 반복해서 제일 큰(또는 작은) 값이 끝에 오도록 한다.
	    
	    각 회전(Pass)과정이 끝날때마다 정렬은 뒤에서부터 하나씩 완료된다. 
	 */   

	public static void main(String[] args) {
		
		int[] numArr = {9, 7, 3, 5, 1};
		
		/*
		 * numArr[0] => 9
		 * numArr[1] => 7
		 * numArr[2] => 3
		 * numArr[3] => 5
		 * numArr[4] => 1
		 */
		
		
		// == 정렬하기 전 == //
		for(int i=0; i<numArr.length; i++) {
			String str = (i<numArr.length-1)?",":""; // i값이 4보다 작으면(데이터값 1이  아니면) 뒤에 콤마를 준다.
			System.out.print(numArr[i]+str);
		}
		
		
		// == 오름차순 정렬하기 == //
		//{9, 7, 3, 5, 1};
		
		for(int i=0; i<numArr.length-1; i++) { // 4 개의 값을 뽑는 for문 , 맨 마지막자리는 비교할 대상이 없으니깐 4이다.
											// i=0일때 다 돌리면 {7,3,5,1,9}
											// i=1일때 다 돌리면 {3,5,1,7,9}
											// i=2일때 다 돌리면 {3,1,5,7,9}
											// i=3일때 다 돌리면 {3,5,1,7,9}
										
			
			for(int j=0; j<numArr.length-1-i; j++) {// // 여기서 이제 하나씩 비교를 한다.
			
				
				// i=0; 일때는 조건식이 j<4; 되어야만 4번 비교함. (9는 7, 3, 5, 1과 비교해야한다.)
				// i=1; 일때는 조건식이 j<3; 되어야만 3번 비교함. (7은 3, 5, 1과 비교해야한다.)
				// i=2; 일때는 조건식이 j<2; 되어야만 2번 비교함. (3은 5, 1과 비교해야한다.)
				// i=3; 일때는 조건식이 j<1; 되어야만 1번 비교함. (5는 1과 비교해야한다.)
				
				if(numArr[j] > numArr[j+1]) { // 앞에있는 값이 뒤에값보다 크면, 뒤로 보낸다
					int temp = numArr[j]; // 9를 temp에 잠시 넣어놓고
					numArr[j] = numArr[j+1]; // 7을 1번째 자리에 넣고
					numArr[j+1] = temp; // temp에 있던 9를 2번째 자리에 넣는다.
					
				}
			}// end of for---------------
			
		}// end of for--------------
		
		// == 정렬한 후  == //
		System.out.println("\n === 오름차순 정리한 후 === ");
		
		for(int i=0; i<numArr.length; i++) {
			String str = (i<numArr.length-1)?",":""; // i값이 4보다 작으면(데이터값 1이  아니면) 뒤에 콤마를 준다.
			System.out.print(numArr[i]+str);
		}
		
		
		// == 내림차순 정리하기 == //
		
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		int[] numArr2 = {9, 7, 3, 5, 1};
		
		System.out.println("=== 정렬하기 전 ===");
		for(int i=0; i<numArr2.length; i++) {
			String str = (i<numArr2.length-1)?",":"\n";
			System.out.print(numArr2[i]+str);
			
		}// end of for-------------------------
		// 9,7,3,5,1
		
		for(int i=0; i<numArr2.length-1; i++) {
			
			for(int j=0; j<numArr2.length-1-i; j++) { // i=0일땐 4번비교, i=1일땐 3번비교....
				
				if(numArr2[j] < numArr2[j+1]) {// 앞에있는 값이 뒤에 값보다 작으면
					int temp = numArr2[j]; 
					numArr2[j] = numArr2[j+1]; // 뒤에 있는 걸 앞으로 보내고
					numArr2[j+1] = temp; // 작은 값을 뒤로 보내고
				}
				
			}// end of for-------------
			
		}// end of for---------------
		
		System.out.println("\n === 내림차순 정리한 후 ===\n");
		for(int i=0; i<numArr2.length; i++) {
			String str = (i<numArr2.length-1)?",":"\n";
			System.out.print(numArr2[i]+str);
			
		}// end of for-------------------------
		// 9,7,5,3,1
		
		
	}// end of main(String args)-------------------------------------------

}
