package my.day09.a.array;

public class TwoDimensionArrayMainRe {

	public static void main(String[] args) {
		
	
		
		System.out.println("\n================ 성적결과 ================\n");
		
		// 과목 : 국어, 영어, 수학
		// 4행
		int[][] jumsuArr = {{90, 80, 70},		// 이순신의 성적
							{80, 85, 76},		// 엄정화의 성적
							{85, 70, 90},		// 서강준의 성적
							{60, 80, 50}		// 이혜리의 성적
							}; 
		
		/*
		 =================
		  국어   영어   수학    총점
		 =================
		 90   80  70   240
		 80   85  76   241
		 85   70  90   245
		 60   80  50   190
		 */
		
		System.out.println("===========================");
		System.out.println("국어  영어  수학  총점  평균");
		System.out.println("===========================");
		
		
		for(int i=0; i<jumsuArr.length; i++) { // 4행
			int sum = 0;
			
			for(int j=0; j<jumsuArr[i].length; j++) { // 3열
				
				
				System.out.printf("%3d%s",jumsuArr[i][j]," ");
				sum+=jumsuArr[i][j];
			}

			float avg = Math.round((float)sum/jumsuArr[i].length*10)/10.0F;
			System.out.println(sum+"  "+avg);
		}
	
		
		System.out.println("\n======================================================\n");
		
		int[][] numArr = new int[4][]; // 4행 null열
		
/*
		numArr[0][0] = 10; // 열의 크기를 설정하지 않았으므로 NullPointerException 발생함.
		numArr[0][1] = 20;
		numArr[0][2] = 30;
*/		
		
		numArr[0] = new int[3]; // 첫번째 행은 3열
		numArr[1] = new int[2]; // 두번째 행은 2열
		numArr[2] = new int[4]; // 세번째 행은 4열
		numArr[3] = new int[3]; // 네번째 행은 3열
		
		numArr[0][0] = 10; 
		numArr[0][1] = 20;
		numArr[0][2] = 30;
		
		numArr[1][0] = 40;
		numArr[1][1] = 50;
//		numArr[1][2] = 60; // 2행은 열이 2개인데, 3개를 넣으면 ArrayIndexOutOfboundsException이 든다.
		
		numArr[2][0] = 40;
		numArr[2][2] = 90;// 배열의 변수는 자동 초기화가 된다.
		
		for(int i=0; i<numArr.length; i++) { // 이중for문에서는 바깥 for문이 행이다. 4행
			
			for(int j=0; j<numArr[i].length; j++) {// 안쪽 for문이 열이다. 2차원배열명[행의인덱스].length => 열 길이
													// 각 행에 있는 열의 갯수만큼만 돈다.
				
				String str = (j<numArr[i].length-1)?",":"\n"; 
				System.out.printf("%2d%s",numArr[i][j], str);
				
			}// end of for---------------------------
			
		}//end of for--------------------------------
		
		System.out.println("\n======================================================\n");
		
		
		
		int[][] numArr2 = {{10,20,30},
						   {40,50},
						   {70,0,90,0},
						   {0,0,0}
						   };
		
		for(int i=0; i<numArr2.length; i++) { // 이중for문에서는 바깥 for문이 행이다. 4행
			
			for(int j=0; j<numArr2[i].length; j++) {// 안쪽 for문이 열이다. 2차원배열명[행의인덱스].length => 열 길이
													// 각 행에 있는 열의 갯수만큼만 돈다.
				
				String str = (j<numArr2[i].length-1)?",":"\n"; 
				System.out.printf("%2d%s",numArr2[i][j], str);
				
			}// end of for---------------------------
			
		}//end of for--------------------------------
		
		
		
	}// end of main(String[] args)-------------------------------

}
