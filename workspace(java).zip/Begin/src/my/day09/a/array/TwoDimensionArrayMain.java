package my.day09.a.array;

public class TwoDimensionArrayMain {

	public static void main(String[] args) {
		
		// === 1차원 배열 === //
		int[] subjectArr = new int[5]; // 1행 5열
		
		/*
		            ---------------------
		  데이터값 ==> | 0 | 0 | 0 | 0 | 0 |     1행 5열
					---------------------			
		 index  ==>   0   1   2   3   4 
		 */
		
		// === 2차원 배열 === //
		int[][] pointArr = new int[4][3]; // 4행 3열
		
		
		/*
		 
		 ---------------------------
		 | [0][0] | [0][1] | [0][2] |
		 ---------------------------
		 | [1][0] | [1][1] | [1][2] |
		 ---------------------------
		 | [2][0] | [2][1] | [2][2] |
		 ---------------------------
		 | [3][0] | [3][1] | [3][2] |
		 ---------------------------
		 */
		
		pointArr[0][0] = 10;
		pointArr[0][1] = 20;
		pointArr[0][2] = 30;
		
		pointArr[1][0] = 40;
		pointArr[1][1] = 50;
//		pointArr[1][2] = 60;
		
		pointArr[2][0] = 70;
		pointArr[2][1] = 80;
		pointArr[2][2] = 90;

/*		
		pointArr[3][0] = 100;
		pointArr[3][1] = 110;
		pointArr[3][2] = 120;
*/		
		System.out.println("pointArr.length => " + pointArr.length);
		// pointArr.length => 4
		// 2차원배열명.length => 행의 길이가 나온다.
		// *1차원 배열은 열의 길이
		
		System.out.println("pointArr[0].length => " + pointArr[0].length);
		// pointArr[0].length => 3
		// 2차원배열명[행의인덱스].length => 그 행에 존재하는 열의 길이가 나온다.
		
		System.out.println("pointArr[1].length => " + pointArr[1].length);
		// pointArr[1].length => 3
		// 2차원배열명[행의인덱스].length => 그 행에 존재하는 열의 길이가 나온다.

		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		for(int i=0; i<pointArr.length; i++) { // 이중for문에서는 바깥 for문이 행이다. 4행
			
			for(int j=0; j<pointArr[i].length; j++) {// 안쪽 for문이 열이다. 2차원배열명[행의인덱스].length => 열 길이
				
				String str = (j<pointArr[i].length-1)?",":"\n"; // 꼴찌 앞까지는 ,를주고 꼴찌는 아무것도 안준다.
				System.out.printf("%2d%s",pointArr[i][j], str);
				
			}// end of for---------------------------
			
		}//end of for--------------------------------
		
		System.out.println("\n================ 성적결과 ================\n");
		
		// 과목 : 국어, 영어, 수학
		// 4행
		int[][] jumsuArr = {{90, 80, 70},		// 이순신의 성적
							{80, 85, 76},		// 엄정화의 성적
							{85, 70, 90},		// 서강준의 성적
							{60, 80, 50}		// 이혜리의 성적
							}; 
		
		/*
		 =================
		  국어   영어   수학    총점
		 =================
		 90   80  70   240
		 80   85  76   241
		 85   70  90   245
		 60   80  50   190
		 */
		
		System.out.println("===========================");
		System.out.println("국어  영어  수학  총점  평균");
		System.out.println("===========================");
		
		int korSum=0, engSum=0, mathSum=0;
		int[] totalArr= new int[jumsuArr.length]; // 크기는 인원수별, 사람별 총점이 담겨질 저장소
		// new int[4] << 사람이 더 늘어나거나 줄을 수 있기 때문에 유기적으로 변동되도록 이렇게 했다.
		
		float[] avgArr = new float[jumsuArr.length]; // 각 사람별 평균을 담아둘 배열
		
		
	

		
		
		for(int i=0; i<jumsuArr.length; i++) { // 행, 행의갯수
			
			int sum = 0;
			for(int j=0; j<jumsuArr[i].length; j++) {// 열, 그 행의 열 갯수
				
				sum += jumsuArr[i][j]; // 한 사람의 국어, 영어, 수학 점수를 누적합한다. 개인별 합계
				
				System.out.printf("%3d%s",jumsuArr[i][j], " ");
				
				// 국어는 전부다 0열, 영어는 전부다 1열, 수학은 전부다 2열
				if(j==0) { // 국어점수의 총합
					korSum += jumsuArr[i][j];
				}
				
				else if(j==1) {// 영어점수의 총합
					engSum += jumsuArr[i][j];
				}
				
				else if(j==2){// 수학점수의 총합
					mathSum += jumsuArr[i][j];
				}
				
				
			}// end of inner for-------------------------------
			
			float avg = Math.round((float)sum/jumsuArr[i].length*10)/10.0F; // Math.round는 int로 반환해서 밖에서 나누기 10.0을 해준다.
			// sum이 안쪽 for문을 빠져나와야 사람별 세 과목의 총합이 완성되기에 밖에서 avg를 구한다
			
			System.out.println(sum + "  " + avg); // 각 과목별 점수를 찍은 다음에, 총합 점수를 출력하고 줄바꿈
			
			totalArr[i] += sum; // 사람별  총점을 totalArr에 저장
			// 이순신의 총합 넣고, 엄정화의 총합 또 넣고, 서강준의 총합 또 넣고, 이혜리의 총합 또 넣고
			avgArr[i] += avg;
		}// end of outer for-----------------------------------
		
		
		
		System.out.println("---------------------------");
		
		int count = jumsuArr.length; // 4명이라는 말이다.
		
		
		float korAvg = Math.round((float)korSum/count*10)/10.0F; // 사람 수는 행의 수이다.
		float engAvg = Math.round((float)engSum/count*10)/10.0F;
		float mathAvg = Math.round((float)mathSum/count*10)/10.0F;
		
		int sumOfsum = 0;
		for(int i=0; i<totalArr.length; i++) { // 배열에 들어가진 사람들별 점수총합을 다시 뽑아서 누적합한다.
			sumOfsum+=totalArr[i];
			
		}// end of for----------------------
		
		float sumOfavg = 0.0F;
		for(int i=0; i<avgArr.length; i++) { // 배열에 들어가진 사람들별 평균점수를 다시 뽑아서 누적합한다.
			sumOfavg+=avgArr[i];
			
		}// end of for-------------------------
				
		
		float sumOfsumAvg = Math.round((float)sumOfsum/count*10)/10.0F;
		float avgOfAvg = Math.round(sumOfavg/count*10)/10.0F; // 이미 float 타입이라 float괄호 불필요
	
		
		System.out.println("합계 "+korSum+"  "+engSum+"  "+mathSum+"  "+sumOfsum+"  "+sumOfavg);
		System.out.println("평균 "+korAvg+"  "+engAvg+"  "+mathAvg+"  "+sumOfsumAvg+"  "+avgOfAvg);
		
		System.out.println("---------------------------");
		
		System.out.println("\n======================================================\n");
		
		int[][] numArr = new int[4][]; // 4행 null열
		
/*
		numArr[0][0] = 10; // 열의 크기를 설정하지 않았으므로 NullPointerException 발생함.
		numArr[0][1] = 20;
		numArr[0][2] = 30;
*/		
		
		numArr[0] = new int[3]; // 첫번째 행은 3열
		numArr[1] = new int[2]; // 두번째 행은 2열
		numArr[2] = new int[4]; // 세번째 행은 4열
		numArr[3] = new int[3]; // 네번째 행은 3열
		
		numArr[0][0] = 10; 
		numArr[0][1] = 20;
		numArr[0][2] = 30;
		
		numArr[1][0] = 40;
		numArr[1][1] = 50;
//		numArr[1][2] = 60; // 2행은 열이 2개인데, 3개를 넣으면 ArrayIndexOutOfboundsException이 든다.
		
		numArr[2][0] = 40;
		numArr[2][2] = 90;// 배열의 변수는 자동 초기화가 된다.
		
		for(int i=0; i<numArr.length; i++) { // 이중for문에서는 바깥 for문이 행이다. 4행
			
			for(int j=0; j<numArr[i].length; j++) {// 안쪽 for문이 열이다. 2차원배열명[행의인덱스].length => 열 길이
													// 각 행에 있는 열의 갯수만큼만 돈다.
				
				String str = (j<numArr[i].length-1)?",":"\n"; 
				System.out.printf("%2d%s",numArr[i][j], str);
				
			}// end of for---------------------------
			
		}//end of for--------------------------------
		
		System.out.println("\n======================================================\n");
		
		
		
		int[][] numArr2 = {{10,20,30},
						   {40,50},
						   {70,0,90,0},
						   {0,0,0}
						   };
		
		for(int i=0; i<numArr2.length; i++) { // 이중for문에서는 바깥 for문이 행이다. 4행
			
			for(int j=0; j<numArr2[i].length; j++) {// 안쪽 for문이 열이다. 2차원배열명[행의인덱스].length => 열 길이
													// 각 행에 있는 열의 갯수만큼만 돈다.
				
				String str = (j<numArr2[i].length-1)?",":"\n"; 
				System.out.printf("%2d%s",numArr2[i][j], str);
				
			}// end of for---------------------------
			
		}//end of for--------------------------------
		
		
		
	}// end of main(String[] args)-------------------------------

}
