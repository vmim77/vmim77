package my.day07.b.DOWHILE;

import java.util.InputMismatchException;
import java.util.Scanner;

public class PrimeNumberMain3 {
	
	// === 소수란? === 
	   // 소수란? 1과 자기 자신의 수로만 나누었을때 나머지가 0인 1이외의 정수
	   // 예> 1 부터 10까지의 소수를 나타내면 
	   //       2%2 ==> 0   2 는 소수
	   //       3%3 ==> 0   3 는 소수
	   //       4%2 ==> 0   4 는 소수가 아님 (2, 4)
	   //       5%5 ==> 0   5 는 소수
	   //       6%2 ==> 0   6 는 소수가 아님(2, 3, 6)
	   //       7%7 ==> 0   7 는 소수
	   //       8%2 ==> 0   8 는 소수가 아님(2, 4, 8)
	   //       9%3 ==> 0   9 는 소수가 아님
	   //      10%2 ==> 0  10 는 소수가 아님  (2, 5, 10)
	
	
		/*
	    ==실행결과==
	     ▷시작 자연수 : 1엔터
	     ▷끝 자연수 : 20엔터 
	  1 부터 20 까지의 소수는?
	  2,3,5,7,11,13,17,19
	
	  1부터 20 까지의 소수의 개수? 8개  
	
	  1부터 20 까지의 소수들의 합? 77 
	
	  === 프로그램 종료 ===      
		 */

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int startNo = 0, endNo = 0, sum = 0; 
		
		
		
		do {
			
			try {
			
				System.out.print("▷시작 자연수 : ");
				startNo = sc.nextInt(); // nextInt는 종결자가 엔터와 스페이스바이다.
											// 1엔터 or 1.345엔터 or 똘똘이엔터
				sc.nextLine(); // 스캐너 버퍼를 비워주기 위한 nextLine
				
				System.out.print("▷끝 자연수 : ");
				endNo = sc.nextInt(); // nextInt는 종결자가 엔터와 스페이스바이다.
											// 20엔터 or 20.345엔터 or 이순신엔터
				sc.nextLine(); // 스캐너 버퍼를 비워주기 위한 nextLine
				
				
				// if( !(startNo >= 1 && endNo >= 1))  
				// (시작값이 1보다 크고 그리고 끝값도 1보다 크다면)의 반대이니  값을 바꾸라고 해야한다.
				// 하나라도 false 면 모두 false가 되니깐 값을 바꾸라고 하는 식이 나와야 한다.
				// 또는
				
				
				if( startNo < 1 || endNo < 1) { // startNo는 1 이상이여야 한다.
					// 두 개중에 한 개라도 0이면
					System.out.println(">> 입력하시는 값은 모두 자연수 이여야 합니다!! <<"); //2번째 경우의 수 :  0이나 음수를 넣은 경우
					
				}
				
				else if (startNo >= endNo) {
					System.out.println(">> 두번째 입력한 숫자가 첫번째 입력한 숫자보다 커야 합니다!! <<"); //3번째 경우의 수 : 첫번째가 30이고 두번째가 0인 경우
				}
				
				else { // 올바르게 입력한 경우, 여기서 반복을 빠져나가게 해야 한다. do~while의 break가 들어가는 위치
					
					
					// 올바른 숫자들을 받아온 것이다.
					
					break;
				}
				
			} catch (InputMismatchException e) {
				System.out.println(">> 자연수만 입력하세요!! << \n"); // 1번째 경우의 수 : 문자열, 실수형을 넣은 경우
				sc.nextLine();// 스캐너버퍼에 엔터가 계속 담겨져 있으니 비워줘야 한다.
			}
		} while(true);
		// end of do~while--------------------------------------------
		
		///////////////////////////////////////////////////////////////////////////////////////
		
		// startNo ==> 1        5
		// endNo   ==> 20       20 
		//                 이라면
		// 1 부터 20까지의 소수를 구해야 한다.
		// 소수란? 1과 자기 자신의 수로만 나누었을때 나머지가 0인 1이외의 정수
		
		String resultStr = "";
		int cnt = 0;
		
		for(int i=startNo; i<=endNo; i++) {
			if(i == 1) // i가 소수인지 아닌지를 검사할 대상이다.
					   // 1은 소수가 아니므로 검사할 필요가 없다.그러므로 건너뛰어야 한다.
				continue;
				
			/*
		            나누기를 했을때 나머지가 얼마가 되는지 일일이 검사를 한다. 
		            만약에 i 가 2 이라면  ==> 2는 소수이다.
		            만약에 i 가 3 이라면  ==> 3%2 3는 소수이다.
		            만약에 i 가 4 이라면  ==> 4%2 == 0  4%3(검사할 필요가 없다)  4는 소수가 아니다.    
		            만약에 i 가 5 이라면  ==> 5%2 5%3 5%4  5는 소수이다. 
		            만약에 i 가 9 이라면  ==> 9%2 9%3 == 0  9%4(검사할 필요가 없다) 9는 소수가 아니다.       
	        */
			
			boolean isSosu = true; // 자기가 아닌 수로 나눴을 때 0이되면 false를 줘버릴 것이다.
			
			for(int j=2; j<i; j++) { // j가 분모에 들어갈 값이다. 분모는 자기보다 하나 작은 수까지 들어가야 한다.
				if(i%j == 0) { // 검사대상인 i는 소수가 아닌 경우 0으로 떨어진다.
					isSosu = false; // 소수가 아님을 표시!! 한다.
					break; // 중간에서 0으로 떨어지면 뒤에껀 검사할 필요가 없기 때문에
				}
				
					
			}//end of for-------------------------- // 소수인지 아닌지를 검사
			
			if(isSosu) { // 검사대상인 i가 소수이라면 resultStr에 쌓아준다.
				cnt++; // 소수의 개수
				sum += i; // 소수들의 누적 합계
				
				String comma =(cnt>1)?",":""; // 두번째 부터 나오는 소수부터는 소수 앞에 ,를 붙인다.
				resultStr += comma+i;
				
			}
			
			
			
			
		}// end of for------------------------
		
		System.out.println(startNo+" 부터 "+endNo+" 까지의 소수는?\n"+resultStr+"\n");
		System.out.println(startNo+" 부터 "+endNo+" 까지의 소수의 개수?\n"+cnt+"개\n");
		System.out.println(startNo+" 부터 "+endNo+" 까지의 소수의 합계?\n"+sum+"\n");
		
		
		sc.close();
		System.out.println("=== 프로그램 종료 === ");
	}// end of main(String[] args)-------------------------------------

}
