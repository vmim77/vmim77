package my.day07.b.DOWHILE;

import java.util.Scanner;

public class FactorialMain2Re {
	
	// === 입사문제 === //
    /*
       >> 알고 싶은 팩토리얼 수 입력 => 5엔터
       >> 5! = 120
       
       5! ==> 5*4*3*2*1
       7! ==> 7*6*5*4*3*2*1
     */

	public static void main(String[] args) {
		
		System.out.println("=== 입사문제 ===");
		
		Scanner sc = new Scanner(System.in);
		
		
		outer : do {
			
			try {
			
			System.out.print(">> 알고 싶은 팩토리얼 수 입력 => ");
			int num = Integer.parseInt(sc.nextLine());
			
			if(num <= 0) {
				System.out.println(">> 자연수만 입력하세요 !! <<");
				
				continue;
			}
			
			if(num > 10) {
				System.out.println(">> 10까지의 숫자만 적어주세요 !! <<");
				
				continue;
			}
			
			int fac = 1;
			int i = num;
			
			do {
				
				fac = fac*i;
				i--;
				
			}while(i>0);
			
			System.out.println(">> " + num +"! = " + fac);

			
			do {
				
				System.out.print(" >> 다시 할래?[Y/N] << ");
				String yn = sc.nextLine();
				
				if("y".equalsIgnoreCase(yn)) {
					break;
				}
				
				else if("n".equalsIgnoreCase(yn)) {
					System.out.println("===  프로그램 종료 ===");
					sc.close();
					break outer;
				}
				
				else
					System.out.println(">> Y 또는 N 중에 하나만 고르세요 <<");
				
				
				
			}while(true);
			
			
			
			} catch (NumberFormatException e) {
				System.out.println(">> 정수만 입력하세요 !! <<");
			}
		
		} while(true);
		
	}// end of main(String[] args)---------------------------------

}
