package my.day07.b.DOWHILE;

import java.util.Scanner;

public class PrimeNumberMain3Re {
	
	// === 소수란? === 
	   // 소수란? 1과 자기 자신의 수로만 나누었을때 나머지가 0인 1이외의 정수
	   // 예> 1 부터 10까지의 소수를 나타내면 
	   //       2%2 ==> 0   2 는 소수
	   //       3%3 ==> 0   3 는 소수
	   //       4%2 ==> 0   4 는 소수가 아님 (2, 4)
	   //       5%5 ==> 0   5 는 소수
	   //       6%2 ==> 0   6 는 소수가 아님(2, 3, 6)
	   //       7%7 ==> 0   7 는 소수
	   //       8%2 ==> 0   8 는 소수가 아님(2, 4, 8)
	   //       9%3 ==> 0   9 는 소수가 아님
	   //      10%2 ==> 0  10 는 소수가 아님  (2, 5, 10)
	
	
		/*
	    ==실행결과==
	     ▷시작 자연수 : 1엔터
	     ▷끝 자연수 : 20엔터 
	  1 부터 20 까지의 소수는?
	  2,3,5,7,11,13,17,19
	
	  1부터 20 까지의 소수의 개수? 8개  
	
	  1부터 20 까지의 소수들의 합? 77 
	
	  === 프로그램 종료 ===      
		 */

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int firstNum = 0, endNum = 0;
		
		
		do {
			try {
				System.out.print("▷시작 자연수 : ");
				firstNum = Integer.parseInt(sc.nextLine());
				
				System.out.print("▷끝 자연수 : ");
				endNum = Integer.parseInt(sc.nextLine());
				
				
				if(firstNum < 1 || endNum < 1) { // 0, 음수를 거른다.
					System.out.println(">> 자연수만 입력하세요!! <<");
				}
				
				else if(firstNum >= endNum) { // 시작값이 끝값보다 큰 경우를 거른다.
					System.out.println(">> 시작값은 끝값보다 작아야 합니다!! <<");
				}
				
				else { // 제대로 입력된 경우
					break;
				}
			} catch (NumberFormatException e) {
				System.out.println(">> 정수만 입력하세요!! <<");
			}
		} while(true);
		// end of do ~ while----------------------------------
		
		int sum = 0;
		int cnt = 0;
		String str = "";
		
		for(int i = firstNum; i<=endNum; i++) {
			if(i == 1)
				continue;
			
			boolean isSosu = true;
			
			
			for(int j=2; j<i; j++) {
				if(i%j == 0) {
					isSosu = false;
					break;
				}
			}// end of for------------------
			
			if(isSosu) {
				cnt++;
				sum += i;
				String comma = (cnt>1)?",":"";
				str += comma + i;
				
			}
			
		}// end of for---------------------
		System.out.println(firstNum+" 부터 "+endNum+" 까지의 소수는?\n"+str+"\n");
		System.out.println(firstNum+" 부터 "+endNum+" 까지의 소수의 개수?\n"+cnt+"개\n");
		System.out.println(firstNum+" 부터 "+endNum+" 까지의 소수의 합계?\n"+sum+"\n");
		
		sc.close();
		System.out.println("=== 프로그램 종료 ===");
		
	}// end of main(String[] args)-------------------------------------

}
