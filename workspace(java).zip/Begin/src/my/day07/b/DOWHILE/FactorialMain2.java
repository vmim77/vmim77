package my.day07.b.DOWHILE;

import java.util.Scanner;

public class FactorialMain2 {
	
	// === 입사문제 === //
    /*
       >> 알고 싶은 팩토리얼 수 입력 => 5엔터
       >> 5! = 120
       
       5! ==> 5*4*3*2*1
       7! ==> 7*6*5*4*3*2*1
     */

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		outer:
			do {
				
				try {
					
					System.out.print(">> 알고 싶은 팩토리얼 수 입력 => ");
		
					int num = Integer.parseInt(sc.nextLine()); // 실수니깐 0이나 음수도 일단 받아들일 것이다.
					
					if(num <= 0) { 
						System.out.println(">> 자연수만 입력하세요!! <<"); // 0이나 음수를 걸러낸다.
						
						continue; // do ~ while에서 continue를 만나면 while의 조건식으로 다시 간다.
								  // 그럼 do가 처음부터 다시 시작된다.
					}
					
					// 제대로 정수이면서, 자연수를 넣었을 때 이제 연산을 시작해준다.
						
					int result = 1; // 누적해서 곱해줘야 하니 0을 주면 안 된다.
					
					for(int i=num; i>0; i--) { // 입력한 것이 5이면, 5*4*3*2*1
						result*=i; // result = 1*5; 
								   // result = 1*5*4; 
								   // result = 1*5*4*3;
								   // result = 1*5*4*3*2;
								   // result = 1*5*4*3*2*1;
						           // i=1인 이후 0이 됨으로, 조건식에서 false가 떨어져서 for문을 빠져나간다.
						
					}// end of for------------------------
					// 얘는 자동으로 0이되면 빠져나가지기에 break가 필요없다.
					
					System.out.println(num+"! ==> "+result);
					
					for(;;) { // 또 할건지 묻는 무한루프
						
						System.out.print(">> 또 할래? [Y/N] => ");
						String yn = sc.nextLine();
						
						
						if("N".equalsIgnoreCase(yn)) { // No를 입력했으니 가장 바깥에 for를 끝내버려서 모든 프로그램을 종료시킨다.
							System.out.println("\n=== 프로그램 종료 ===");
							sc.close();
							break outer; // 프로그램 아예 종료시키는 break;	
						}
						
						else if ("Y".equalsIgnoreCase(yn)) { // Yes를 입력했으니 이 다시실행용 무한루프를 빠져나가게 해서 do로 보내서
															 // 다시 팩토리얼을 구하게 한다.
							break; // 또 할거지 묻는거 나가는 break; 그리고 다시 실행하러 간다.
						}
						
						else // y나 n를 안 친 경우
							System.out.println(">> Y 또는 N만 입력하세요!! <<");
					}// end of for----------------------
					
				
				} catch (NumberFormatException e) {
					System.out.println(">> 정수만 입력하세요!! <<");
				}
			} while (true);
			 // end of do~while--------------------------------------------
		
		

		

	}// end of main(String[] args)---------------------------------

}
