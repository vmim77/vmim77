package my.day07.c.random;

import java.util.Scanner;

public class MathRandomMain1 {

	public static void main(String[] args) {

		// === 랜덤한 정수를 뽑아낸다 === //
		double random = Math.random();

		System.out.println("random => " + random);
		// random => 0.6042092129534317
		// random => 0.09700980437958984
		// random => 0.5319560226065053
		// random => 0.780066221093447

		
		/*
        java.lang.Math.random() 메소드는 
        0.0 이상 1.0 미만의 실수(double)값을 랜덤하게 나타내어주는 메소드이다. 
                즉,  0.0 <= 임의의 난수(실수) < 1.0 
           
        1 부터 10까지중 랜덤한 정수를 얻어와 본다.
        
                랜덤한 정수 = (int)(Math.random()*구간범위)+시작값;
                
                구간범위 = Maximum - Minimum + 1 
        
        0.0        (int)(0.0*(10-1+1))+1         ==>  1
        0.23346438 (int)(0.23346438*(10-1+1))+1  ==>  3
        0.67835431 (int)(0.67835431*(10-1+1))+1  ==>  7
        0.99999999 (int)(0.99999999*(10-1+1))+1  ==> 10
        
        3 부터 7까지중 랜덤한 정수를 얻어와 본다.
        
        0.0        (int)(0.0*(7-3+1))+3         ==>  3
        0.23346438 (int)(0.23346438*(7-3+1))+3  ==>  4
        0.67835431 (int)(0.67835431*(7-3+1))+3  ==>  6
        0.99999999 (int)(0.99999999*(7-3+1))+3  ==>  7
        */ 
		
		
		int rand1 = (int)(random*(10-1+1))+1;
		int rand2 = (int)(random*(7-3+1))+3;
		int rand3 = (int)(random*('z'-'a'+1))+'a';
		
		
		System.out.println("1 부터 10까지 중 랜덤하게 발생한 값 : " + rand1 );

		System.out.println("3 부터 7까지 중 랜덤하게 발생한 값 : " + rand2 );
		
		System.out.println("a 부터 z 까지중 랜덤하게 발생한 소문자 : " + (char)rand3);
		
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		
		// 인증키는 랜덤한 숫자 3개(0~9) 랜덤한 소문자 4개로 만들어진다.
		// 예 >103qdtq 020abat
		
		String key = "";
		
		
		for(int i=0; i<3; i++) {
			int num = (int)(Math.random()*(9-0+1))+0; // rand를 호출하면 한 번만 돌려진 값이 계속 붙여진다.
			key += num;
		}

		for(int i=0; i<4; i++) {
			int num = (int)(Math.random()*('z'-'a'+1))+'a';
			key += (char)num;
		}

		System.out.println("인증키 => " + key);
		
		
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		
		Scanner sc = new Scanner(System.in);
		
		outer:
		do {
			try {
			
				System.out.print("선택[1 : 홀수 / 0 : 짝수] => ");
				String choice = sc.nextLine();
				
				int userno = Integer.parseInt(choice);
				
				//if( !(userno==1 || userno==0) ) {
				//또는
				if( userno!=1 && userno!=0 ) {// 제대로 선택 안 한 경우 // 0과 1이라면 둘 중 하나는 false가 되서 아래에 문구가 실행되지 않음으로!!
					System.out.println(">> 0 또는 1 만 입력하세요!! << \n");
				}
				
				//////////////////////////////////////////////////////
				
				else { // 제대로 선택한 경우 
					// PC 에서 랜덤하게 1 부터 10까지 중 하나를 만들자
					
					int pcno = (int)(Math.random()*(10-1+1))+1;
					
					String result ="";
					
					if(userno == pcno%2) { // PC에서 만든 숫자를 2로 나눠서 나머지가 0이면 짝수고, 1이면 홀수다
						result = "맞추었습니다.";

					}
					else {
						result = "틀렸습니다.";

					}
					
					System.out.println("컴퓨터가 낸수 : " + pcno + ", 결과는 => " + result);
					
					do {
						System.out.print("또 하시겠습니까? [Y/N] => ");
						String yn = sc.nextLine();
						if("y".equalsIgnoreCase(yn)) {
							break;
						}
						else if("n".equalsIgnoreCase(yn)) {
							break outer;
						}
						else {
							System.out.println("Y 또는 N 중에서 선택하세요!!");
						}
						
					}while(true);
					// end do while -----------------------------
					
				}
				
				
				
			} catch (NumberFormatException e) {
				System.out.println(">> 정수만 입력하세요!! << \n");
			}
		}while(true);// end do while--------------------------------
		
		sc.close();
		System.out.println("\n >> 프로그램 종료 <<");
	}// end of main(String[] args)-----------------------------

}
