package my.day07.c.random;



public class MathRandomMain1Re {

	public static void main(String[] args) {
		
		double random = Math.random();
		System.out.println("Random => " + random);

		// === 랜덤한 정수를 뽑아낸다 === //
	
		// random => 0.6042092129534317
		// random => 0.09700980437958984
		// random => 0.5319560226065053
		// random => 0.780066221093447

		
		/*
        java.lang.Math.random() 메소드는 
        0.0 이상 1.0 미만의 실수(double)값을 랜덤하게 나타내어주는 메소드이다. 
                즉,  0.0 <= 임의의 난수(실수) < 1.0 
           
        1 부터 10까지중 랜덤한 정수를 얻어와 본다.
        
                랜덤한 정수 = (int)(Math.random()*구간범위)+시작값;
                
                구간범위 = Maximum - Minimum + 1 
        
        0.0        (int)(0.0*(10-1+1))+1         ==>  1
        0.23346438 (int)(0.23346438*(10-1+1))+1  ==>  3
        0.67835431 (int)(0.67835431*(10-1+1))+1  ==>  7
        0.99999999 (int)(0.99999999*(10-1+1))+1  ==> 10
        
        3 부터 7까지중 랜덤한 정수를 얻어와 본다.
        
        0.0        (int)(0.0*(7-3+1))+3         ==>  3
        0.23346438 (int)(0.23346438*(7-3+1))+3  ==>  4
        0.67835431 (int)(0.67835431*(7-3+1))+3  ==>  6
        0.99999999 (int)(0.99999999*(7-3+1))+3  ==>  7
        */ 
		
		int rand1 = (int)(Math.random()*(10-1+1))+1;
		int rand2 = (int)(Math.random()*(7-3+1))+3;
		int rand3 = (int)(Math.random()*('z'-'a'+1))+'a';
		
		System.out.println("1 부터 10까지 중 랜덤하게 발생한 값 : " + rand1 );

		System.out.println("3 부터 7까지 중 랜덤하게 발생한 값 : " + rand2 );
		
		System.out.println("a 부터 z 까지중 랜덤하게 발생한 소문자 : " + (char)rand3);
		
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		
		// 인증키는 랜덤한 숫자 3개(0~9) 랜덤한 소문자 4개로 만들어진다.
		// 예 >103qdtq 020abat
		
		String key = "";
		
		for(int i=0; i<3; i++) {
			int num= (int)(Math.random()*(9-0+1))+1;
			key += num;
		}
		
		for(int i=0; i<4; i++) {
			int num = (int)(Math.random()*('z'-'a'+1))+'a';
			key += (char)num;
		}
		
		System.out.println("인증키는 => " + key);

		
		
		

		
		
	
	}// end of main(String[] args)-----------------------------

}
