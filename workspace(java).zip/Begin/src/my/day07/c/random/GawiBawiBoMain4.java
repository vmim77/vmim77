package my.day07.c.random;

import java.util.Random;
import java.util.Scanner;

public class GawiBawiBoMain4 {

	public static void main(String[] args) {

		Random rnd = new Random();
		
		Scanner sc = new Scanner(System.in);
		
		String str_userNum = "";
		
		do {
			System.out.println("============ 메뉴 ============");
			System.out.println("1.가위\t2.바위\t3.보\t4.게임종료");
			System.out.println("=============================");
			System.out.print(">> 선택하세요 => ");
			
			str_userNum = sc.nextLine();
			
			if(!"1".equals(str_userNum) && 
			   !"2".equals(str_userNum) &&
			   !"3".equals(str_userNum) &&
			   !"4".equals(str_userNum) ) {
				System.out.println("▷ 메뉴에 존재하지 않는 번호 입니다.\n");
				// continue;
				// 1, 2, 3, 4 중에 고르지 않았을 경우 처음부터 다시 돌아가게 한다.
			}
			else if(!("4".equals(str_userNum))) { // 위에서 continue를 써도 안 써도 상관없다. 왜냐면 나머지 값이면 그냥 빠져나가서 다시 do로 올라가서다.
				// 사용자가 1 또는 2 또는 3을 낸 경우
				
				// PC도 1 또는 2 또는 3중에 하나를 랜덤하게 내도록 한다.
				int pcNum = rnd.nextInt(3 - 1 + 1) + 1;
				
				int userNum = Integer.parseInt(str_userNum);
				String msg = "";
				
				// 사용자가 이긴 경우
				
				if( (pcNum == 1 && userNum == 2) ||
					(pcNum == 2 && userNum == 3) ||
					(pcNum == 3 && userNum == 1)) {
					msg = ">>> 사용자님이 이겼습니다!!\n";
				}
				// PC가 이긴 경우(사용자가 진 경우)
				else if( (pcNum == 1 && userNum == 3) ||
						 (pcNum == 2 && userNum == 1) ||
						 (pcNum == 3 && userNum == 2)) {
					msg = ">>> 사용자님이 졌습니다!!\n";
				}
				// 사용자와 PC가 비긴 경우
				else {
					msg = ">>> 사용자님이 비겼습니다!!\n";
				}
				
				System.out.println(msg);
			}
			
		} while (!("4".equals(str_userNum))); 
		// 이 부분을 게임종료 누르기 전까진 무한 반복으로 보여줘야 한다.
        // 느낌표가 왔으니깐 (  )가 탈출조건이다. 4번을 눌렀다면 탈출한다.
		// end of do~while---------------------------------------
		
		sc.close();
		System.out.println("\n========= 프로그램 종료 =========");
	}// end of main(String[] args)-------------------------------------

}
