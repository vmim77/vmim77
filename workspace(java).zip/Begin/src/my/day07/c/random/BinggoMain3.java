package my.day07.c.random;

import java.util.Random;
import java.util.Scanner;

public class BinggoMain3 {

	public static void main(String[] args) {

		Random rnd = new Random();
		int pcno =  rnd.nextInt(100 - 1 + 1)+1;; // 고정값
		
		
		Scanner sc = new Scanner(System.in);
		
		int cnt = 0; // 시도횟수
		/*
		  PC가 만들 수 있는 숫자는 1 ~ 100 까지중 아무거나 1개를 만든다.

		  59(PC가 랜덤하게 만든 숫자)
		  
		   		1 부터 100 사이의 숫자입력 => 50엔터 1번시도
		         50보다 큰값입니다.

		        1 부터 100 사이의 숫자입력 => 71엔터 2번시도
		         71보다 적은값입니다. 

		        1 부터 100 사이의 숫자입력 => 60엔터  3번시도
		         60보다 적은값입니다.

		        1 부터 100 사이의 숫자입력 => 58엔터 4번시도
		         58보다 큰값입니다.

		        1 부터 100 사이의 숫자입력 => 59엔터 5번시도 
		                 빙고!!  5번만에 맞추었습니다.       
		 */
		
		outer:
		do { // 전체프로그램이 계속 실행되게 한다.
			
				try {
					System.out.print("1 부터 100 사이의 숫자입력 => ");
					int userno = Integer.parseInt(sc.nextLine());
					
				
					if( userno < 1 || userno > 100) { // 1보다 작거나, 100보다 큰 값을 넣었다면
						
						// 1보다 작은 값을 넣었거나 또는 100보다 큰 값을 넣었다면 true 
						// userno < 1 && userno > 100
						// 1보다 작으면서,  100보다 큰 값을 넣었다면 true (모순)
						
						System.out.println("1~100까지의 숫자만 입력하세요!\n");
					}
					
					else { // 1 ~ 100에서 입력했으면
						cnt++;
						if(pcno > userno) {
							System.out.println(userno+"보다 큰값입니다.\n");
						}
						
						else if(pcno < userno) {
							System.out.println(userno+"보다 작은값입니다.\n");
						}
						
						else {
							System.out.println("#### 빙고!! 맞추었습니다. ####");
							System.out.println(cnt+"번시도");
							sc.close();
							break outer; // 프로그램 종료
						}
					
					}// end of else-------------------------------------
					
			
				} catch (NumberFormatException e) {
					System.out.println(">> 1 부터 100 사이의 숫자만 입력하세요!! <<\n");
				}
				
		}while(true);
		// end of do~while~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		
		System.out.println("\n ===== 프로그램 종료 =====");
		
	
	}// end of main(String[] args)-------------------------

}
