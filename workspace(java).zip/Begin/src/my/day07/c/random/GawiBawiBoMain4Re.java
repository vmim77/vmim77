package my.day07.c.random;

import java.util.Random;
import java.util.Scanner;

public class GawiBawiBoMain4Re {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		Random rnd = new Random();
		String str_userNo = "";

		do {
			
			System.out.println("============ 메뉴 ============");
			System.out.println("1.가위\t2.바위\t3.보\t4.게임종료");
			System.out.println("=============================");
			System.out.print(">> 선택하세요 => ");
				
			str_userNo = sc.nextLine();
			
			if(!"1".equals(str_userNo) && 
			   !"2".equals(str_userNo) &&
			   !"3".equals(str_userNo) &&
			   !"4".equals(str_userNo) ) {
				System.out.println(">> 메뉴에 있는 번호만 선택해주세요 <<");
			}
			
			// 1, 2, 3, 4 의 숫자들만 걸려져서 내려온다.
			
			else if(!("4".equals(str_userNo))) {
				int pcNo = rnd.nextInt(3-1+1)+1; // 1 ~ 3 중에 난수를 뽑는다.
				int userNo = Integer.parseInt(str_userNo); // 유저가 낸 가위 바위 보 번호
				
				if((pcNo == 1 && userNo == 2)||
				   (pcNo == 2 && userNo == 3)||
				   (pcNo == 3 && userNo == 1)) { // 유저가 이긴 경우
					System.out.println("이겼습니다!");
				}
				
				else if((pcNo == 1 && userNo == 3)||
						(pcNo == 2 && userNo == 1)||
						(pcNo == 3 && userNo == 2)) { // 유저가 진 경우
					System.out.println("졌습니다...");
				}
				
				else
					System.out.println("비겼습니다;;;");
						
			}
				
				
				
				
		} while(!("4".equals(str_userNo)));
		// 이 부분을 게임종료 누르기 전까진 무한 반복으로 보여줘야 한다.
        // 느낌표가 왔으니깐 (  )가 탈출조건이다. 4번을 눌렀다면 탈출한다.
		// end of do~while---------------------------------------
		
		sc.close();
		System.out.println("============ 프로그램 종료 ============");
	}// end of main(String[] args)-------------------------------------

}
