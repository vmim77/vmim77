package my.day07.a.WHILE;

public class WhileMain {
	/*
    === while 문 형식 ===

       변수의 초기화;

    while(조건식) {
       조건식이 참(true)이라면 반복해서 실행할 명령문을 실행하고,
       조건식이 거짓(false)이라면 while의 { } 이부분을 빠져나간다. 

       반복해서 실행할 명령문;
       증감식;
    }
	 */   
	public static void main(String[] args) {

		int cnt = 5, loop = 0; // 변수의 초기화
		while(loop < cnt) { // 0<5, 1<5, 2<5, 3<5, 4<5, 5<5(거짓) 5번 출력
			System.out.println((loop+1)+".안녕 자바~~");
			loop++;         // loop = 1;  2;   3;   4;   5;
		}// end of while-------------------------------
		
		/*
		  1.안녕 자바~~
		  2.안녕 자바~~
		  3.안녕 자바~~
		  4.안녕 자바~~
		  5.안녕 자바~~
		 */
		
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		
		cnt = 5; loop = 0; // 변수의 초기화, 변수를 맨 처음 만들때는 콤마(,)가 가능하지만 재활용이라면 세미콜론(;)로 구분한다.
		while(loop++ < cnt) { // 위의 식의 증감식을 안에다가 넣은 것이다. 0<5 loop=1, 1<5 loop=2, ...., 4<5 loop=5, 5<5 (거짓)
			System.out.println(loop+".Hello Java~~");
		}// end of while-------------------------------
			
		
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		cnt = 5; loop = 0; // 변수의 초기화;
		
		while(loop < cnt) { // 0<5 내려오면서 전위증감식으로 찍기 전에 loop는 1가 된다.
							// ..........
							// 4<5 내려오면서 전위증감식으로 찍기 전에 loop는 5가 된다.
			
			
			System.out.println(++loop+".Hi Eclipse~~"); // 항상 while문에는 증감식이 있어야 한다.
		}//end of while-----------------------------------
		
		
		
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		loop = 0; // 변수의 초기화, loop만 초기화 해준다.
		
		while(true) { // 무조건 참이기 때문에 아래에 System.out.println이 Unreachable code가 뜬다.
			System.out.println(++loop+".Hi 이클립스~~");
			if(loop == 5) 
				break; 
			
		}// end of while---------------------
		System.out.println("\n === 프로그램 종료 ===");
		
		
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		loop = 0; // 변수의 초기화;
		
		while(true) { // 무한loop while문
			
			if(++loop > 10) // 탈출조건 loop가 10보다 커지면(10까지 OK, false니깐 break 작동안함) break;
				break;
				
			if(loop%2 == 0) // loop가 짝수라면
				continue; // 아래로 내려가지 않고 while()의 괄호()속의 조건식으로 이동한다.
			
			System.out.println(loop+". Hi Oracle~~");
			
		}// end of while-------------------------
		
		/*
			1. Hi Oracle~~
			3. Hi Oracle~~
			5. Hi Oracle~~
			7. Hi Oracle~~
			9. Hi Oracle~~
		 */
		
		
		System.out.println("\n === 프로그램 종료 ===");
		
		
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		
		System.out.println("\n=== 5단 ===");
		loop = 0; // 변수초기화
		while(++loop<10) { // 10보다 작으면 출력식을 찍어라.
			System.out.println("5 * "+loop+" = "+(5*loop));
		}// end of while------------------------------
		
		
		System.out.println("\n === 프로그램 종료 ===");
		
		
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		System.out.println("\n=== 6단 ===");
		loop = 0;
		while(true) {
			if(++loop > 9) // 9보다 커지면 멈춰라, 10이 되면 빠져나간다.
				break;
			
			System.out.println("6 * "+loop+" = "+(6*loop));
			
	
		}// end of while------------------------
		
		
		
		System.out.println("\n === 프로그램 종료 ===");
		
		
		
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		System.out.println("\n=== 7단 ===");
		loop=0;
		while(!(++loop > 9)) { // !true = false     while문의 탈출조건을 쓴다. 
			//  ++loop > 9 true가 되어지면 빠져나가라   이렇게 쓰면 break를 쓸 필요가 없다.
			// 먼저 1 증가시켜준 값이 10이되면 나가라,  조건식이 false면 나가짐
			System.out.println("7 * "+loop+" = "+(7*loop));
		}// end of while-------------------------
		
		
		
		System.out.println("\n === 프로그램 종료 ===");
		
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		System.out.printf("%35s\n", "=== 구구단 ==="); 
		
		// 9행 8열
		// jul  dan
		int jul=0, dan=1;
		
		while(!(++jul > 9)){// 9행  행이 10이 되어지면(!(true)) 빠져나가라 (!true = false)
			
			/*
			  2*1=2 3*1=3 ............... 9*1=9
			*/
			
			while(!(++dan > 9)) { // 8열
				String str = (dan < 9)?"\t":"\n"; // 단이 9보다 작으면 탭, 단이 9보다 작지 않으면 줄바꿈
				System.out.print(dan+ "*" + jul + "=" + (dan*jul) + str);
				
				
				/*
				   2*1=2   3*1=3   4*1=4   .....  9*1=9
				   2*2=4   3*2=6   4*2=8   .....  9*2=18
				   2*3=6   3*3=9   4*3=12   .....  9*3=27
				 */
				
				
			}// end of while-----------------------
			
			// 여기에 오면 dan은 현재 10
			// 위에서 dan이 선위증감식으로 10이 되서 빠져나와서 현재 dan은 10이다.
			// 빠져나와서 다시 dan의 while로 들어가면 11이 되서 !(true)이 되기때문에 작동이 안 된다.
			
			dan = 1; // 그래서 단을 다시 초기화 시켜준다.
			
		}// end of while--------------------------
		
		
		
		System.out.println("\n === 프로그램 종료 ===");
		
	}// end of main(String[] args)----------------------------------

}
