package my.day07.a.WHILE;

public class WhileMainRe {
	/*
    === while 문 형식 ===

       변수의 초기화;

    while(조건식) {
       조건식이 참(true)이라면 반복해서 실행할 명령문을 실행하고,
       조건식이 거짓(false)이라면 while의 { } 이부분을 빠져나간다. 

       반복해서 실행할 명령문;
       증감식;
    }
	 */   
	public static void main(String[] args) {
		
		int cnt = 5, i = 0;
		
		while(i < cnt) {
			System.out.println((i+1)+". 안녕 자바~~");
			i++;
		}
	
		/*
		  1.안녕 자바~~
		  2.안녕 자바~~
		  3.안녕 자바~~
		  4.안녕 자바~~
		  5.안녕 자바~~
		 */
		
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
			cnt = 5; i = 0;
			
			while(i++ < cnt) {
				System.out.println(i+ ". Hello Java~~");
			}
			
			/*
			 1. Hello Java~~
			 2. Hello Java~~
			 3. Hello Java~~
			 4. Hello Java~~
			 5. Hello Java~~
			 */
		
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
			cnt = 5; i = 0;
			
			while(i<cnt) {
				System.out.println(++i+". Hi Eclipse~~");
			}
			/*
			1. Hi Eclipse~~
			2. Hi Eclipse~~
			3. Hi Eclipse~~
			4. Hi Eclipse~~
			5. Hi Eclipse~~
			 */
		
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		
			i = 0;
			
			while(true) {
				System.out.println(++i+". 안녕 이클립스~~");
				if(i == 5)
					break;
			}
			/*
			1. 안녕 이클립스~~
			2. 안녕 이클립스~~
			3. 안녕 이클립스~~
			4. 안녕 이클립스~~
			5. 안녕 이클립스~~
			 */
		
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		
		i = 0;
		
		while(true) {
			
			if(++i>10){ // ++i가 10보다 커지면 break, i는 1~10까지만 찍는다.
						// 10 > 10은 false니깐 작동 안함.
				break;
			}
			
			if(i%2==0) {
				continue;
			}
			
			System.out.println(i+". Hi Oracle~~");
			
			
			
		}
		
			

		
		/*
			1. Hi Oracle~~
			3. Hi Oracle~~
			5. Hi Oracle~~
			7. Hi Oracle~~
			9. Hi Oracle~~
		 */
		
		
	
		
		
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		System.out.println("== 5단 ==");
		
		i = 0;
		
		
		while(++i<10) {
			System.out.println("5*"+i+"="+(5*i));
			
		}
		
		
		
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		System.out.println("== 6단 ==");
	
		i = 0;
		
		while(true) {
			
			if(++i>9)
				break;
			System.out.println("6*"+i+"="+(6*i));

		}
		

		
		
		
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		System.out.println("== 7단 ==");
		
		i = 0;
		
		while(!(++i>9)) {
			System.out.println("7*"+i+"="+(7*i));
			
		}
		
		
		
		
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		
		System.out.println("== 구구단 ==");
		
		int jul = 0, dan = 1;
		
		while(!(++jul>9)) {
			while(!(++dan>9)) {
				System.out.print(dan+"*"+jul+"="+(dan*jul)+"\t");
	
			}
			// 위에서 dan이 10이 되서 빠져나왔음으로 현재 dan은 10이다.
			// 빠져나와서 다시 dan의 while로 들어가면 11이 되서 !(참)이 되기때문에 작동이 안 된다.
			dan=1;
			System.out.print("\n");
		}
		
		
		
		
		
		
		
	}// end of main(String[] args)----------------------------------

}
