package my.day05.b.FOR;

import java.util.Scanner;

public class Quiz12Main {

	public static void main(String[] args) {
		

		Scanner sc = new Scanner(System.in);

		
		for(;;) { 
			
			try {
				
				System.out.print("첫번째 정수 : ");
				String strFirstNo = sc.nextLine(); 
				
				int firstNo = Integer.parseInt(strFirstNo);
				
				System.out.print("두번째 정수 : ");
				String strSecondNo = sc.nextLine(); 
				int secondNo = Integer.parseInt(strSecondNo);
				
				int holSum = 0; 
				int jjakSum = 0; 
				
				int holsu = 0, jjaksu = 0;
				
				if(firstNo%2 == 0) { // 첫번째 입력받은 값이 짝수이라면
									 // 예 > 2
					holsu = firstNo + 1;  // 예 > holsu = 3
					jjaksu = firstNo;     // 예 > jjaksu = 2
				}
				else { // 첫번째 입력받은 값이 홀수이라면
					   // 예 > 3
					holsu = firstNo;      // 예 > holsu = 3
					jjaksu = firstNo + 1; // 예 > jjaksu = 4
				}
				
				// == 홀수 및 짝수의 합을 구한다. == //
				
				for(;;) {
					
					if(holsu <= secondNo) // 처음 입력한 값 3이라면, 5 7 9 
						holSum += holsu;
					if(jjaksu <= secondNo) // 처음 입력한 값 3이라면 4 6 8 10
						jjakSum += jjaksu;
					
					holsu+=2; 
					jjaksu+=2;
					
					if(holsu > secondNo && jjaksu > secondNo)
						// 9 > 10(false) && 10>10 (false)
						// 11 >10 (true) && 12>10 (true)
						break;
					
					
				}// end of for ---------------------------------------
	
				
				System.out.println(strFirstNo + " 부터 " + strSecondNo + "까지의 홀수의 합은 : " + holSum + "\n"
								 + strFirstNo + " 부터 " + strSecondNo + "까지의 짝수의 합은 : " + jjakSum);
				
				sc.close();
				break;
			} catch (NumberFormatException e) {
				System.out.println(">> 정수를 입력하세요!! <<");
			}
			
			
			
		}// end of for--------------------------------------------------
		

		
		
	}// end of main(String[] args)

}
