package my.day05.b.FOR;

public class Quiz10MainRe {
	
	/*
	   알파벳 소문자를 아래처럼 출력하세요.
	   a, b, c, d, e, ..................,x, y, z
	 */
	
	// 'A' => 65, 'a' => 97, '0' => 48, space => 32
	
	public static void main(String[] args) {
		
		
		
		for(int i=0; i<'z'-'a'+1; i++) {
			char ch = (char)('a'+i); // 97+0 => 'a' 97+1 => 'b'
			String str = (i < 'z'-'a')?",":"";
			// i<'z'-'a'+1 는 'z'까지
			// i<'z'-'a' 는 'y'까지
			
			
			System.out.print(ch+str);
			// 내려와서 a+"," 한 번 찍고 다시 올라가서
			// 내려와서 b+"," 한 번 찍고 다시 올라가서
			
		}// end of for----------------------------
		 // a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z

		
		/*
		   알파벳 소문자를 아래처럼 출력하세요.
		  a,c,e,g,i,k,m,o,q,s,u,w,y
		 */
		
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		for(int i=0;i<'z'-'a'+1; i++ ) {
			char ch = (char)('a'+i);
			if((ch+0)%2 != 0) {				
				String str = (i < 'z'-'a'-1)?",":"";
				System.out.print(ch+str);
			}
			else continue;
		}// end of for--------------------
		
		// a,c,e,g,i,k,m,o,q,s,u,w,y
		
	}// end of main(String[] args)-----------------------------

}
