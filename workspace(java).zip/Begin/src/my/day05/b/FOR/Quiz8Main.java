package my.day05.b.FOR;

public class Quiz8Main {

	public static void main(String[] args) {

		String word = "Abz3Sa0#$T";
		
		int upperCnt = 0, lowerCnt = 0, numberCnt =0, specialCnt =0;
		
		for(int i=0; i<word.length(); i++) {
			
			char ch = word.charAt(i); // A b z 3 S a 0 # $ T
			
			if(Character.isUpperCase(ch)) // 대문자인지 검사
				upperCnt++;
			
			else if(Character.isLowerCase(ch)) // 소문자인지 검사
				lowerCnt++;
			
			else if(Character.isDigit(ch)) // 숫자인지 검사
				numberCnt++;
			
			else 
				specialCnt+=1; // 특수문자인지 검사

			}// end of for-----------------------

		
		
		
		System.out.println(word+"\n"
							+"대문자 개수 : " + upperCnt + "\n"
							+"소문자 개수 : " + lowerCnt +  "\n"
							+"숫자 개수 : " + numberCnt +  "\n"
							+"특수문자 개수 : " +specialCnt + "\n");
		/*
		 	Abz3Sa0#$T
		 	대문자 개수 : 3
		 	소문자 개수 : 3
		 	숫자 개수 : 2
		 	특수문자 개수 : 2
		 */
		
		
	}// end of main(String[] args-------------------------------------

}
