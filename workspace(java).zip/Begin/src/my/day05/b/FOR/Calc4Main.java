package my.day05.b.FOR;

import java.util.Scanner;

/*
    >> 실행결과 <<
	 첫번째 정수 입력 => 똘똘이
	>>> 정수만 입력하세요!! <<<
	
	첫번째 정수 입력 => superman
	>>> 정수만 입력하세요!! <<<
	
	첫번째 정수 입력 => 10
	두번째 정수 입력 => 엄정화
	>>> 정수만 입력하세요!! <<<
	
	두번째 정수 입력 => 4
	사칙연산자 선택(+ - * /) => $$$
	>> 사칙연산(+ - * /)만 선택하세요!! <<
	
	사칙연산자 선택(+ - * /) => +
	10+4=14
*/	


public class Calc4Main {

	public static void main(String[] args) {
		
		
		Scanner sc = new Scanner(System.in);
		
		int num1 = 0, num2 = 0; // num1이 for 괄호 안에 갇히니 지역변수가 되서 밖으로 빼줘서 아래에서도 쓸 수 있게 해줌
		

		// 유효성 검사 1
		for(;;) {
			System.out.print("첫번째 정수 입력 => "); // 10엔터, 똘똘이엔터
			try {
				num1 = Integer.parseInt(sc.nextLine());
				break;
				
			} catch(NumberFormatException e) { // 문자열을 입력하면 try쪽이 아니라 catch쪽으로 가서 계속 반복된다.
				System.out.println(">>> 정수만 입력하세요!! <<<");
			}
		}// end of for--------------------------------------------
		
		
		
		// 유효성 검사 2
		for(;;) {
			System.out.print("두번째 정수 입력 => "); 
			try {
				num2 = Integer.parseInt(sc.nextLine());
				break;
				
			} catch(NumberFormatException e) {
				System.out.println(">>> 정수만 입력하세요!! <<<");
			}
		}// end of for--------------------------------------------
		
		
		String operator = ""; 
		
		
		// 유효성 검사 3
		for(;;) {
			System.out.print("사칙연산자 선택(+ - * /) =>  "); 
			operator = sc.nextLine(); 
			
			if("+".equals(operator) || "-".equals(operator)|| "*".equals(operator)|| "/".equals(operator))
				break;  
			           
					   
			else
				System.out.println(">> 사칙연산(+ - * /)만 선택하세요!! <<");
		}// end of for-------------------------------------------------------
				
		String result = "";   
		
		if("+".equals(operator)) {
			result = String.valueOf(num1 + num2);
		}
		else if("-".equals(operator)) {
			result = String.valueOf(num1 - num2);
		}
		else if("*".equals(operator)) {
			result = String.valueOf(num1 * num2);
		}
		else if("/".equals(operator)) {
			if(num2 == 0)
				result = "분모에는 0이 올 수 없습니다."; 
	
			else 
				result = String.valueOf((double)num1 / num2);
		}// end of if--------------------------------------------------------
		
		//삼항연산자
		result =("/".equals(operator) && num2 == 0) ? result : num1 + operator + num2 + "="+result;
		
		System.out.println("\n결과는 => " + result);
	
		sc.close();
	}// end of main(String[] args)----------------------------

}
