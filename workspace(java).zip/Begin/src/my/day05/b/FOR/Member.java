package my.day05.b.FOR;

import java.util.Scanner;

public class Member { 

	// === field ===
	String id;
	String pwd;   
	String name; 
	
	
	// === method ===
	// 회원가입 method
	void register(Scanner sc) { // 메소드에 매개변수로 들어올 값을 정의한다.
								// 이 메소드는 스캐너에 입력되어진 값만 받겠다는 의미이다.
		
		System.out.println(">>> 회원가입 <<<");
		
		System.out.print("1. 아이디 : ");
		id = sc.nextLine();
		
		for(;;) {
			
			System.out.print("2. 비밀번호(8글자 이상 15글자 이하에서 영문자,숫자,특수기호가 혼합되어야 함)  : ");
			String pwd = sc.nextLine();
			if(isCheckPwd(pwd)) {
				this.pwd = pwd;   //정책이 맞다면 이 지역변수 pwd를 필드에 넣어줘야 한다.
				break;
			}
			else { //정책에 안 맞을 때
				System.out.println("\n>>> 암호는 8글자 이상 15글자 이하에서 영문자,숫자,특수기호가 혼합되어야 합니다. <<< \n");
				
			}
			
		}
		System.out.print("3. 회원명 : ");
		name = sc.nextLine();
		
		System.out.println("");
		
		showInfo();
		
	}// end of register()-------------------------------
	
	// === method ===
	// 비밀번호정책에 맞는지 틀리는지 검사해주는 method
	// 비밀번호정책은 8글자 이상 15글자 이하에서 영문자,숫자,특수기호가 혼합되어야 함
	boolean isCheckPwd(String pwd) {
			// "aB34$" ,null ,"aBcdef34$123123" ,"qwer1234$"
		    // 일단 글자 길이부터 체크한다.
		
		boolean result = false; // 불린은 기본값이 false이다.
		
		
		
		if(pwd != null) { // 일단 null인지 아닌지 검사
			
			boolean flagAlphabet=false, flagNum=false, flagSpecial=false;
			
			int len = pwd.length(); // null이 아니니깐 length를 쓸 수 있다.
			
			if(8 <= len && len <= 15) { // 그 다음에 글자 길이를 검사한다.
				
				for(int i=0; i<len; i++) { // 글자를 하나하나 검사해서 영문자, 숫자, 특수기호가 들어갔는지 확인
					
					//"qwer1234$" ==> "qwer1234$".charAt(0) ==> 'q'
					//				  "qwer1234$".charAt(1) ==> 'w'
					//                "qwer1234$".charAt(4) ==> '1'
					//                "qwer1234$".charAt(8) ==> '$'
					
					char ch = pwd.charAt(i);
					
					
					if(Character.isAlphabetic(ch+0)) {// 소문자든 대문자든 알파벳이면 true. 대신 int형이 매개변수로 들어와야 한다.
													  // int보다 작은 byte, short, char는 사칙연산 만나면 자동으로 int로 바뀐다.
						flagAlphabet=true;
					}
					
					else if(Character.isDigit(ch)) {
						flagNum=true;
					}
					else {
						flagSpecial=true; // 한글도 특문 취급해짐
					}
					
				}// end of for----------------------------
				
				if(flagAlphabet && flagNum && flagSpecial) {//영문 true & 숫자 true & 특문 true 여야 비번이 만들어질 수 있다. (모두 true여야 정책에 맞게 만든 뜻이란 것)
					result = true;
				}
				
				
			}// end of len if --------------------------------------
		}// end of pwd if-------------------------------------------
		
		
		return result;
	}// end of isCheckPwd(String pwd) {} ---------------------------------
	
	
	
	void showInfo() { 
	
		System.out.println("\n==== 회원정보 ====\n"
				+ "1. 아이디 : " + id + "\n"
				+ "2. 비밀번호 : " + pwd + "\n"
				+ "3. 성명 : " + name + "\n");
	
	}

}
