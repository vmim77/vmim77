package my.day05.b.FOR;

public class Quiz10Main {

	public static void main(String[] args) {
		
		/*
		   알파벳 소문자를 아래처럼 출력하세요.
		   a, b, c, d, e, ..................,x, y, z
		 */
		
		for(int i=0; i<'z'-'a'+1;i++) {
			char ch = (char)('a'+i);    // 97+0 => 'a'
										// 97+1 => 'b'
			                            // 97+2 => 'c'
			
			String str = (i<'z'-'a')?",":"";
			// i<'z'-'a'+1 는 'z'까지
			// i<'z'-'a' 는 'y'까지
			// ch != 'z'
			
			
			System.out.print(ch+str); 
			
		}// end of for----------------------------
		
		// a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z
		
		
		
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		
		
		/*
		   알파벳 소문자를 아래처럼 출력하세요.
		  a,c,e,g,i,k,m,o,q,s,u,w,y
		 */
		
		int cnt = 'z'-'a'+1; // z까지 해라  ex. 10(z)-1(a)+1
		for(int i=0; i<cnt; i++) {
			char ch = (char)('a'+i);
			
			if((ch+0)%2 == 0) // 'a' = 97, ASCII가 홀수인 알파벳만 나오게 하려면 이렇게 조건식을 준다.
				continue; // 짝수알파벳이면 출력을 하지 않고, 증감식으로 다시 올라간다.
				String str =(i<cnt-2)?",":""; // cnt는 z까지 cnt-1는 y까지 cnt-2는 x까지 콤마(,)를 준다.
				System.out.print(ch+str); 
		}// end of for------------------------------
		
		// a,c,e,g,i,k,m,o,q,s,u,w,y
		
	}// end of main(String[] args)-----------------------------

}
