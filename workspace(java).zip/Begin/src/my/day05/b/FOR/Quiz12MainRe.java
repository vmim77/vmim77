package my.day05.b.FOR;

import java.util.Scanner;

public class Quiz12MainRe {

	public static void main(String[] args) {
		
		
		Scanner sc = new Scanner(System.in);
		for(;;) {
			
			try {
				
				System.out.print("첫번째 정수 : ");
				String strFirstNo = sc.nextLine(); // 출력용 입력 시작숫자 고정값
				
				int firstNo = Integer.parseInt(strFirstNo);
				
				System.out.print("두번째 정수 : ");
				String strSecondNo = sc.nextLine(); // 출력용 입력 마지막숫자 고정값
				
				int secondNo = Integer.parseInt(strSecondNo);
				
				int holsum = 0, jjaksum = 0; // 홀 & 짝수용 누적합계 저장소
				int holsu = 0, jjaksu = 0; 
			
				if(firstNo%2==0) { // 처음 들어온 숫자가 짝수인 경우
					holsu = firstNo+1;
					jjaksu = firstNo;
				}
				else { // 처음 들어온 숫자가 홀수인 경우
					holsu = firstNo;
					jjaksu = firstNo+1;
				}
				
				// == 홀수 및 짝수의 합을 구한다. == //
				for(;;) {
					
					if(holsu<=secondNo) // 3이라면 5 7 9
						holsum+=holsu;
					if(jjaksu<=secondNo) // 2이라면 4 6 8 
						jjaksum+=jjaksu;
					
					holsu += 2;
					jjaksu += 2;
					
					if(holsu > secondNo && jjaksu > secondNo) {
						// 1부터 10까지 입력
						// 홀수 : 1 , 짝수 : 2 false false
						// ....................
						// 홀수 : 9 , 짝수 : 10 false false
						// 홀수 : 11 , 짝수 : 12 true true
						
						// 위에 누적합계에 더해주고 내려와서 +2를 한 값이 범위 안이면 계속 식을 돌리고
						// +2를 한 값이 범위 밖이면 내보낸다.
						break;
					}
					
					
				}// end of for
			
			System.out.println(strFirstNo + " 부터" + strSecondNo + "까지의 홀수의 합계는 " + holsum+"\n"
							 + strFirstNo + " 부터" + strSecondNo + "까지의 짝수의 합계는 " + jjaksum);
				
			sc.close();
			break;
			} catch (NumberFormatException e) {
				System.out.println("정수를 입력하세요!!");
			}
		}// end of for
	}// end of main(String[] args)

}
