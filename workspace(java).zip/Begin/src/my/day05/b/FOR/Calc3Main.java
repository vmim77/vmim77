package my.day05.b.FOR;

import java.util.Scanner;

/*
    >> 실행결과 <<
    
	첫번째 정수 입력 => 똘똘이
	>>> 정수만 입력하세요!! <<<
	
	첫번째 정수 입력 => 10
	두번째 정수 입력 => 4
	사칙연산자 선택(+ - * /) => $$$
	>> 사칙연산(+ - * /)만 선택하세요!! <<
	
	사칙연산자 선택(+ - * /) => +
	10+4=14
*/	
public class Calc3Main {

	public static void main(String[] args) {
		
		
		Scanner sc = new Scanner(System.in);
		
		try {
			
		
				System.out.print("첫번째 정수 입력 => "); 
				int num1 = Integer.parseInt(sc.nextLine());
			
				System.out.print("두번째 정수 입력 => "); 
				int num2 = Integer.parseInt(sc.nextLine());
				
				// 아래부분을 반복해서 출력시켜줘야 한다. 
				// 사용자가 몇 번을 잘못칠지 모르니 횟수를 잡을 수 없다.
				// 무한반복으로 하고, 입력받은 operator가 사칙연산일때 break를 하게 해준다.
				
				String operator = ""; //operator가 for의 괄호 안에 갇혀서 지역변수가 됐기 때문에, 밖으로 빼준다.
				
				
				// 유효성 검사
				for(;;) {
					System.out.print("사칙연산자 선택(+ - * /) =>  "); 
					operator = sc.nextLine(); // 여기서 넣어준 사칙연산자가 밖으로 나가줌
					
					if("+".equals(operator) || "-".equals(operator)|| "*".equals(operator)|| "/".equals(operator))
						break; // &&을 넣어주면 앞에서 false가 하나라도 생기면 뒤에가서 내가 친 사칙연산자를 찾아주지 않고 그냥 else만 반복함
					           // ex. &&이면 나는 사칙연산자 - 를 제대로 넣었는데 and라서 앞에서 false가 하나라도 나오면 전부 false가 나와버림
							   // 결국엔 사칙연산자를 똑바로 쳤는데도 제대로 치라는 메세지를 출력시킴
					else
						System.out.println(">> 사칙연산(+ - * /)만 선택하세요!! <<");
				}// end of for-------------------------------------------------------
						
				String result = "";   
				
				if("+".equals(operator)) {
					result = String.valueOf(num1 + num2);
				}
				else if("-".equals(operator)) {
					result = String.valueOf(num1 - num2);
				}
				else if("*".equals(operator)) {
					result = String.valueOf(num1 * num2);
				}
				else if("/".equals(operator)) {
					if(num2 == 0)
						result = "분모에는 0이 올 수 없습니다."; 
			
					else 
						result = String.valueOf((double)num1 / num2);
				}// end of if--------------------------------------------------------
				
				result =("/".equals(operator) && num2 == 0) ? result : num1 + operator + num2 + "="+result;
				
				System.out.println("결과는 => " + result);
				
		} catch(NumberFormatException e) { 
			System.out.println(" >>> 정수만 입력하세요 <<< ");
		}
		sc.close();
		
	}// end of main(String[] args)----------------------------

}
