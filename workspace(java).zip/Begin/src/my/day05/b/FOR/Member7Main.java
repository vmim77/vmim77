package my.day05.b.FOR;

import java.util.Scanner;

public class Member7Main {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		Member mbr = new Member();
		mbr.register(sc); // 회원가입 메소드
		
		
		System.out.println(">>> 프로그램 종료 <<<");
		sc.close();
	}// end of main(String[] args)---------------

}
