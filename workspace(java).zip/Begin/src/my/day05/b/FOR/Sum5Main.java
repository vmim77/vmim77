package my.day05.b.FOR;

public class Sum5Main {

	public static void main(String[] args) {
		
		int sum = 0;
		
		for(int i=1; i<=10; i++) {
			sum += i; // sum = sum + i;
					  // sum = 0 + 1; ==> 1번째 반복
					  // sum = 0 + 1 + 2; ==> 2번째 반복
					  // sum = 0 + 1 + 2 + 3; ==> 3번째 반복
					  // .......................
					  // sum = 0 + 1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9 + 10 ==> 10번째 반복
			
		}// end of for------------------------------
		
		// 1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9 + 10 ==> 55
		
		System.out.println("1부터 10까지의 누적의 합계 : " + sum);
		// 1 부터 10 까지의 누적의 합계 : 55
		
		
		// Quiz 1
		// 1 부터 10 까지의 누적의 합계
		// 결과물 : 1+2+3+4+5+6+7+8+9+10=55
		sum = 0;
		String str = "";
		
		for(int i=1; i<=10; i++) {
			sum += i; 
			
			// str += i; str = ""+1+2+3+4+5+6+7+8+9+10; 12345678910
			// str += i+"+"; str = ""+1+2+3+4+5+6+7+8+9+10; 1+2+3+4+5+6+7+8+9+10+
			
			if(i < 10)
				str += i+"+";
			else
				str += i; 
			
		}// end of for------------------------------
		
		System.out.println(str+"="+sum);
		
		

		

	}// end of main(String[] args)---------------------------------

}
