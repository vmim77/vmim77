package my.day05.b.FOR;

// System.out.println("2. 최초로 숫자가 나오는 곳의 앞까지 문자열 출력 ==> " + str);
// System.out.println("2. 최초로 숫자가 나오는 곳의 앞까지의 문자열의 길이 ==>" + cnt);

public class Quiz9MainRe {

	public static void main(String[] args) {
	
		String word = "super$man";
		String str = "";
		int cnt = 0;
		
		boolean flagdigit = false;
		
		for(int i=0;i<word.length();i++) {
			char ch = word.charAt(i);
			
			if(Character.isDigit(ch))
				flagdigit=true;
			
		}//end of for-------
		if(flagdigit) {
			for(int i=0; i<word.length(); i++) {
				char ch = word.charAt(i); // 0 => s, 1 => u, 2 => p, 3 => e, 4 => r, 5 => 0
				  
				if(!Character.isDigit(ch)) { // 숫자가 아니면 내려간다.
					str += ch; // str = str + ch; // 숫자가 아니라면 str에 계속해서 문자열이 합쳐진다.
					cnt++; // 그리고 문자열의 갯수를 센다.
				}
				else
					break;
				
			}// end of for--------------------------
		
		}
		
		System.out.println("2. 최초로 숫자가 나오는 곳의 앞까지 문자열 출력 ==> " + str);
		System.out.println("2. 최초로 숫자가 나오는 곳의 앞까지의 문자열의 길이 ==>" + cnt);
	}// end of main(String[] args)-----------------------

}
