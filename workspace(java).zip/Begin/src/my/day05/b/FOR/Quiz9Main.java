package my.day05.b.FOR;

public class Quiz9Main {

	public static void main(String[] args) {
		// 이 풀이는 숫자가 있다는 것을 전제로 푼 것이기에 숫자가 없는 word가 들어오면 오류가 난다.

		String word = "super007Man";
		//String word = "superMan";
		
		String str = ""; // 결과물
		int cnt=0; // cnt는 문자열 길이와 똑같다. 
				
		
		boolean flagDigit = false;
		
		for(int i = 0;i<word.length(); i++) { 
			char ch = word.charAt(i);
			
			if(Character.isDigit(ch)) { // 문자를 끝까지 하나하나 봐서 숫자가 있다면 깃발을 올린다.
				flagDigit = true;
			}
			
				
			
			
		}// end of for------------------------------------------
		
		/*
		   String word = "super007Man"; 이라면 
		   flagDigit = true; 가 될 것이다.
		   
		   String word = "superMan"; 이라면
		   flagDigit = false; 가 될 것이다.
		 */
		
		if(flagDigit) { // 검색하고자 하는 것에 숫자가 있는 경우 String word = "super007Man";
			            // true면 str과 cnt를 뽑아올 것이다.
			
			for(int i=0; i<word.length(); i++) {
				
				char ch = word.charAt(i);
				
				if(!Character.isDigit(ch)) { // 숫자가 아니라면
					str += ch; // str = str + ch;
							   //        ""  + 's';
							   //        "s" + 'u';
							   // .......
							   // str = "super"
					cnt++;
				}
				
				else { // '0'
					break;
				}
			}// end of for------------------------------
			
		}
	
		System.out.println("1. 최초로 숫자가 나오는 곳의 앞까지 문자열 출력 ==> " + str);
		System.out.println("1. 최초로 숫자가 나오는 곳의 앞까지의 문자열의 길이 ==>" + cnt);
		
		
		// 1. 최초로 숫자가 나오는 곳의 앞까지 문자열 출력 => super
		// 2. 최초로 숫자가 나오는 곳의 앞까지의 문자열의 길이 => 5
				
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		str="";
		cnt=0;
		
		
		if(flagDigit) {
			for(int i = 0;;) { // 첫번째 for에서 반복의 횟수만 없애버린 것, 어차피 숫자만 나오면 자동으로 멈춰진다.
				char ch = word.charAt(i++); // 증감식이 없어서 i가 0으로 고정되니 i++로 계속 증가하게 해준다.
											// 전위이면 0은 빠져버리고 1부터 되어버린다.
										    // 후위로 0부터 글자를 뽑아줘야 한다.
				// word.charAt(0) 's' i=>1
				// word.charAt(1) 'u' i=>2
				// word.charAt(2) 'p' i=>3
				// word.charAt(3) 'e' i=>4
				// word.charAt(4) 'r' i=>5
				// word.charAt(5) '0' i=>6 //숫자를 넣고 글자를 뽑은다음에 바로 변수를 증감시킴!!
				
				
				
				if(!Character.isDigit(ch)) { 
					str += ch; 
					
					cnt++;
				}
				
				else { // '0'
					break;
				}
			}// end of for-------------------------
		}
		
		
		
		System.out.println("2. 최초로 숫자가 나오는 곳의 앞까지 문자열 출력 ==> " + str);
		System.out.println("2. 최초로 숫자가 나오는 곳의 앞까지의 문자열의 길이 ==>" + cnt);
		
		
		

	}// end of main(String[] args)-----------------------

}
