package my.day05.b.FOR;

public class Quiz8MainRe {
	
	/*
 	Abz3Sa0#$T
 	대문자 개수 : 3
 	소문자 개수 : 3
 	숫자 개수 : 2
 	특수문자 개수 : 2
 */

	public static void main(String[] args) {

		String word = "Abz3Sa0#$T"; // 10자리
	
		int len = word.length(); // len = 10;
		
		int upperStr = 0, lowerStr = 0, digitStr = 0, specialStr = 0;
		
		for (int i=0;i<len;i++) { 
			
			char ch = word.charAt(i);
			
			if(Character.isUpperCase(ch))
				upperStr++;
			else if(Character.isLowerCase(ch))
				lowerStr++;
			else if(Character.isDigit(ch))
				digitStr++;
			else
				specialStr++;
			
			
		}// end of for-------------------------
	
		System.out.println(word + "\n"
							+"대문자 개수 : " + upperStr +"\n"
							+"소문자 개수 : " + lowerStr +"\n"
							+"숫자 개수 : " + digitStr +"\n"
							+"특수문자 개수 : " + specialStr);

		
	}// end of main(String[] args-------------------------------------

}
