package my.day05.b.FOR;

import java.util.Scanner;

/*
		=== 실행결과 ===
		
		>> 누적해야할 시작 정수 => 그냥엔터 똘똘이엔터  2.567엔터 (첫번째 경우의 수)
		### 정수만 입력하세요!! ###
		
		>> 누적해야할 시작 정수 => 1엔터   2엔터
		>> 누적해야할 마지막 정수 => 그냥엔터 똘똘이엔터 2.567엔터 (두번째 경우의 수)
		### 정수만 입력하세요!! ###
		
		>> 누적해야할 마지막 정수 => 10엔터   9엔터
		
		>>> 실행결과 : 1 부터 10까지의 누적의 합은 55 입니다. <<<
		>>> 실행결과 : 2 부터 9까지의 누적의 합은 44 입니다. <<<
 */

public class Sum6Main {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int num1 = 0, num2 = 0, sum =0; // 시작값, 종료값, 누적값
		
	
		for(;;) {
			try {
				
				System.out.print(">> 누적해야할 시작 정수 => ");
				num1 = Integer.parseInt(sc.nextLine());
				// 1  2  3
				break;
			}
			catch (NumberFormatException e) {
				System.out.println("### 정수만 입력하세요!! ###");	
			}
		}// end of for--------------------
		
		
		for(;;) {
			try {
				System.out.print(">> 누적해야할 마지막 정수 => ");
				num2 = Integer.parseInt(sc.nextLine());
				// 10  9  8
				break;
			}
			catch (NumberFormatException e) {
				System.out.println("### 정수만 입력하세요!! ###\n");	
			}
		}// end of for--------------------
		
		
		// 예시 시작값 : 1, 마지막값 : 10을 줬다면 현재 num1 = 1; num2 = 10;

		String str ="";
		
		for(int i = num1; i <= num2; i++) {
			sum +=i; // 누적합계 결과표시
			
			if(i < num2) str+=i+"+"; // ex. 1부터 10이면 1~9는 뒤에 "+"를 문자열 결합
			
			else str+=i; // ex. 1부터 10이면 10은 그냥 문자열 결합

		}// end of for--------------------
		
		System.out.println(">>> 실행결과 : "+ num1 +" 부터 " + num2 +"까지의 누적의 합은 "+ sum +" 입니다. <<<");
		System.out.println(str+"="+sum);
		sc.close();
		
	}// end of main(String[] args)-------------------------

}
