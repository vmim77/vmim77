package my.day05.b.FOR;

import java.util.Scanner;

public class Quiz11MainRe {

	public static void main(String[] args) {
		
		/*
		첫번째 정수 : 2엔터        그냥엔터      "똘똘이"엔터     2.45엔터
		두번째 정수 : 10엔터      그냥엔터      "똘똘이"엔터     2.45엔터
		
		>> 결과 <<
		2 부터 10까지의 홀수의 합은 : 24    3 부터 10까지의 홀수의 합은 : 24
		2 부터 10까지의 짝수의 합은 : 30    4 부터 10까지의 홀수의 합은 : 28
		*/
		
		
		Scanner sc = new Scanner(System.in);
		
		for(;;) {
			
			try {
				System.out.print("첫번째 정수 : "); // 2    3
				String strFirstNo = sc.nextLine();
				
				int firstNo = Integer.parseInt(strFirstNo);
				
				
				
				System.out.print("두번째 정수 : "); // 9    8
				String strSecondNo = sc.nextLine();
				
				int secondNo = Integer.parseInt(strSecondNo);
				
				int holsum = 0; // 홀수의 누적합계를 담아둘 변수
				int jjaksum = 0; // 짝수의 누적합계를 담아둘 변수
				
				// 홀수의 합을 구한다.
				for(;;) {
					// 홀수의 합을 구하는데 첫번째로 입력한 첫번째 정수의 값이 2(짝수) 이라면 firstNo는 1을 더한후(즉, 3) 2씩 증가시켜주면 된다.
					
					// 홀수의 합을 구하는데 첫번째로 입력한 첫번째 정수의 값이 3(홀수) 이라면 2씩 증가시켜주면 된다.
					
					if(firstNo%2 == 0) { // 처음으로 들어온 값이 짝수라면
						firstNo+=1;		 //  +1를 해줘서 홀수로 만든다.
					}
					
					if(firstNo <= secondNo) {
						holsum+=firstNo; // 홀수의 누적합
					}
					
					else
						break; // 2부터 10이라 했는데, 값이 11이 된다면 break
					
					firstNo+=2; // 다음 홀수로 만든다.
					
				}//end of for-------------------------------------
				
				
				firstNo = Integer.parseInt(strFirstNo); // 첫번째 입력 정수가 위에서 바꼈음으로 초기화
				
				// 짝수의 합을 구한다.
				for(;;) {
					// 짝수의 합을 구하는데 첫번째로 입력한 첫번째 정수의 값이 3(홀수) 이라면 firstNo는 1을 더한후(즉, 4) 2씩 증가시켜주면 된다.
					
					// 짝수의 합을 구하는데 첫번째로 입력한 첫번째 정수의 값이 2(짝수) 이라면 2씩 증가시켜주면 된다.
					
					if(firstNo%2 != 0) { // 처음으로 들어온 값이 홀수라면
						firstNo+=1;		 //  +1를 해줘서 짝수로 만든다.
					}
					
					if(firstNo <= secondNo) {
						jjaksum+=firstNo; // 짝수의 누적합
					}
					
					else
						break; // 2부터 10이라 했는데, 값이 12이 된다면 break
					
					firstNo+=2; // 다음 짝수로 만든다.
					
				}//end of for-------------------------------------
				
				System.out.println(strFirstNo + " 부터 " + strSecondNo + "까지의 홀수의 합은 : " + holsum + "\n"
						 		+ strFirstNo + " 부터 " + strSecondNo + "까지의 짝수의 합은 : " + jjaksum);
				
				sc.close();
				break;
				
			} catch (NumberFormatException e) {
				System.out.println("정수만 입력하세요!!");
			}
			
		}//end of for-----------------------------
		
		
	}// end of main(String[] args)

}
