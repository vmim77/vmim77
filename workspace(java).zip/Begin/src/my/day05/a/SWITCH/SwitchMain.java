package my.day05.a.SWITCH;

import java.util.Scanner;

/*
	>> 실행결과 <<
	
	첫번째 정수 입력 => 10엔터
	두번째 정수 입력 => 4엔터
	사칙연산자 선택(+ - * /)	 => +엔터
	10 + 4 = "14"
	10 - 4 = "6"
	10 * 4 = "40"
	10 / 4
	 = "2.5"
*/	

// calc와 똑같이 하는데 if문을 안 쓰고 switch문을 사용할 것이다.

public class SwitchMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		try {
		System.out.print("첫번째 정수 입력 => "); // 10엔터, 똘똘이엔터 경우의수 1
		int num1 = Integer.parseInt(sc.nextLine());
		
		System.out.print("두번째 정수 입력 => "); // 4엔터, 똘똘이엔터 경우의수 2
		int num2 = Integer.parseInt(sc.nextLine());
		
		System.out.print("사칙연산자 선택(+ - * /) =>  "); // +엔터 -엔터 *엔터 /엔터 그냥엔터 $$$엔터
		String operator = sc.nextLine();
		
		
		String result = "";   //double을 쓰면 모든 result(더하기, 빼기, 곱셈)에도 소수점이 붙어서 깔끔해보이지 않고
							  //int로 하자니 호환이 안된다. 나눗셈에서 double인 값을 result에 담을 수가 없다.
							  //+ - / 은 정수만 나오고, /만 소수부가 나오게 하려면 String을 이용하면 된다.
		
		
		
		/*
		// 항상 변수에 null값이 올 수 있으니 변수를 뒤에 비교대상 위치에 놓자
		if("+".equals(operator)) {
			result = String.valueOf(num1 + num2);
		}
		else if("-".equals(operator)) {
			result = String.valueOf(num1 - num2);
		}
		else if("*".equals(operator)) {
			result = String.valueOf(num1 * num2);
		}
		else if("/".equals(operator)) {
			if(num2 == 0)
				result = "분모에는 0이 올 수 없습니다."; // 분모에 0을 넣는 경우의 수
			else 
				result = String.valueOf((double)num1 / num2);
		}
		else { // 그냥엔터, $$$엔터의 경우의 수
			System.out.println(">> 사칙연산(+ - * /)만 선택하세요!! <<");
			sc.close();
			return;	
		}
		*/
		
		
		// === switch 문 === //
		// key : 비교대상, 유저가 입력한 operator가 무엇이냐?를 알아야 한다.
		// 입력한 값이 case value와 같은지 비교한다.
		
		switch (operator) { // >, <, >=, <= 는 if문에만 쓸 수 있다.
		case "+": // operator 값이 "+"와 같다라면 
			result = String.valueOf(num1 + num2); // 다음과 같이 계산해라
			break; // switch (operator) {} 부분을 빠져나가라는 말이다.
			
		case "-": // operator 값이 위의 값이 아니고 "-"와 같다라면
			result = String.valueOf(num1 - num2); // 다음과 같이 계산해라
			break; // switch (operator) {} 부분을 빠져나가라는 말이다.
			
		case "*": // operator 값이 위의 값이 아니고 "*"와 같다라면
			result = String.valueOf(num1 * num2); // 다음과 같이 계산해라
			break; // switch (operator) {} 부분을 빠져나가라는 말이다.
			
		case "/": // operator 값이 위의 값이 아니고 "/"와 같다라면
			if(num2 == 0)
				result = "분모에는 0이 올 수 없습니다."; // 분모에 0을 넣는 경우의 수 방지
			else 
				result = String.valueOf((double)num1 / num2);
			break; // switch (operator) {} 부분을 빠져나가라는 말이다.
			
		default: // operator 값이 "+" 도 아니고 "-" 도 아니고 "*" 도 아니고 "/" 도 아닌 것이라면 
			System.out.println(">> 사칙연산(+ - * /)만 선택하세요!! <<");
			sc.close();
			return;	// 얘는 메인메소드를 종료하라는 말인데, break는 switch문을 빠져나가서 다음으로 나가세요이니 모순이 됨.
			// break; << 프로그램 종료를 시키기 위해서 break를 없앤다.
		}   // end of switch (operator) {]----------------------------------
		
		
		
		
		
		// 삼항연산자
		result =("/".equals(operator) && num2 == 0) ? result : num1 + operator + num2 + "="+result;
		
		
		System.out.println("결과는 => " + result);
		
		
		} catch(NumberFormatException e) { 
			System.out.println(" >>> 정수만 입력하세요 <<< ");
		}
		sc.close();

	}// end of main(String[] args)----------------------------

}
