package my.day05.a.SWITCH;

public class Sungjuk {
	
	/// >>> field = attribute = property = 속성 <<< //
	String hakbun; // "091234" 
	String name; 
	byte kor;  // byte -128 ~ 127          0 ~ 100 제한
	byte eng;  // byte -128 ~ 127          0 ~ 100 제한
	byte math; // byte -128 ~ 127          0 ~ 100 제한
	short age; // short -32,768 ~ 32,767   20 ~ 50 제한
	
	
	// public Sungjuk() {} 기본생성자(constructor)는 생략이 되어져 있다.
	// 단 파라미터가 있는 생성자를 만들면, 기본생성자는 생략이 아니라 삭제가 되어진다.
	
	
	// >>> operator = method = 기능  = 행위 <<< //
	
	// === *** 유효성 검사하기(입력받은 데이터값이 올바른 값인지 틀린값인지를 검사하는 것) *** ===
	
	// 국어, 영어, 수학은 최저 점수가 0 부터 최대 점수가 100 이어야 한다.
	// 그 이외의 값은 받으면 안된다.
	boolean checkJumsu(byte jumsu){
		if(0 <= jumsu && jumsu <= 100) {
			return  true;
		} 
		else {
			System.out.println("## 점수 입력은 0 이상 100 까지만 가능합니다. ##");
			return false;
		}
		
		

		
	}; // end of boolean checkJumsu(byte jumsu) --------------------
	
	
	
	
	// === *** 유효성 검사하기(입력받은 데이터값이 올바른 값인지 틀린값인지를 검사하는 것) *** ===
	
	// 나이는 최소 20 부터 최대 50 이어야 한다.
	// 그 이외의 값은 받으면 안된다.
	boolean checkAge(short age){
		
		boolean result = false;
		
		if(20 <= age && age <= 50) {
			result = true;
		} 
		else {
			System.out.println("## 나이 입력은 20 이상 50 까지만 가능합니다. ##");
		}

		return result; 
	}; // end of boolean checkAge(byte age) --------------------
	
	
	
	void showInfo() { 
		
		/*
        === 이순신님의 성적결과 ===
        1. 학번 : 091234
        2. 성명 : 이순신
        3. 국어: 90
        4. 영어: 80
        5. 수학: 78
        6. 총점: 248
        7. 평균: 82.666664 ==> 82.7
        8. 학점: B 
        9. 나이: 20세    
		 */
		
		short total = (short)(kor + eng + math); // 총점 , int 보다 작은 byte, short, char인 변수는 사칙연산(+-*/)를 만나면 자동으로 int 타입으로 변한다.
		float avg = Math.round(total/3.0F*10)/10.0F; // 평균 Float 타입, double은 메모리 낭비가 심하다. short 는 float 보다 크기가 작기 때문에 자동형변환이 된다.
		
		String hakjum = ""; // 학점 초기화, 지역변수는 초기화가 필수이다.

		
		switch ( (int)avg/10 ) { 
		/* switch(  ) 에서 (  )속에 들어올 수 있는 타입은 
		   long을 제외한 정수인 byte, short, int 와 char, String 만 가능하다
		*/
		// avg ==> 100.0 98.7 92.3 90.0 면 A가 나오게한다. (앞자리가 10, 9면) ==> "A"
		// avg ==> 88.7 82.3 80.0 면 B가 나오게한다. (앞자리가 8면) ==> "B"
		// avg ==> 78.7 72.3 70.0 면 C가 나오게한다. (앞자리가 7면) ==> "C"
		// avg ==> 68.7 62.3 60.0 면 D가 나오게한다. (앞자리가 6면) ==> "D"
		// 그외 ==> "F"
		
		// avg ==> (int)100.0 (int)98.7 (int)92.3 (int)90.0 ==> "A"
		// avg ==>      100        98        92        90 
		// avg ==>      100/10     98/10     92/10     90/10  정수/정수는 몫만 나온다. 
		// avg ==>      10         9         9         9   ==> 결과물이 10 또는 9면 "A"
		
			case 10:  // break없이 case 10, case 9를 연달아 쓰면 10 또는 9입니까? 이다.
			case 9:	
				hakjum = "A";
				break;
				
			case 8:
				hakjum = "B";
				break;
				
			case 7:
				hakjum = "C";
				break;
				
			case 6:
				hakjum = "D";
				break;
				
			default: // 50, 40, 30, 20, 10, 0은 다 여기로 떨어진다.
				hakjum = "F";
				break;
		} // end of switch()-----------------------------------
		
		/*
		 학점이 "A" 이라면 상품 : "놀이공원이용권,치킨,피자,아이스크림"
	          학점이 "B" 이라면 상품 : "치킨,피자,아이스크림"    
	          학점이 "C" 이라면 상품 : "피자,아이스크림"    
	          학점이 "D" 이라면 상품 : "아이스크림"    
	          학점이 "F" 이라면 상품 : "꿀밤3대"    
		 */
		String gift = "";  // gift = gift + "놀이공원이용권,";
		                   // gift = ""   + "놀이공원이용권,";
						   // gift += "놀이공원이용권,";
		switch (hakjum) {
		case "A": 
			gift += "놀이공원이용권,"; // 아래로 가면서 상품이 누적되서 쌓여감, 중간에 break가 없어서
			
		case "B": 
			gift += "치킨,";	// B이면 A를 재끼고 B부터 시작되니깐 치킨부터 쌓인다.
			
		case "C": 
			gift += "피자,";	
			
		case "D": 
			gift += "아이스크림";
			break;	// 더 이상 붙을 선물이 없기때문에 break를 한다.
					// break; 를 만나야만 switch case 문을 빠져나간다.
					// 이렇게하면 break;를 계속 구간마다 써야하고, 상품을 열거해야 하는 중복을 없앨 수 있다.
	
		default:
			gift += "꿀밤3대";
			break;
		} // end of switch()-----------------------------------

		
		System.out.println("\n=== " + name + "님의 성적결과 ===\n"
							+ "1. 학번 : " + hakbun +"\n"
							+ "2. 성명 : " + name +" \n"
							+ "3. 국어 : " + kor + "\n"
							+ "4. 영어 : " + eng + "\n"
							+ "5. 수학 : " + math + "\n"
							+ "6. 총점 : " + total + "\n"
							+ "7. 평균 : " + avg + "\n"
							+ "8. 학점 : " + hakjum + "\n"
							+ "9. 나이 : " + age + "\n"
							+ "10. 상품 : " + gift + "\n");

	}; // end of showInfo()-------------------------------------------

}
