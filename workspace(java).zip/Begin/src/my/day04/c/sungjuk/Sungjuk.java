package my.day04.c.sungjuk;

public class Sungjuk {
	
	/// >>> field = attribute = property = 속성 <<< //
	String hakbun; // "091234" 
	String name; 
	byte kor;  // byte -128 ~ 127          0 ~ 100 제한
	byte eng;  // byte -128 ~ 127          0 ~ 100 제한
	byte math; // byte -128 ~ 127          0 ~ 100 제한
	short age; // short -32,768 ~ 32,767   20 ~ 50 제한
	
	
	// public Sungjuk() {} 기본생성자(constructor)는 생략이 되어져 있다.
	// 단 파라미터가 있는 생성자를 만들면, 기본생성자는 생략이 아니라 삭제가 되어진다.
	
	
	// >>> operator = method = 기능  = 행위 <<< //
	
	// === *** 유효성 검사하기(입력받은 데이터값이 올바른 값인지 틀린값인지를 검사하는 것) *** ===
	
	// 국어, 영어, 수학은 최저 점수가 0 부터 최대 점수가 100 이어야 한다.
	// 그 이외의 값은 받으면 안된다.
	boolean checkJumsu(byte jumsu){
		if(0 <= jumsu && jumsu <= 100) {
			return  true;
		} 
		else {
			System.out.println("## 점수 입력은 0 이상 100 까지만 가능합니다. ##");
			return false;
		}
		
		

		
	}; // end of boolean checkJumsu(byte jumsu) --------------------
	
	
	
	
	// === *** 유효성 검사하기(입력받은 데이터값이 올바른 값인지 틀린값인지를 검사하는 것) *** ===
	
	// 나이는 최소 20 부터 최대 50 이어야 한다.
	// 그 이외의 값은 받으면 안된다.
	boolean checkAge(short age){
		
		boolean result = false;
		
		if(20 <= age && age <= 50) {
			result = true;
		} 
		else {
			System.out.println("## 나이 입력은 20 이상 50 까지만 가능합니다. ##");
		}

		return result; 
	}; // end of boolean checkAge(byte age) --------------------
	
	
	
	void showInfo() { 
		
		/*
        === 이순신님의 성적결과 ===
        1. 학번 : 091234
        2. 성명 : 이순신
        3. 국어: 90
        4. 영어: 80
        5. 수학: 78
        6. 총점: 248
        7. 평균: 82.666664 ==> 82.7
        8. 학점: B 
        9. 나이: 20세    
		 */
		
		short total = (short)(kor + eng + math); // 총점 , int 보다 작은 byte, short, char인 변수는 사칙연산(+-*/)를 만나면 자동으로 int 타입으로 변한다.
		float avg = Math.round(total/3.0F*10)/10.0F; // 평균 Float 타입, double은 메모리 낭비가 심하다. short 는 float 보다 크기가 작기 때문에 자동형변환이 된다.
		
		String hakjum = ""; // 학점 초기화, 지역변수는 초기화가 필수이다.
		
		if (avg >= 90) hakjum = "A"; // true일때 실행할 명령이 한 줄이라면 중괄호로 안 묶어줘도 괜찮다.
		else if (avg >= 80) hakjum = "B";
		else if (avg >= 70) hakjum = "C";
		else if (avg >= 60) hakjum = "D"; 
		else hakjum = "F";
		
		System.out.println("\n=== " + name + "님의 성적결과 ===\n"
							+ "1. 학번 : " + hakbun +"\n"
							+ "2. 성명 : " + name +" \n"
							+ "3. 국어 : " + kor + "\n"
							+ "4. 영어 : " + eng + "\n"
							+ "5. 수학 : " + math + "\n"
							+ "6. 총점 : " + total + "\n"
							+ "7. 평균 : " + avg + "\n"
							+ "8. 학점 : " + hakjum + "\n"
							+ "9. 나이 : " + age + "\n");

	}; // end of showInfo()-------------------------------------------

}
