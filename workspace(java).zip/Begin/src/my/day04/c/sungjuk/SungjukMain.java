package my.day04.c.sungjuk;

import java.util.Scanner;

public class SungjukMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		Sungjuk sj = new Sungjuk(); // 기본생성자
		
		int inputType = 0;
		
		try {
		
				System.out.print("1. 학번 : ");
				sj.hakbun = sc.nextLine(); // "091234"
				
				System.out.print("2. 성명 : ");
				sj.name = sc.nextLine();   // "이순신"
				
				inputType = 1; // inputType은 국어, 영어, 수학을 입력 중이라면 1 값을 넣어준다.
				
				System.out.print("3. 국어 : ");
				byte kor = Byte.parseByte(sc.nextLine());  // "90" ==> 90
														   // "-50" ==> -50 또는 "120" ==> 120 
														   // byte 타입으로 변경할 수 없는 "200" 이나 "똘똘이"를 입력해주면 java.lang.NumberFormatException 익셉션이 발생한다.
				/*
				boolean bool = sj.checkJumsu(kor);
				// kor 값이 0 ~ 100 이라면 true
				// kor 값이 0 미만 또는 100 보다 크다라면 false
				
				if(!bool) { // 조건이 참이 되기 위해서는 false가 들어와야 한다. 왜냐하면 if는 조건식이 true가 들어와야 동작하기 때문이다.
					sc.close();
					return;
					// main()메소드내에서  return; 은  main()메소드에서 작업중인 것을 종료해라는 말이다. 
		            // 즉, 프로그램을 종료해라는 말이다.
				}
				*/
				
				// 또는 아래와 같이 한다.
				
				if(!sj.checkJumsu(kor)) { // 조건이 참이 되기 위해서는 false가 들어와야 한다. 왜냐하면 if는 조건식이 true가 들어와야 동작하기 때문이다.
					sc.close();
					return;
					// main()메소드내에서  return; 은  main()메소드에서 작업중인 것을 종료해라는 말이다. 
		            // 즉, 프로그램을 종료해라는 말이다.
				} else {
					sj.kor = kor;
				}
		
				System.out.print("4. 영어 : ");
				byte eng = Byte.parseByte(sc.nextLine());
				
				if(!sj.checkJumsu(eng)) {
					sc.close();
					return;
		
				} else {
					sj.eng = eng;
				}
				
				System.out.print("5. 수학 : ");
				byte math = Byte.parseByte(sc.nextLine());
				
				if(!sj.checkJumsu(math)) {
					sc.close();
					return;
		
				} else {
					sj.math = math;
				}
				
				inputType = 2; // inputType은 나이를 입력 중이라면 2 값을 넣어준다.
				
				System.out.print("6. 나이 : ");
				short age = Short.parseShort(sc.nextLine());
							// "25"
							// "10" 또는 "60"
				
				if(!sj.checkAge(age)) {
					sc.close();
					return;
		
				} else {
					sj.age = age;
				}
				
				sj.showInfo();
				/*
		          === 이순신님의 성적결과 ===
		          1. 학번 : 091234
		          2. 성명 : 이순신
		          3. 국어: 90
		          4. 영어: 80
		          5. 수학: 78
		          6. 총점: 248
		          7. 평균: 82.666664
		          8. 학점: B 
		          9. 나이: 20세    
		       */
	
				
			
		} catch (NumberFormatException e) {
			if (inputType == 1) {
				System.out.println(" >> == 점수 입력은 0 에서 100 까지만 가능합니다. == << ");
			} 
			else if (inputType == 2) {
				System.out.println(" >> == 나이 입력은 20 이상 50 까지만 가능합니다. == << ");
			}
			
		sc.close();
		} 

	}// end of main(String[] args)----------------------------
}
