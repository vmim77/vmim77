package my.day03.c.operator;

public class OperatorMain {

	public static void main(String[] args) {
		
		// ==== 연산자 ==== //
		
		// 1. 산술연산자 + - * / %(나머지)
		int n = 10;
		
		System.out.println("n+3=" + (n+3));
		// 괄호 안 적으면 : "n+3=103"
		// 괄호 적으면 : n+3=13
		System.out.println("n-3= " + (n-3)); // n-3=7
		System.out.println("n*3= " + (n*3)); // n*3=30
		System.out.println("n/3= " + (n/3)); // n/3=3 정수/정수=정수(몫)
		System.out.println("((double)n/3))= " + ((double)n/3)); // 3.3333333333333335 실수/정수=실수
		System.out.println("n%3= " + (n%3)); // n%3=1 n을 3으로 나누었을때의 나머지
		
		// 2. 증감연산자 ++ -- 
		
		// int a=7;
		// int b=3;
		// 또는
		
		int a=7, b=3; // 같은 타입일때만 요렇게 써도 괜찮다.
		System.out.println("a => " + a); // a => 7
		
		//a = a+1
		//또는
		a++; // 현재 7인 a에 +1을 해주는 것
		System.out.println("a => " + a); // a => 8
		
		++a; // 현재 8인 a에 +1을 해주는 것
		System.out.println("a => " + a); // a => 9
		
		System.out.println("b => " + b); // b => 3
		
		// b = b-1;
		// 또는
		b--; // 후위연산자
		
		System.out.println("b => " + b); // b => 2
		
		--b; // 전위연산자
		System.out.println("b => " + b); // b => 1
		
		
		
		// !!! 꼭 암기하세요 !!! //
		  // 전위증감연산자(++a; --b;) 는 맨먼저 1씩 증감을 마친 이후에 다른 연산을 한다.
	      // 후위증감연산자(a++; b--;) 는 다른 연산을 다 마친 이후에 1씩 증감한다. 
	      
		int x=10, y=10;
		int z=++x; // ++x; z=x;    x=>11, z=>11 먼저 자기부터 1 증가하고, 그 다음에 z로 넘긴다.
		System.out.println("z => " + z);//z => 11
		System.out.println("x => " + x);//x => 11
		
		z=y++; // z=y; y++;    z=10, y=11 먼저 넘기고, 그 다음에 자기를 1 증가시킨다.
		System.out.println("z => " + z);// z => 10
		System.out.println("y => " + y);// y => 11
		
		// 3. 논리연산자 & |(버티컬라인) && ||
		// & : and
		// | : or
		
		/*
			수학에서는 T ∧   T ∧  F  ==> F      ∧(and)
			수학에서는 T ∧   T ∧  T  ==> T
			
			수학에서는 T ∨   T ∨  F  ==> T      ∨(or)
			수학에서는 T ∨   T ∨  T  ==> T
			수학에서는 F ∨   F ∨  F  ==> F
		 */
		
		int c=50, d=60, e=70;
		
		boolean bool = (c > d) && (d < e) && (c == e);
				// false && skip && skip, &&은 false가 나오면 뒤에는 계산 안 한다.
		System.out.println("bool => " + bool); // bool => false
		
		bool = (c > d) || (d < e) || (c == e);
				// false || true || skip , ||은 true가 나오면 뒤에는 계산 안 한다.
		System.out.println("bool => " + bool); // bool => true
		
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		
		bool = (c > d) & (d < e) & (c == e);
				// false & true & false , 한 개짜리는 스킵하지않고 끝까지 계산한다.
		System.out.println("bool => " + bool); // bool => false
		
		bool = (c > d) | (d < e) | (c == e);
				// false | true | false , 한 개 짜리는 스킵하지않고 끝까지 계산한다.
		System.out.println("bool => " + bool); // bool => true
		
		/*
        if(조건) {
                  실행해야할 명령;     
        }
        ==> 조건이 참일때만 실행해야할 명령; 을 구동한다.
        ==> 조건이 거짓이라면 실행해야할 명령; 을 구동안한다.
		 */
		
		int n1 = 10;
		
		if (n1 <20) {
			//true
			System.out.println(">> " +n1+"은 20보다 작습니다.");
		}
			// >> 10은 20보다 작습니다. << //
		
		
		System.out.println("\n~~~~~~ 퀴즈1 ~~~~~~\n");
	       int i=1; 
	       int j=i++; //j=i; i++; => j=1;, i=>2
	       
	       if( (i > ++j) & (i++ == j) ) {
	    	// ++j; i>j ==> j=>2 2>2    &   i==j i++  ==> 2==2 i=3
	    	//					false   &            true
	    	// 					if(false)
	          i=i+j;  // 작동 X
	       }
	       
	       System.out.println("i="+i); // i=3
	       
	       i=1;
	       j=i++; //j=i; i++; ==> j=1; i=>2
	       
	       if( (i > ++j) && (i++ == j) ) {
	    	   // ++j; i>j ==> j=>2 2>2
	    	   //					false && skip
	    	   // 					if(false)
	          i=i+j; // 작동 X
	       }
	       
	       System.out.println("i="+i); // i=2  
	       
	       
	       System.out.println("\n~~~~~~ 퀴즈2 ~~~~~~\n");
	       
	       int m1=0;
	       n1=1;
	       
	       if( (m1++ == 0) | (n1++ == 2) ) {
	    	   //m1==0 m1++;
	    	   // 0==0 m1=>1
	    	   // true   |   n1==2 n1++;
	    	   // true   |    1==2 n1=>2
	    	   // true   |    false
	    	   //if(true)
	    	   
	          m1=42; // m1=>42
	       }
	       
	       System.out.println("m1=>"+m1 + ", n1=>"+n1); 
	      //m1=>42, n1=>2
	       
	       m1=0; 
	       n1=1;
	       
	       if( (m1++ == 0) || (n1++ == 2) ) {
	    	   //m1==0 m1++;
	    	   // 0==0 m1=>1
	    	   // true || skip n1=>1
	    	   //if(true)
	    	   
	          m1=42; // m1=42
	       }
	       
	       System.out.println("m1=>"+m1 + ", n1=>"+n1); 
	      // m1=>42, n1=>1
		
	       
	       // === 4. 비교연산자 ===
	       // == 같다, != 같지않다, > 크다, >= 같거나 크다, < 작다, <= 같거나 작다
	       
	       // === 5. 할당연산자(연산 후 대입 연산자) ===
	       int no = 1;
	       no+=3; //no = no+3; 와 같은 것이다.
	       System.out.println("no="+no); //no=4
	       
	       no-=2; //no = no-2; 와 같은 것이다.
	       System.out.println("no="+no); //no=2
	       
	       no*=5; //no = no*5; 와 같은 것이다.
	       System.out.println("no="+no); //no=10
	       
	       no/=4; //no = no/4; 와 같은 것이다.
	       System.out.println("no="+no); //no=2
	       
	       no%=3; //no = no%3; 와 같은 것이다.
	       System.out.println("no="+no); //no=2
	       
	       // === 6. 삼항연산자 ===
	       /*
	        	변수선언 = (조건식)?값1:값2;    조건이 참이면 ? 다음의 값이 들어가고 거짓이면 :(콜론) 다음 값이 들어간다.
	        	
	        	변수를 선언하고 나서 값을 부여하고자 할때 사용되어지는데 
			        조건식이 참 이라면 변수에 값1 을 대입해주고, 
			        만약에 조건식이 거짓 이라면 변수에 값2 를 대입해준다. 
	        */
	       
	       int num1=50, num2=60;
	       int num3=(num1 > num2)?num1:num2;
	       
	       System.out.println("num3 => " + num3);
		
	}// end of main(String[] args)----------------------------

}
