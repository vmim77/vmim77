package my.day03.d.scanner;

import java.util.Scanner;

public class Scanner3Main {
	

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		String str_num = ""; // 둘 중 하나라도 에러가 나면 어디서 난지 모르기 때문에 변수를 통일시켜준다.
		
		try {
		
			System.out.print("첫번째 정수를 입력하세요 => ");
			str_num = sc.nextLine(); // "이순신" "10"
			int num1 = Integer.parseInt(str_num); // 10
			// str_num1 문자열(String)을 int 타입으로 형변환 시켜주는 static 메소드이다.
			
			System.out.print("두번째 정수를 입력하세요 => ");
			str_num = sc.nextLine(); // "똘똘이" "20"
			int num2 = Integer.parseInt(str_num); // 20
			// str_num2 문자열(String)을 int 타입으로 형변환 시켜주는 static 메소드이다.
			
			System.out.println(num1 +"+"+num2+"="+(num1+num2)); // Integer.parseInt로 후 처리한 변수로 바꿔준다.
			// 10 + 20 = 30
			
			System.out.println("\n ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ \n");
			
			System.out.print("첫번째 실수를 입력하세요 => ");
			str_num = sc.nextLine(); // "이순신" "10.5"
			double db1 = Double.parseDouble(str_num);
			// str_num 문자열(String)을 double 타입으로 형변환 시켜주는 static 메소드이다.
			
			System.out.print("두번째 실수를 입력하세요 => ");
			str_num = sc.nextLine(); // "똘똘이" "20.4"
			double db2 = Double.parseDouble(str_num);
			// str_num 문자열(String)을 double 타입으로 형변환 시켜주는 static 메소드이다.
			
			System.out.println(db1 +"+"+db2+"="+(db1+db2)); // 30.9
			
		} catch(NumberFormatException e) { // 문자열이지만 숫자가 아닌 걸 넣으면 잡아내서 경고창 띄움
			System.out.println(str_num + "은(는) 올바른 숫자가 아닙니다.");
		}
		
		sc.close();

	} // end of main(String[] args) -----------------------------

}
