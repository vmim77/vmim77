package my.day03.d.scanner;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Scanner2Main {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("정수를 입력하세요 => ");
		
		try { // 한 번 돌려봐서 잘 되면 작성한 로직에 맞게 작동된다.
			int inputNum = sc.nextInt();
			
			
			sc.nextLine();
			
			System.out.println("입력한 정수 : " + inputNum); // 123
			                                             // "안녕하세요"
			                                             // 123123123123
		} catch (InputMismatchException e) { // 오류난 값들을 잡고, 아래 중괄호 내용을 실행한다.
			System.out.println(">>> int 범위에 맞는 정수만 입력하세요!! <<<");
			
			e.printStackTrace(); // 어디서 오류가 났나 추적(trace)해서 화면에 찍어준다.
		}
		
		
		
		sc.close();
	}// end of main(String[] args)---------------------

}
