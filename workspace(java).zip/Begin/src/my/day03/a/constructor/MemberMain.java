package my.day03.a.constructor;

public class MemberMain {

	public static void main(String[] args) {

		Member eomjhMbr = new Member("eomjh","qwer1234","엄정화", 35, 100);
		
		Member lssMbr = new Member();
		lssMbr.userid = "leess";
		lssMbr.passwd = "abcd";
		lssMbr.name = "이순신";
		lssMbr.age = 25;
		lssMbr.point = 200;
		
		eomjhMbr.showInfo(); // 엄정화 인스턴스의 정보를 보여준다.
		lssMbr.showInfo(); // 이순신 인스턴스의 정보를 보여준다.
		
		System.out.println("\n ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ \n");
		
		eomjhMbr.updateInfo("abcd0070","EomJeongHwa", 29, 300);
		
		System.out.println("\n ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ \n");
		
		String newInfo = lssMbr.changeInfo("qwer", "순신이", 22, 500); //changeInfo 메소드의 결과값을 담는 컨테이너
		System.out.println(newInfo);
		
			
	} // end of main(String[] args) ----------------------------

}
