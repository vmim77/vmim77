package my.day16.b.list;

import java.util.*;

public class ArrayList2_Main {

	public static void main(String[] args) {
		
		String[] arr=new String[] {"java","css", "html", "javascript", "jsp"};
		
		List<String> strList = new ArrayList<>(Arrays.asList(arr));
		
		
		for(int i=0; i<strList.size(); i++) {
			System.out.println(strList.get(i));
		}
		
		
		
		
	}// end of main(String[] args)---------------------------

}
