package my.day15.e.anonymousclass;

public class Area implements InterArea {

	@Override
	public double area(double x, double y) {
		
		return x*y;
	}

}
