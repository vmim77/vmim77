package my.day15.e.anonymousclass;

public interface InterArea {
	
	double PI = 3.141592;
	
	double area(double x, double y);

}
