package my.day15.a.block;

public class Parent {
	
	// field
	String id;
	
	// 생성자(constructor)
	public Parent() {
		id = "seokj";
		System.out.println(">> 부모클래스인 Parent 클래스의 기본생성자 호출함 <<");
	}
	
	
	

}
