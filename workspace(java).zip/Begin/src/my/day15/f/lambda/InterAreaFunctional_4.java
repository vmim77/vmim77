package my.day15.f.lambda;

@FunctionalInterface
public interface InterAreaFunctional_4 {
	
	void write();
	
}
