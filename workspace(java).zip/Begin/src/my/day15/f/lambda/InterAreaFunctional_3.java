package my.day15.f.lambda;

@FunctionalInterface
public interface InterAreaFunctional_3 {
	
	void smile(String state);
	
}
