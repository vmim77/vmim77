package my.day15.f.lambda;

@FunctionalInterface
public interface InterAreaFunctional_1 {
	
	double area(double x, double y);
	
}
