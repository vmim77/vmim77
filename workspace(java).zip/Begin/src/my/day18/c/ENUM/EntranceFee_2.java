package my.day18.c.ENUM;

public class EntranceFee_2 {
	
	public static final EntranceFee_2 CHILD = new EntranceFee_2(0);
	public static final EntranceFee_2 TEENAGER = new EntranceFee_2(150);
	public static final EntranceFee_2 ADULT = new EntranceFee_2(300);
	public static final EntranceFee_2 OLD = new EntranceFee_2(100);
	
	// 얘네 각각의 인스턴스 FEE 필드에 따로따로 값을 넣어준 것이다.
	// CHILD의 FEE는 0원으로 메모리에 저장, TEENAGER의 FEE는 150원으로 메모리에 저장
	// 외부에서 인스턴스들을 호출할 수 있도록 static으로 선언한다.
	// CHILD는 오로지 0원만 가지고있다. 변수값 변경불가 FINAL 변수
	
	private final int FEE;
	// 외부에서 FEE 에 접근하지 못하도록 접근제한자에 private 을 준다.
	
	// 파라미터가 있는 생성자
	private EntranceFee_2(int fee) {
	// 생성자의 접근제한자에 private 을 주어서 외부에서 객체 생성을 못하도록 막아버린다.
	// 어린이, 청소년, 성인, 어른의 표값들만 있게해주려고 기본생성자 제거
		// 기본생성자를 안 만드는 이유는 바로 필드값을 주는 생성자만 가지고 있으려고
		// 또한 밖에서 Entrance_2 의 객체를 생성시키지 못하도록 하기 위해서이다.
		
		this.FEE = 	fee;
	}
	
	public int getFee() {
	// 외부에서 FEE 값을 읽을 수 있도록 접근제한자를 public 으로 준다.
		
		return FEE;
	}
	
	
}
