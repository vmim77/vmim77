package my.day18.a.ENUM;

public class Season_1 {
	
	public static final String SPRING = "봄";
	public static final String SUMMER = "여름";
	public static final String AUTUMN = "가을";
	public static final String WINTER = "겨울";

}
