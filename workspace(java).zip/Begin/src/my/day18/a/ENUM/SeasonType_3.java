package my.day18.a.ENUM;


// Enum Type : enum(열거형)이라는 타입은 "서로 연관된 상수들의 집합"을 의미하는 것이다.
// ex. 사계절(봄,여름,가을,겨울)
public enum SeasonType_3 {
	봄,여름,가을,겨울	// 겨울; 와 같이 끝에 ;을 붙이지 않는다.

}
