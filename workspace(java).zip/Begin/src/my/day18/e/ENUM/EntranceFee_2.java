package my.day18.e.ENUM;


// 아래는 조금전 my.day18.c.ENUM.EntranceFee_2 클래스를 enum 을 사용하여 변경한 것이다.

//>> === enum(열거형)에 멤버(field, method)추가하기 === << //
//모든 enum(열거형)은 추상 클래스 Enum 의 자손이다. 그러므로 field 및  생성자와 method 를 만들 수 있는 것이다.

public enum EntranceFee_2 {
	
	CHILD(0) {
		@Override
		int getRealFee(int inwonsu) {
			return 0; // 어린이는 인원수에 관계없이 0원이기 때문에 딱히 추가할 내용 없다.
		}
	}, 
	TEENAGER(150) {
		@Override
		int getRealFee(int inwonsu) {
			
			if(inwonsu >= 20)
				return (int)(DEFAULT_FEE * inwonsu * 0.8); // 청소년은 20% 할인, 소수부는 절삭하려 int 형변환
			
			else 
				return DEFAULT_FEE * inwonsu; // 20명이 안되면 그냥 기본요금 * 인원수
		}
	},
	ADULT(300) {
		@Override
		int getRealFee(int inwonsu) {
			
			if(inwonsu >= 20)
				return (int)(DEFAULT_FEE * inwonsu * 0.9); // 성년은 10% 할인, 소수부는 절삭하려 int 형변환
			
			else 
				return DEFAULT_FEE * inwonsu; // 20명이 안되면 그냥 기본요금 * 인원수
		}
	}, 
	OLD(100) {
		@Override
		int getRealFee(int inwonsu) {
			
			if(inwonsu >= 20)
				return (int)(DEFAULT_FEE * inwonsu * 0.7); // 어르신은 30% 할인, 소수부는 절삭하려 int 형변환
			
			else 
				return DEFAULT_FEE * inwonsu; // 20명이 안되면 그냥 기본요금 * 인원수
		}
	}; // 끝에 ; 을 붙여야 한다.
	
	// !!! 사실은 열거형 상수 CHILD, TEENAGER, ADULT, OLD 하나 하나가 EntranceFee_2 객체라는 것이다. !!!
	// 얘네는 파라미터가 있는 생성자이다.
	
	// 단체관람시 각 연령대별 할인금액(추상메소드로 만들어서 객체 생성시 반드시 재정의 하도록 강제하는 것임) 을 달리 적용하여 실제 입장료 금액을 계산하도록 한다.
	
	// 객체들이 메소드를 재정의를 안해서 빨간줄이 뜬다. must implement the abstract method getRealFee(int)
	
	
	// 얘네 각각의 인스턴스 FEE 필드에 따로따로 값을 넣어준 것이다.
	// CHILD의 FEE는 0원으로 메모리에 저장, TEENAGER의 FEE는 150원으로 메모리에 저장
	// 외부에서 인스턴스들을 호출할 수 있도록 static으로 선언한다.
	// CHILD는 오로지 0원만 가지고있다. 변수값 변경불가 FINAL 상수변수
	
	protected final int DEFAULT_FEE;
	// !!! private 으로 하면 위의 열거형 상수에서 DEFAULT_FEE 으로 접근이 불가능해진다. !!!
	// !!! protected 또는 default 또는 public 으로 해야만 위의 열거형 상수에서 DEFAULT_FEE 으로 접근이 가능해진다. !!!
	// enum(열거형)의 인스턴스 변수 반드시 final 이어야 한다는 규칙은 없지만 FEE 는 열거형 상수값을 저장하기 위한 용도이므로 final 을 붙인 것이다.
	// 할인율이 적용되지 않은 개인별 금액은 DEFAULT_FEE 이다.
	
	
	// 파라미터가 있는 생성자
	EntranceFee_2(int default_fee) {
	// 생성자의 접근제한자에 private 을 주어서 외부에서 객체 생성을 못하도록 막아버린다.
	// ★ enum(열거형)의 생성자는 접근제한자가 private 이 생략되어져 있는 것이다.
	// 기본생성자를 안 만드는 이유는 바로 필드값을 주는 생성자만 가지고 있으려고
	// 또한 밖에서 Entrance_2 의 객체를 생성시키지 못하도록 하기 위해서이다.
		
		this.DEFAULT_FEE = 	default_fee; 
	}
	
	public int getFee() {
	// 외부에서 FEE 값을 읽을 수 있도록 접근제한자를 public 으로 준다.
		
		return DEFAULT_FEE;
	}
	
	// !!!! 입장인원수에 따라 할인이 적용된 실제 입장료  금액을 알려주는 추상(미완성)메소드 !!!!
	abstract int getRealFee(int inwonsu);
	
	
	
	
	
	
	
	
	
	
	
	
	
}
