package my.day01;

import java.util.Date;

public class HelloTest {

	public static void main(String[] args) {
		System.out.println("Hello World!");
		System.out.println("안녕하세요?");

		Date now = new Date();
		System.out.println("현재시각 : " + now);

	}

}
