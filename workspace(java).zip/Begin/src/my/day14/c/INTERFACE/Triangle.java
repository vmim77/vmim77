package my.day14.c.INTERFACE;

public class Triangle extends Figure {
	// Triangle 이라는 클래스는 InterFigure 라는 인터페이스를 implements(구현)한다는 말이다.

	// 기본생성자
	public Triangle() {}
	
	
	// 파라미터가 있는 생성자
	public Triangle (int x, int y) {
		// 필드명과 지역변수명이 똑같아지면, 지역변수가 우선순위가 높다.
		super.x = x;
		this.y = y;
	}
	
	@Override
	public double area() {
		
		
		return x*y*0.5;
	}
	
	
	


}
