package my.day14.c.INTERFACE;

public abstract class Figure implements InterFigure {
	
	double x;
	double y;
	
}
