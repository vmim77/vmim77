package my.day14.e.INTERFACE;

import java.text.DecimalFormat;
import java.util.Scanner;

public class GujikjaCompanyCtrl implements InterGujikjaCompanyCtrl {
	
	// == 구직자(Gujikja) 신규 회원가입을 해주는 메소드 생성하기 ==  
	@Override
	public boolean registerGujikja(Scanner sc, Member[] mbrArr) { 
		// GujikjaMain에서 입력받아진 스캐너값과 GujikjaMain에서 그동안 사용된 guArr을 넘겨 받아온다.
		
		boolean result = false;
		
		
		if(Member.count < mbrArr.length) { // 배열에 빈 칸이 남았는지 확인해보고 count가 guArr의 길이보다 작아야 정보를 넣을 수 있게 해줘야 한다.
			
			Gujikja gu = new Gujikja(); // Gujikja에서 설계한 필드들과 메소드를 사용하기 위해서 선언한 것이다.
			
			
			// == 아이디 중복검사 == //
			do {
				System.out.print("1.  아이디 : ");
				String id = sc.nextLine(); // 이걸 for 안에 넣으면, 제대로 아이디를 썼어도 다시 입력하라는 메세지가 나온다.
				// 그냥엔터 => "",  "     "
				// "youks", "eomjh", "leess", "seokj", "kang#$"
				
				
				gu.setId(id);
				
				if(gu.getId() == null) { // 잘못들어온 케이스라면 다시 반복시킨다.
					continue;
				}
					
				boolean isDuplicate = false; // 제대로 입력한 아이디를 검사해서 중복이라면 true를 준다.
				
				for(int i=0; i<Member.count; i++) { //null과 비교해봐야 NullPointerException이 뜨기 때문에 배열에 저장된 갯수만큼 비교해야 한다.
					
					if(mbrArr[i].getId().equals(id)) {
						isDuplicate = true;
						break;
					}
	
				}// end of for----------------------
				
				if(isDuplicate) { // 중복됐으면 다시 위로 올려서 아이디값을 입력받아야 한다.
					System.out.println("\n>> 당신이 입력하신 "+id+"는 이미 사용중 입니다. 새로운 아이디를 입력하세요!! <<\n");
				}
				else { // 중복이 없는 아이디를 입력한 경우
					gu.setId(id);
					break; // 제대로 했으니 while문을 빠져나가게 해준다.
				}
			} while(true);
			
			
			// == 패스워드가 정책에 맞는지 검사 == //
			do {
				System.out.print("2.  암호 : ");
				String passwd = sc.nextLine();
				
				gu.setPasswd(passwd); // 정책에 안맞으면 안 들어가고, getPasswd()는 null값이 된다.
				
				if( gu.getPasswd() != null ) { // 잘못 입력됐다고 메세지도 안 떳고, 들어간 값이 null이 아니면 정상이다.
					break;
				}

			} while(true);
			
			
			// == 이름에 공백이나 그냥 엔터를 못치게 한다. == //
			do {
				System.out.print("3.  성명 : ");
				String name = sc.nextLine();
				
				gu.setName(name);
				
				if(gu.getName() != null) { // 잘못 입력됐다고 메세지도 안 떳고, 들어간 값이 null이 아니면 정상이다.
					break;
				}
				
			} while(true);

			
			
			do {
				System.out.print("4.  주민번호 앞의 7자리만 : "); // 올바르게 넣을 때까지 반복시키기 위해서 do~while 무한반복을 시킨다.
				String jubun = sc.nextLine();
				
				gu.setJubun(jubun);
				
				if(gu.getJubun()!= null) {// 제대로 주민번호를 넣었다면 null이 아니다.
					break;
				}
				
			} while (true); // end of do~while----------------------------------------
			
			do {
				System.out.print("5.  연락처 : "); 
				String mobile = sc.nextLine();
				
				gu.setMobile(mobile);
				
				if(gu.getMobile()!= null) {
					break;
				}
				
			} while (true); // end of do~while----------------------------------------
			
			do {
				System.out.print("6.  희망급여 : "); 
				String str_hopeMoney = sc.nextLine(); // String 타입으로 받아왔지만, setHopeMoney는 int로 들어가야한다.
				
				try {
					gu.setHopeMoney(Integer.parseInt(str_hopeMoney)); // 여기는 Exception을 유발시킨다.
					
					if(1000 <= gu.getHopeMoney() && gu.getHopeMoney() <= 9999)  { // getHopeMoney의 초기값은 null이 아닌 0이여서 이렇게 조건을 설정한다.
						break;
					}
					
					
				} catch(NumberFormatException e) {
					System.out.println("\n>>  정수만 입력 가능합니다.!! <<\n");
				}
				
			} while (true); // end of do~while----------------------------------------
			
			
			
			
			// 이제 올바르게 입력받은 정보들을 검사하고 배열 속에 넣어줘야 한다.
			if(checkGujikja(gu)) { // 그동안 gu 인스턴스에 입력한 필드값들을 한 번더 확인해서 null값이 하나도 없다면
								   // 배열에 값들을 넣어준다.
 				
				mbrArr[Member.count++] = gu; // 스캐너로 입력받은 정보로 새로운 구직자인스턴스를 만들어서 배열에 넣는다.
				result = true;
			}
			// 지금까지 GujikjaMain에서 사용된 guArr에 추가 저장하여서 내보내려고 파라미터로 선언한 것이다. (서로 연결을 시키기 위해서)
 		
		}// end of if--------------------------------------------		
		
		// 메인메소드에서 입력받아진 스캐너값들을 Gujikja 인스턴스에 넣는다. 그 후에 그 인스턴스를 guArr 배열에 저장시킨다. 

		
		
		else {
			System.out.println("\n>>> 구직자 정원마감으로 신규회원 가입은 불가합니다. <<<\n");
			
			
		}
		return result;
	}// end of boolean register(Scanner sc, Member[] mbrArr)----------------------------------------
	
	
	
	
	
	// == 구인회사(Company) 신규 회원가입을 해주는 메소드 생성하기 ==  
	@Override
	public boolean registerCompany(Scanner sc, Member[] mbrArr) {
		
		boolean result = false;
		
		
		if(Member.count < mbrArr.length) { // 길이를 3을줘서 공간이 1개밖에 안남았다.
			
			Company comp = new Company(); // Company에 설계한 필드와 메소드를 사용하기 위해서 선언
			
			
			// == 아이디 중복검사 == //
			do {
				System.out.print("1.  아이디 : ");
				String id = sc.nextLine(); 
				// "LG", "Samsung" "SK"
				
				comp.setId(id);
				
				if(comp.getId() == null) { // 잘못들어온 케이스라면 다시 반복시킨다.
					continue;
				}
					
				boolean isDuplicate = false; // 제대로 입력한 아이디를 검사해서 중복이라면 true를 준다.
				
				for(int i=0; i<Company.count; i++) { //null과 비교해봐야 NullPointerException이 뜨기 때문에 배열에 저장된 갯수만큼 비교해야 한다.
					
					if(mbrArr[i].getId().equals(id)) { // "LG" "Samsung" "LG" 와 그냥엔터 를 비교
														// 전에 LG가 이미 들어가버려서 LG랑 그냥엔터를 비교하면 중복이 아니게 됨
						isDuplicate = true; // 그래서 그냥 엔터가 중복처리가 안되서 나가버림
						break;
					}
	
				}// end of for----------------------
				
				if(isDuplicate) { // 중복됐으면 다시 위로 올려서 아이디값을 입력받아야 한다.
					System.out.println("\n>> 당신이 입력하신 "+id+"는 이미 사용중 입니다. 새로운 아이디를 입력하세요!! <<\n");
				}
				else { // 중복이 없는 아이디를 입력한 경우
					comp.setId(id);
					break; // 제대로 했으니 while문을 빠져나가게 해준다.
				}
			} while(true);
			
			
			// == 패스워드가 정책에 맞는지 검사 == //
			do {
				System.out.print("2.  암호 : ");
				String passwd = sc.nextLine();
				
				comp.setPasswd(passwd); // 정책에 안맞으면 안 들어가고, getPasswd()는 null값이 된다.
				
				if( comp.getPasswd() != null ) { // 잘못 입력됐다고 메세지도 안 떳고, 들어간 값이 null이 아니면 정상이다.
					break;
				}

			} while(true);
			
			
			// == 이름에 공백이나 그냥 엔터를 못치게 한다. == //
			do {
				System.out.print("3.  회사명 : ");
				String name = sc.nextLine();
				
				comp.setName(name);
				
				if(comp.getName() != null) { // 잘못 입력됐다고 메세지도 안 떳고, 들어간 값이 null이 아니면 정상이다.
					break;
				}
				
			} while(true);

			do {
				System.out.print("4.  인사 담당자 연락처 : "); 
				String mobile = sc.nextLine();
				
				comp.setMobile(mobile);
				
				if(comp.getMobile()!= null) {
					break;
				}
				
			} while (true); // end of do~while----------------------------------------
			
			
			do {
				System.out.print("5.  회사직종타입(서비스,제조업,IT,...) : "); 
				String jopType = sc.nextLine();
				
				comp.setJobType(jopType);
				
				if(comp.getJobType()!= null) {
					break;
				}
				
			} while (true); // end of do~while----------------------------------------
			
			
			
			
			
			
			
			do {
				System.out.print("6.  자본금 : "); 
				String str_seedMoney = sc.nextLine(); // String 타입으로 받아왔지만, setHopeMoney는 int로 들어가야한다.
				
				try {
					comp.setSeedMoney(Long.parseLong(str_seedMoney)); // 여기는 Exception을 유발시킨다.
					
					if(comp.getSeedMoney() > 0)  { 
						break;
					}
					
					
				} catch(NumberFormatException e) {
					System.out.println("\n>>  정수만 입력 가능합니다.!! <<\n");
				}
				
			} while (true); // end of do~while----------------------------------------
			
			
			
			
			// 이제 올바르게 입력받은 정보들을 검사하고 배열 속에 넣어줘야 한다.
			if(checkCompany(comp)) { // 그동안 comp 인스턴스에 입력한 필드값들을 한 번더 확인해서 null값이 하나도 없다면
								     // 배열에 값들을 넣어준다.
				mbrArr[Member.count++] = comp;
				result = true;
			}
			 		
		}// end of if--------------------------------------------		
		
		
		
		
		else {
			System.out.println("\n>>> 구인회사 정원마감으로 신규회사 가입은 불가합니다. <<<\n");
			
			
		}
		return result;

		
	}// end of public boolean register(Scanner sc, Company[] compArr)------------------------
	
	
	
	// 연령대에 해당하는 구직자 찾아보기
	@Override
	public void search(int ageline, Member[] mbrArr) {
		
		boolean isExists = false;
		
		for(int i=0; i<Member.count; i++) {
			if( mbrArr[i] instanceof Gujikja && 
					((Gujikja)mbrArr[i]).getAge()/10*10 == ageline) {  // 내 나이가 20 24 29 이건                   => 20이 되야함
													  // 20/10*10 24/10*10 29/10*10  => 20
						
				isExists = true; // 내가 찾고자 하는 연령대의 정보가 있다면 배열에 있다면 true를 반환
				System.out.println(mbrArr[i].showInfo()); // 이미 위에 if절에서 Gujikja임을 확인했으니, 여기는 형변환 불필요
			}

		}// end of for-------------------
		
		if(!isExists) {
			System.out.println("\n>> 검색하신 연령대 "+ageline +"대는 없습니다.<<\n");
		}
		
	}// end of void search(int ageline, Member[] mbrArr)-------------------------------
	
	
	
	
	// !!!! === method 의 overloading(메소드의 오버로딩) === !!!! //
	// ==> method 의 이름이 같더라도 
	//     파라미터의 개수나 또는 순서, 타입이 다르면 서로 다른 method 로 인식한다.
	
	
	// === 성별로 구직자 찾아보기 ===
	@Override
	public void search(String gender, Member[] mbrArr) {
	      
	      for(int i=0; i<Member.count; i++) {
	      
	    	 if(mbrArr[i] instanceof Gujikja) { 
	    		 String n_gender = ((Gujikja)mbrArr[i]).getJubun().substring(6);
	    		 //     "1"   "2"   "3"   "4"
	    		 
	    		 if("남".equals(gender)) { // "남"을 검색했는데
	 	            if("2".equals(n_gender) || "4".equals(n_gender)) { // 꺼낸 구직자가 "여"이면
	 	               continue; // 그 다음 사람을 검색한다.
	 	            }
	 	            else { // 꺼낸 사람도 "남"이면 그 구직자의 정보를 출력
	 	               System.out.println(mbrArr[i].showInfo());
	 	            }
	 	         }
	 	         else { // "여"를 검색했는데
	 	            if("1".equals(n_gender) || "3".equals(n_gender)) { // "꺼낸 구직자가 "남"이면
	 	               continue; // 그 다음 사람을 검색한다.
	 	            }
	 	            else { // 꺼낸 사람도 "여"이면 그 구직자의 정보를 출력
	 	               System.out.println(mbrArr[i].showInfo());
	 	            }
	 	         }
	    	 }
	    	 
	         
	         
	      }// end of for----------------------
	            
	   }// end of void search(String gender, Member[] mbrArr)-------------------------------
	   
	   
	   
	// === 특정 연령대에 해당하는 회원중 특정 성별 회원만 출력해주기 메소드 생성 === //   
	@Override
	public void search(int ageline, String gender, Member[] mbrArr) {
		for(int i=0; i<Member.count; i++) {
			
			if(mbrArr[i] instanceof Gujikja) {
				
				if( ageline != ((Gujikja)mbrArr[i]).getAge()/10*10 ) { // 일단 연령대가 안 맞으면 다음 사람을 찾아온다.
					continue;
				}
				else { // 내가 찾고자하는 연령대와 가져온 구직자의 연령대가 똑같으면 
					String n_gender = ((Gujikja)mbrArr[i]).getJubun().substring(6); // 그 사람의 주민번호 끝자리를 가져온다.
					// "1" "2" "3" "4"
			
					if("남".equals(gender)) { // 내가 성별 선택을 "남"을 했는데
						if("1".equals(n_gender)||"3".equals(n_gender)) {// 가져온 구직자의 주민번호 끝자리도 "남"이라면
							System.out.println(mbrArr[i].showInfo()); // 연령대와 성별도 맞으니 그 구직자의 정보를 출력한다.
						}
					}
					else { // 성별 선택을 "여"를 했는데
						if("2".equals(n_gender)||"4".equals(n_gender)) {// 가져온 구직자의 주민번호도 "여"이라면
							System.out.println(mbrArr[i].showInfo());
						}
					}
				}
				
			}
		
		}// end of for-------------------
		
	}// end of void search(int ageline, String gender, Member[] mbrArr)------------------------

	
	// 모든 구직자 희망급여보기
	@Override
	public void showAllHopeMoney(Member[] mbrArr) {
		
		
		
		/*
		   -------------------
		            구직자명   희망급여
		   -------------------
		            엄정화       5,000만원
		            이순신       7,000만원
		            유관순       8,000만원
		 */

		
		System.out.println("-------------------------------------");
		System.out.println("구직자명               희망급여");
		System.out.println("-------------------------------------");
		
		for(int i=0; i<Member.count; i++) {
			
			if(mbrArr[i] instanceof Gujikja) {
				
				System.out.println(mbrArr[i].getName()+"                  "+((Gujikja)mbrArr[i]).strHopeMoney() );
			}
			
		}// end of for----------------------
		
	}// end of public void showAllHopeMoney()-----------------------
		
	
	// 구직자들의 입력받은 필드값(Gujikja)들을 모두 검사하여서, null값이 있는지 없는지 확인한다.
	// 사용은 GujikjaMain에서 써야하니, private는 안 된다.
	// 같은 패키지이든, 다른 패키지이든 모든 곳에서 사용하게 하고싶다면 public로 한다.
	
	// == Gujikja 인스턴스가 제대로 생성되었는지 확인 시켜주는 메소드 생성 == //
	@Override
	public boolean checkGujikja(Gujikja gu){
		
		if(gu.getId() != null &&
		   gu.getPasswd() != null &&
		   gu.getName() != null &&
		   gu.getMobile() != null &&
	       gu.getJubun() != null &&
		   gu.getHopeMoney() > 0) {
			
			return true;
		}
		else {
			return false;
		}
		
	}
	
	// == Company 인스턴스가 제대로 생성되었는지 확인 시켜주는 메소드 생성 == //
	@Override
	public boolean checkCompany(Company comp){
		
		if(comp.getId() != null &&
		   comp.getPasswd() != null &&
		   comp.getName() != null &&
		   comp.getMobile() != null &&
		   comp.getJobType() != null &&
		   comp.getSeedMoney() > 0) {
			
			return true;
		}
		else {
			return false;
		}
		
		
		
	}

	// === 구직자 로그인 ===
	@Override
	public Gujikja login(Scanner sc, Member[] mbrArr) {
		
		Gujikja loginGu = null;
		
		System.out.print("▷ 구직자 ID : ");
		String input_id = sc.nextLine();
		
		System.out.print("▷ 비밀번호 : ");
		String input_passwd = sc.nextLine();
		
		for(int i=0; i<Gujikja.count; i++) {
			String id = mbrArr[i].getId();
			String passwd = mbrArr[i].getPasswd();
			
			if(id.equals(input_id) && passwd.equals(input_passwd)) {
				// id 및 암호가 일치했다라면
				
				if(mbrArr[i] instanceof Gujikja) {
					// 얘가 실제 Gujikja 클래스의 인스턴스라면
					
					loginGu = (Gujikja)mbrArr[i]; // Gujikja로 형변환해서 loginGu에 넣어준다.
					break;
				}
				
			}
		}// end of for-------------------
				
		return loginGu;
	}// end of public Gujikja login(Scanner sc, Member[] mbrArr)--------




	// === 구인회사 로그인 ===
	@Override
	public Company login(Member[] mbrArr, Scanner sc) {
		
		Company loginComp = null;
		
		System.out.print("▷구인회사 ID : ");
		String input_id = sc.nextLine();
		
		System.out.print("▷비밀번호 : ");
		String input_passwd = sc.nextLine();
		
		for(int i=0; i<Company.count; i++) {
			String id = mbrArr[i].getId();
			String passwd = mbrArr[i].getPasswd();
			
			if(id.equals(input_id) && passwd.equals(input_passwd)) {
				// id 및 암호가 일치했다라면
				
				if(mbrArr[i] instanceof Company) {
					// 얘가 실제 Company 클래스의 인스턴스라면
					
					loginComp = (Company)mbrArr[i]; //Company로 형변환해서 loginComp에 넣어준다.
					break;
				}
				
			
			}
		}//end of for---------------------------
		
		
		
		
		return loginComp;
	}// end of public Company login(Member[] mbrArr, Scanner sc)-------------------



	// === 구직자 또는 구인회사 모두 보기 ===
		public void showAll(Member[] mbrArr, int no) {
			
			if(no==1) {
				// 모든 구직자 보기
				for(int i=0; i<Member.count; i++) {
					
					if(mbrArr[i] instanceof Gujikja) { // 실제 저장된 애가 Gujikja라면
						System.out.println(mbrArr[i].showInfo()); // 위에서 구직자인것을 물어본 게 참이니깐, 구직자에있는 showInfo가 나올 것이다.
						//Gujikja.showInfo()와 같으니, 구직자에서 재정의한 showInfo가 나올 것이다.
					}
					
					
				}// end of for---------------------
			}
			
			else if(no==2) {
				// 모든 구인회사 보기
				showAll(mbrArr);
			}
			
		}// end of public void showAll(Member[] mbrArr, int no) ------------------------------------
		

	// 모든 구인회사 보기
	@Override
	public void showAll(Member[] mbrArr) { 
		
		
		boolean isExistsCompany = false;
		
		for(int i=0; i<Member.count; i++) {
			if( mbrArr[i] instanceof Company ) {
				isExistsCompany = true;
				break;
			} // 회사가 하나라도 있다면 아래의 기능을 실행하라
		}// end of for-----------------------
		
		
		if(isExistsCompany) {
			
			System.out.println("\n=====================================================");
			System.out.println("회사명                  직종                       자본금                    담당자연락처   ");
			System.out.println("\n=====================================================");
			
			DecimalFormat df = new DecimalFormat("#,###");
			for(int i=0; i<Member.count; i++) { // 배열에 저장되어진 갯수만큼 반복하여서 구인회사 정보를 comp에 넣어준다.
				// 현재 배열에는 "LG"와 "samsung"이 있으니, 두 개의 정보를 각각 넣어준다.
				if( mbrArr[i] instanceof Company ) {
					System.out.println(mbrArr[i].getName()+"     "+((Company)mbrArr[i]).getJobType()+"                    "+ df.format(((Company)mbrArr[i]).getSeedMoney())+ "원          "+mbrArr[i].getMobile());
				}
				
			}// end of for----------------------------------------
			
			System.out.println("\n=====================================================");
		}
		else {
			System.out.println("\n>> 가입된 구인회사가 없습니다.!! <<\n");
		}
		
		
	}// end of public void showAll(Company[] compArr)--------------------------------




	// 구직자 나의 정보 변경해주는 메소드
	@Override
	public Gujikja update(Scanner sc, Gujikja loginGu) {
		
		System.out.println("\n>> === 변경전 구직자 나의 정보 === <<");
		System.out.println(loginGu.showInfo()); // 로그인 되어진 구직자를 받아서 그 사람의 정보를 보여준다.
		
		String original_passwd = loginGu.getPasswd();
		String original_name = loginGu.getName();
		int original_hopeMoney = loginGu.getHopeMoney(); // 만약 잘못친다면 null값으로 바뀌니깐, 바뀌기 전에 값들을 빼온다.
		

		
		
		do {
			System.out.print("▷암호변경[변경하지 않으려면 그냥 엔터하세요] : "); // 메인메소드에서 실행된 콘솔에서 입력된 스캐너값을 받는다.
			String passwd = sc.nextLine();
			
			if("".equals(passwd)) {
				// System.out.println("엔터이군요!");
				passwd = original_passwd; // 그냥엔터를 쳤다면, 원래 암호를 다시 넘겨준다.
			}
			
			loginGu.setPasswd(passwd); // 로그인 되어진 사람의 비밀번호를 일단 바꾼다.
			
			if( loginGu.getPasswd() != null ) { // 잘못 입력됐다고 메세지도 안 떳고, 들어간 값이 null이 아니면 정상이다.
				break;
			}

		} while(true);
		

		
		do {
			System.out.print("▷성명변경[변경하지 않으려면 그냥 엔터하세요] : ");
			String name = sc.nextLine();
			
			if("".equals(name)) {
				// System.out.println("엔터이군요!");
				name = original_name; // 그냥엔터를 쳤다면, 원래 성명을 다시 넘겨준다.
			}
			
			loginGu.setName(name);
			
			if(loginGu.getName() != null) { // 잘못 입력됐다고 메세지도 안 떳고, 들어간 값이 null이 아니면 정상이다.
				break;
			}
			
		} while(true);
		

		
		do {
			System.out.print("▷희망급여변경[변경하지 않으려면 그냥 엔터하세요] : "); 
			String str_hopeMoney = sc.nextLine(); // String 타입으로 받아왔지만, setHopeMoney는 int로 들어가야한다.
			
			if("".equals(str_hopeMoney)) {
				// System.out.println("엔터이군요!");
				str_hopeMoney = String.valueOf(original_hopeMoney); // 그냥엔터를 쳤다면, 원래 성명을 다시 넘겨준다.
			}
			
			try {
				
				loginGu.setHopeMoney(Integer.parseInt(str_hopeMoney)); // 여기는 Exception을 유발시킨다.
				
				if(1000 <= loginGu.getHopeMoney() && loginGu.getHopeMoney() <= 9999)  { // getHopeMoney의 초기값은 null이 아닌 0이여서 이렇게 조건을 설정한다.
					break;
				}
				
				
			} catch(NumberFormatException e) {
				System.out.println("\n>>  정수만 입력 가능합니다.!! <<\n");
			}
			
		} while (true); // end of do~while----------------------------------------
		
		
		// 이미 위에서 끄집어온 구직자에 (loginGu = guArr[i]) 정보를 넣고있다.

		return loginGu; // 변경되어진 정보를 넘긴다. 
		
	}// end of public boolean update(Scanner sc, Gujikja loginGu, Gujikja[] guArr)---------------------------










	// 구인회사 정보 변경해주는 메소드
	
	@Override
	public Company update(Scanner sc, Company loginComp) {
		
		//암호, 업종, 자본금
		
		

		
		System.out.println("\n>> === 변경전 구인회사 정보 === <<");
		System.out.println(loginComp.showInfo()); // 로그인 되어진 구직자를 받아서 그 사람의 정보를 보여준다.
		
		String original_passwd = loginComp.getPasswd();
		String original_jobType = loginComp.getJobType();
		long original_seedMoney = loginComp.getSeedMoney(); // 만약 잘못친다면 null값으로 바뀌니깐, 바뀌기 전에 값들을 빼온다.
		
		do {
			System.out.print("▷암호변경[변경하지 않으려면 그냥 엔터하세요] : "); // 메인메소드에서 실행된 콘솔에서 입력된 스캐너값을 받는다.
			String passwd = sc.nextLine();
			
			if("".equals(passwd)) {
				// System.out.println("엔터이군요!");
				passwd = original_passwd; // 그냥엔터를 쳤다면, 원래 암호를 다시 넘겨준다.
			}
			
			loginComp.setPasswd(passwd); // 로그인 되어진 사람의 비밀번호를 일단 바꾼다.
			
			if( loginComp.getPasswd() != null ) { // 잘못 입력됐다고 메세지도 안 떳고, 들어간 값이 null이 아니면 정상이다.
				break;
			}

		} while(true);
		
		
		do {
			System.out.print("▷업종변경[변경하지 않으려면 그냥 엔터하세요] : "); 
			String jopType = sc.nextLine();
			
			if("".equals(jopType)) {
				// System.out.println("엔터이군요!");
				jopType = original_jobType; // 그냥엔터를 쳤다면, 원래 업종을 다시 넘겨준다.
			}
			
			loginComp.setJobType(jopType);
			
			if(loginComp.getJobType()!= null) {
				break;
			}
			
		} while (true); // end of do~while----------------------------------------
		
		do {
			System.out.print("▷자본금변경[변경하지 않으려면 그냥 엔터하세요] : "); 
			String str_seedMoney = sc.nextLine(); // String 타입으로 받아왔지만, setHopeMoney는 int로 들어가야한다.
			
			if("".equals(str_seedMoney)) {
				// System.out.println("엔터이군요!");
				str_seedMoney = String.valueOf(original_seedMoney); // 그냥엔터를 쳤다면, 원래 업종을 다시 넘겨준다.
			}
			
			try {
				loginComp.setSeedMoney(Long.parseLong(str_seedMoney)); // 여기는 Exception을 유발시킨다.
				
				if(loginComp.getSeedMoney() > 0)  { 
					break;
				}
				
				
			} catch(NumberFormatException e) {
				System.out.println("\n>>  정수만 입력 가능합니다.!! <<\n");
			}
			
		} while (true); // end of do~while----------------------------------------
		
		// 이미 위에서 끄집어온 구인회사에 (loginComp = compArr[i]) 정보를 넣고있다.

		return loginComp; // 변경되어진 정보를 넘긴다. 
		
		
	}//end of public void update(Scanner sc, Company loginComp)-----------------------------------

	
}
	

