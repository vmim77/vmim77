package my.day14.d.multi_interface;

public interface InterFather {
	void work();
}
