package my.day14.d.multi_interface;

public class Main {

	public static void main(String[] args) {

		MeImpl me = new MeImpl();
		me.work();
		me.cook();
		me.play();
		
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		InterMe interme = new MeImpl();
		
		// inter me 는 InterFather, InterMorthe, 그리고 본인의 InterMe에 있던 모든 메소드를 가져올 수 있다.
		interme.work();
		interme.cook();
		interme.play();
		
		
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		InterFather interfa = new MeImpl();
		// 실제는 MeImpl이지만, 저장장소는 인터페이스 파더이다.
		interfa.work(); // 그래서 work 밖에 안나온다. 하지만 실제 만든 객체는 MeImpl이니 거기에 있는 메소드를 모두 나오게 해야한다.
		
		((InterMe)interfa).cook();
		((InterMe)interfa).play();
		
		
		
		
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		InterMorther intermo = new MeImpl();
		((InterMe)intermo).work();
		intermo.cook();
		((InterMe)intermo).play();
		
	}// end of main(String[] args)-------------------

}
