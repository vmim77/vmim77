package my.day14.d.multi_interface;

public interface InterMe extends InterFather, InterMorther {
	// 자바는 인터페이스에서 여러개의 인터페이스를 다중상속이 가능하다.!!
	void play();

}
