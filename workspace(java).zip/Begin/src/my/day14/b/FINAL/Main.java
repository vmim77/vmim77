package my.day14.b.FINAL;

public class Main {

	public static void main(String[] args) {
		
		Father fa = new Father();
		
		System.out.println("아이디 : " + fa.id);
		System.out.println("성씨 : " + fa.FIRSTNAME + "씨");
		
		fa.test();
		fa.exam();
		
	}// end of main(String[] args)--------------------------

}
