package my.day14.b.FINAL;

public final class Father extends GrandFather {
	
	String email;
	
	public Father() {
		id = "me";
		// FIRSTNAME = "이"; FIRSTNAME 은  final 변수이므로 새로운 값을 할당할 수 없다.
	}

	@Override
	void test() {
		System.out.println(">> This is test() method !! <<");
	}
	
//	@Override
//	void exam() {
//		System.out.println(">> This is exam() method !! <<");
//	}
	
	// exam() 메소드가 final 메소드로 되어있으므로 오버라이딩(재정의)이 불가하다.
	
	
}
