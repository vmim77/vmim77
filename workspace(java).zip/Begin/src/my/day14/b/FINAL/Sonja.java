package my.day14.b.FINAL;

public class Sonja extends Father {
	// Farther 클래스가 final 클래스이므로 Father 클래스를 상속을 해올 수 없다.
}
