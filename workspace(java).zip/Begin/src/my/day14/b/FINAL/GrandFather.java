package my.day14.b.FINAL;

public class GrandFather {
	
	String id = "father";
	final String FIRSTNAME = "김"; // final 변수를 상수변수 라고도 부른다.
	
	void test() {
		System.out.println(">> 이것은 test 메소드 입니다. <<");
	}
	
	final void exam() {
		System.out.println(">> 이것은 exam 메소드 입니다. <<");
	}
	
}
