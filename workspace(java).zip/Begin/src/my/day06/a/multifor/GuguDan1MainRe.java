package my.day06.a.multifor;

import java.util.Scanner;

public class GuguDan1MainRe {

	
	/*
    >> 몇단볼래? => 8엔터
    
    === 8단 ===
    8*1=8
    8*2=16 
    8*3=24
    8*4=32
    8*5=40
    8*6=48
    8*7=56
    8*8=64
    8*9=72 
    
    >> 또 하시겠습니까?[Y/N] => y엔터 또는 Y엔터
    
    >> 몇단볼래? => 1.34엔터 또는 똘똘이엔터
    >>> 2단부터 9단까지만 가능합니다 <<<
    
    >> 몇단볼래? => 345엔터
    >>> 2단부터 9단까지만 가능합니다 <<<
    
    >> 몇단볼래? => 3엔터
    
    === 3단 ===
       생략
       
    >> 또 하시겠습니까?[Y/N] => s엔터 또는 S엔터
    >>> Y 또는 N 만 가능합니다!! <<<
    
    >> 또 하시겠습니까?[Y/N] => n엔터 또는 N엔터
    
    == 프로그램종료 ==   
 */
	
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		outer:
		for(;;) { // 단수 정수형 검사 무한루프
			try {
				System.out.print(">> 몇단볼래? => ");
				String strDan = sc.nextLine();
				
				int dan = Integer.parseInt(strDan);
				
				if(2 <= dan && dan <= 9) {
					
					System.out.println("=== "+ dan +" ===");
					
					for(int i=1;i<10;i++) {
						System.out.println(dan+"*"+i+"="+(dan*i));
					}// end of for
					
				for(;;) { // 종료창 무한루프
					System.out.print(">> 또 하시겠습니까?[Y/N] => ");
					String yn = sc.nextLine();
					if("n".equalsIgnoreCase(yn)) {
						sc.close();
						break outer;
					}
					
					else if ("y".equalsIgnoreCase(yn)) {
						break; // 종료창 무한루프를 벗어나서 다시 구구단 for문으로 들어감
					}
					
					else
						System.out.println(">>> Y 또는 N 만 가능합니다!!! <<<");
						
				}// end of for
					
					
				}
				
				else {
					System.out.println(">>> 2단부터 9단까지만 가능합니다 <<<"); // 정수형이지만 2~9를 벗어난 값 변수
				}
	
			} catch (NumberFormatException e) {
				System.out.println(">>> 2단부터 9단까지만 가능합니다 <<<"); // 문자열, 실수형 입력 변수
			}
		}// end of for
		
		System.out.println("== 프로그램종료 ==");
	}// end of main(String[] args)-----------------------------

}
