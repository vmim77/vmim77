package my.day06.a.multifor;

public class HomeWorkMain {

	public static void main(String[] args) {

	System.out.println("== 과제 1 ==");
	int a = 0, b = 0, c = 0;
	
	for(a = 1;a <= 5;a++) { // 5줄
		
		for(b = 0;b < a;b++) {
			
			System.out.print("*");
		}// end of for----------------------------
		
		System.out.print("\n");
	}// end of for--------------------------------
	
	System.out.println("== 과제 2 ==");
	a = 0; b = 0; c = 0;
	
	for(a = 1; a <= 5; a++) {
		
		for(b=5; b>a; b--) {
			
			System.out.print(" ");
		}// end of for---------------------
		
		for(c=0; c < a; c++) {
			
			System.out.print("*");
		}// end of for---------------------
		System.out.print("\n");
	}// end of for-------------------------
	
	
	System.out.println("== 과제 3 ==");
	a = 0; b = 0; c = 0;
	
	for(a=1; a<=5; a++) {
		
		for(b=6; b>a; b--) {
			
			System.out.print("*");
		}// end of for-------------------------
		System.out.print("\n");
	}// end of for-------------------------

		
	System.out.println("== 과제 4 ==");
	a = 0; b = 0; c = 0;
	
	for(a=1; a<=5; a++) {
		
		if(a%2==0)
			continue;
		
		for(c=5; c>a; c-=2) {
			System.out.print(" ");
		}// end of for-------------------------
		
		for(b=0; b<a; b++) {
			System.out.print("*");
		}// end of for-------------------------
		
		System.out.print("\n");
	}// end of for-------------------------
	
	System.out.println("== 과제 5 ==");
	a = 0; b = 0; c = 0;
	
	for(a=1; a<=5; a++) {
		if(a%2==0)
			continue;
		for(c=1; c<a; c+=2) {
			System.out.print(" ");
		}// end of for-------------------------
		
		
		for(b=6; b>a; b--) {
			System.out.print("*");
		}// end of for-------------------------
		System.out.print("\n");
	}// end of for-------------------------
	
	System.out.println("== 과제 6 ==");
	a = 0; b = 0; c = 0;
	
	for(a=1; a<10; a++) {
		
		if(a%2==0) //1 3 5 7 9 
			continue;
		
		if(a<=5) {
			
			for(c=5; c>a; c-=2) {
				System.out.print(" ");
			}// end of for-------------------------
			
			for(b=0; b<a; b++) {
				System.out.print("*");
			}// end of for-------------------------         
		}
		else if(a<=9) {
			
			for(c=5; c<a; c+=2) {
				System.out.print(" ");
			}// end of for-------------------------
			
			
			for(b=10; b>a; b--) {
				System.out.print("*");
			}// end of for-------------------------
			
		}

		
		System.out.print("\n");
	}// end of for-------------------------
	
	System.out.println("== 입사문제 ==");
	a = 0; b = 0; c = 0;
	int cnt = 0;
	
	for(a=1; a<=9; a++) {
		
		for(b=10; a<b; b--) {
			
			System.out.print("*");
		}// end of for-------------------------
		
		cnt++;
		System.out.print(cnt);
		System.out.print("\n");
	}// end of for-------------------------

	}// end of main(Stinrg[] args)----------------------

}
