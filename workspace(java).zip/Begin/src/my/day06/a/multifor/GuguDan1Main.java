package my.day06.a.multifor;

import java.util.Scanner;

public class GuguDan1Main {

	
	/*
    >> 몇단볼래? => 8엔터
    
    === 8단 ===
    8*1=8
    8*2=16 
    8*3=24
    8*4=32
    8*5=40
    8*6=48
    8*7=56
    8*8=64
    8*9=72 
    
    >> 또 하시겠습니까?[Y/N] => y엔터 또는 Y엔터
    
    >> 몇단볼래? => 1.34엔터 또는 똘똘이엔터
    >>> 2단부터 9단까지만 가능합니다 <<<
    
    >> 몇단볼래? => 345엔터
    >>> 2단부터 9단까지만 가능합니다 <<<
    
    >> 몇단볼래? => 3엔터
    
    === 3단 ===
       생략
       
    >> 또 하시겠습니까?[Y/N] => s엔터 또는 S엔터
    >>> Y 또는 N 만 가능합니다!! <<<
    
    >> 또 하시겠습니까?[Y/N] => n엔터 또는 N엔터
    
    == 프로그램종료 ==   
 */
	
	
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		outer: // outer: 을 레이블 이라고 부르는데 그 레이블명이 지금은 outer 일 뿐이다.
		for(;;) {
			
			try {
				
				System.out.print(">> 몇단볼래? => ");
				
				String strDan = sc.nextLine(); // 몇 단 쳤는지가 변수에 들어감
				
				int dan = Integer.parseInt(strDan); // 단을 int로 바꿔서 변수에 들어감
				
				if ( 2 <= dan && dan <= 9){
					// 비록 int이지만 354나 80 등 높은 숫자가 못 들어오게 함
					// 해당하는 단을 출력하기 //
					
					System.out.println("=== "+ dan +" ===");
					
					for(int i=0;i<9;i++) {
						System.out.println(dan+"*"+(i+1)+"="+dan*(i+1));
											//8*1=8
											//8*2=16
						
					}//end of for--------------------------
					
				// 숫자 제대로 넣어서 연산하고 아래 종료창 for문을 이동한다.
				
				for(;;) {
					System.out.print(">> 또 하시겠습니까?[Y/N] => ");
					String yn = sc.nextLine(); // 또 할지 말지를 받는다.
					
					// yn <== "n" 또는 "N" 을 입력했다라면  종료시켜야 한다.
					if("N".equalsIgnoreCase(yn)) {//equals는 대문자와 소문자를 구분한다.
												  //equalsIgnoreCase는 대, 소문자를 구분하지않는다.
						
					//바깥 for문을 빠져나가는 break를 만들어야 한다.
					/*
			         === 레이블을 사용하여 break; 하기 ===
				            레이블명 뒤에는 : 을 붙이며 반드시 반복문 앞에 써야 한다.  
				            반복문에 이름표를 붙여주는 것이다.
				     */
						
					//그냥 break를 쓰면 종료창 for문을 빠져나가는 것이다.
						sc.close();  // 프로그램 종료이니 스캐너를 꺼준다.
						
						break outer; // 가장 바깥에서 선언되어진 for문을 빠져나가야 하는 것이다.  
			                         // outer가 레이블명이다.
					}
					
					
					// yn <== "y" 또는 "Y" 을 입력했다라면 또 하겠다는 것이니 >> 몇단볼래?를 출력해야함
					else if("Y".equalsIgnoreCase(yn)) {
						break; // 안쪽 for문을 빠져나가서 다시 처음으로 돌아감
							   // break; 와 가장 가까운 반복문(for)을 빠져나가는 것이다.
 					}
					
					// yn <== "n" 또는 "N" 또는 "y" 또는 "Y" 을 제외한 나머지 값을 입력한 경우
					else {
						System.out.println(">>> Y 또는 N 만 가능합니다!! <<<");
					}
					
				}//end of for------------------------------
					
							
				}
				
				else {
					System.out.println(">>> 2단부터 9단까지만 가능합니다 <<<");
					// 정수이지만 2 ~ 9 을 넘는 숫자를 못들어오게 한다.
				}
			
			} catch (NumberFormatException e) {
				System.out.println(">>> 2단부터 9단까지만 가능합니다 <<<");
				// 정수형이 아닌 똘똘이나 12.3456 이 못들어오게 한다.
			}
		}// end of for-----------------------------------
		
		System.out.println("\n== 프로그램 종료==");
		
	}// end of main(String[] args)-----------------------------

}
