package my.day06.a.multifor;

public class GuguDan2MainRe {

	public static void main(String[] args) {
		
		System.out.println("== 구구단 ==");
		
		int row = 0, col = 0;
		// row 는 9개 , col 는 8개
		
		for(row=1; row<10; row++) { // 얘는 곱해지는 수 
			for(col=2; col<10; col++) {
				System.out.print(col+"*"+row+"="+(col*row)+"\t");
			}
			System.out.print("\n");
		}


		

	}// end of main(String[] args)-----------------------

}
