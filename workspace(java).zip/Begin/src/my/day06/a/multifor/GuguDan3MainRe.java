package my.day06.a.multifor;

public class GuguDan3MainRe {
	

	public static void main(String[] args) {
		
		int dan = 0, row = 0;
		
		for(dan=2; dan<10; dan+=4) { //2,3,4,5 6,7,8,9
			for(row=1; row<10; row++) {
				for(int i=dan;i<dan+4;i++) {
				 System.out.print(i+"*"+row+"="+(i*row)+"\t");
				}// end of for
				System.out.print("\n");
			}// end of for
			System.out.println("\n");
		}//end of for

	}// end of main(String[] args)----------------

}
