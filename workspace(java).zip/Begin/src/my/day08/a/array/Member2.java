package my.day08.a.array;

public class Member2 {
	
	// field
	String id;
	String passwd;
	String name;
	static int count; // 초기치 0

	
	// 기본생성자
	public Member2() {
		count++;
	}
	
	// method
	String showInfo() {
		return "1. 아이디 : " + id +"\n"
			+  "2. 비밀번호 : " + passwd +"\n"
			+  "3. 성명 : " + name;
		
	}// end of showInfo()
	
}
