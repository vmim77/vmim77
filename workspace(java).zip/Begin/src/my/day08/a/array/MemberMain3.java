package my.day08.a.array;

import java.util.Scanner;

import my.util.MyUtil;

public class MemberMain3 {

	public static void main(String[] args) {
		
		Member2[] mbrArr = new Member2[3];
		
		/*
		for(int i=0; i<mbrArr.length; i++) {
			System.out.println(mbrArr[i]);
		}
		*/
		
		/*
			null
			null
			null
		 */
		
		/*
		for(int i=0; i<mbrArr.length; i++) {
			System.out.println(mbrArr[i].id);
			// java.lang.NullPointerException 이 발생함
			// null.id 자체는 없다.
		}
		*/
		
		Scanner sc = new Scanner(System.in);
		 int menuNo = 0;
		
		do {
			
			System.out.println("\n===========================  >> 메 뉴 <<  ===========================");
	        System.out.println("1.회원가입 2.모든회원조회 3.모든회원조회 4.특정아이디로 회원조회 5.프로그램종료");
	        System.out.print("▷ 선택하세요 => ");
	        
	        try {
		        menuNo =  Integer.parseInt(sc.nextLine());
		        //							"똘똘이" "5" "3" "2" "3" "4"
		        
		        if( !(1 <= menuNo && menuNo <= 5) ) {
		        	System.out.println(">> 메뉴에 없는 번호 입니다.\n");
		        	continue;
		        	// 3이 아니기 때문에 do~while을 빠져나가지 못하고 do로 돌아가서 다시 시작한다.
		        }
		        
		        switch (menuNo) { 
		        // 어차피 여기에 떨어지는 경우의 수는 1, 2, 3뿐이기 때문에 3을 위한 default는 안 써줘도 된다.
		        
				case 1: // 회원가입
					
					if(Member2.count < mbrArr.length) {
						// 배열에 저장할 여유공간이 있다면 
						
						Member2 mbr = new Member2(); // 배열은 최대 3개이므로 회원들의 정보들을 넣어줄 객체도 3개만 만들어줄 수 있다.
						
						System.out.println(">> 확인용 count : " + Member2.count); // 1 2 3
						// 회원가입할 때마다 count는 1씩 늘어난다.
						// point++를 넣어도 인스턴스는 메모리(RAM)이 서로 다른 주소에 저장되기 때문에 계속 1이 나온다.
						
						System.out.print("\n1. 아이디 : ");
						mbr.id = sc.nextLine();
						
						do {
							System.out.print("2. 비밀번호 : ");
							String passwd = sc.nextLine(); // 그냥엔터 "aB12$" "adfsSf32145152##!!"(글자수 오버) "qwer12345" "qwEr1234$"
							
							if(MyUtil.isCheckPasswd(passwd)) {
								mbr.passwd = passwd;
								break; // do ~ while 문의 break 이다.
							}
							else {
								System.out.println(">> 암호는 8글자 이상 15글자 이하의 영문 대,소문자 및 숫자 및 특수문자가 혼합되어야 합니다!!\n <<");
								
							}
						} while(true);
						
						System.out.print("3. 성명 : ");
						mbr.name = sc.nextLine();
						
						for(int i=0; i<mbrArr.length; i++) {
							if( mbrArr[i] == null ) { // 비어있는 곳들을 차례대로 찾아서 비워져있으면 회원님들의 정보를 각각 넣어준다.
								mbrArr[i] = mbr; // 비어있는 방에 mbr의 id, passwd, name을 넣어준다.
								break; // break를 안 잡아주면 0, 1, 2번 방이 처음에는 모두 비워져있어서 다 이순신을 넣어버린다.
							}
						}// end of for------------------------------
						
					} 
					
					else { // 배열에 저장할 여유공간이 없다면 즉, 정원마감 이라면
						System.out.println(">> 더이상 회원을 저장할 공간이 없습니다. 정원마감!!!");
					}
					
					break; // switch 의 break 이다.
					
				case 2: // 모든회원조회
					
					int nullCount = 0;
					
					for(int i=0; i<mbrArr.length; i++) {
						if(mbrArr[i]!=null) {
							System.out.println(mbrArr[i].showInfo()+"\n");
						}	
						else {
							nullCount++;
						}
					}// end of for---------------------------
					
					if(nullCount == mbrArr.length) { // 가입된 회원이 아무도 없으면 nullCount는 3이 됨.
													 // null의 갯수와 mbrArr의 길이가 같다면 모든 배열의 방이 비었다는 말이다!
						System.out.println(">> 가입된 회원이 0명 입니다. <<");
					}
					
					break; // switch 의 break 이다.
					
				case 3: // 모든회원조회(다른 방법)
					
					if(Member2.count > 0) {
					
						for(int i=0; i<Member2.count; i++) { // 내가 실제로 만든 회원 수만큼만 돌리면 된다.
							System.out.println(mbrArr[i].showInfo()+"\n");
							
						}// end of for---------------------------
					}
					
					else {
						System.out.println(">> 가입된 회원이 0명 입니다. <<");
					}
					
					break; // switch 의 break 이다.
					
				case 4: // 4.특정아이디로 회원조회
					
					if(Member2.count > 0) {
						
						System.out.print("▷ 조회하고자 하는 아이디 : ");
						String searchID = sc.nextLine();
						
						boolean isExists = false;
						for(int i=0; i<Member2.count; i++) {
							
							if(mbrArr[i].id.equals(searchID)) {// 내가 쓴 아이디와 저장되어진 인스턴스의 아이디가 같다라면
							 System.out.println(mbrArr[i].showInfo());
							 isExists = true;
							 break; // 더 이상 검사할 것이 없으니 나간다.
							}

						}//end of for-----------------------
						
						if(!isExists) { // 존재하지않는 아이디로 조회했다면
							System.out.println("저장되어진 회원중 아이디가 "+searchID +"인 회원은 없습니다.");
						}
							
						
					} 
					else { // 가입된 회원이 없는데 조회하려고 하는 경우
						
						System.out.println(">>> 가입된 회원이 없으므로 특정아이디로 검색이 불가합니다. <<<\n");
					}
					break; // switch 의 break 이다.
					
				}// end of switch----------------------------
		        
			} catch (NumberFormatException e) {
				System.out.println(">> 정수만 입력하세요!! <<");
			}
		
		} while(!(menuNo == 5));
		// 얘가 false면 빠져나오니 (    )이 true면 !때문에 빠져나와진다.
		
		sc.close();
		
		System.out.println(">>  프로그램 종료 <<");
	}// end of main(String[] args)-------------------------------

}
