package my.day08.a.array;

public class SpaceDeleteMain4 {

	public static void main(String[] args) {
		
		// === 문자열 중 공백 제거하기 === //
		
		String str = "  korea   seou l 쌍용 강북 교육센터  ";
		System.out.println(str);
		
		char[] chArr = str.toCharArray();
		
		
		// "koreaseoul쌍용강북교육센터" ==> 18글자
		
		/*
	       --------------------------------------------------------------------------------------------------------------------------
	       |' '|' '|'k'|'o'|'r'|'e'|'a'|' '|' '|' '|'s'|'e'|'o'|'u'|' '|'l'|' '|'쌍'|'용'|' '|'강'|'북'|' '|'교'|'육'|'센'|'터'|' '|' '|         
	       --------------------------------------------------------------------------------------------------------------------------    
	    */
		
		int len = 0;
		for(int i=0; i<chArr.length; i++) {
			
			if(chArr[i] != ' ') {
				len++;
			}
			
		}// end of for------------------------------
		
		// System.out.println(len);
		// len = 18 (공백이 아닌 글자 개수)
		
		char[] resultchArr = new char[len];
		/*
		 	------------------------------------------------
		 	| 0 | 1 | 2 | 3 |~~~~~~~~~~~~~~~~~~~~| 16 | 17 |
		 	------------------------------------------------
		 	** 초기치는 정수는 0, 실수는 0.0, char는 ' ', String 및 객체는 null 이다.
		 	
		    ------------------------------------------------------------------------------
	        |'k'|'o'|'r'|'e'|'a'|'s'|'e'|'o'|'u'|'l'|'쌍'|'용'|'강'|'북'|'교'|'육'|'센'|'터'|  
	        ------------------------------------------------------------------------------	
		 */
		
		for(int i=0, j=0; i<chArr.length; i++, j++) { // chArr.length ==> 29
			
			if(chArr[i] != ' ') {
					resultchArr[j] = chArr[i];
				///////////////// 잘못된 케이스 /////////////////	
				//  resultchArr[i] = chArr[i]로 식을 넣으면
				//  resultchArr[0] 에는 공백이 들어가고
				//  resultchArr[1] 에도 공백이 들어간다.
				//  resultchArr[2] = 'k'
				// .................
				//  resultchArr[17] ==> 마지막 인덱스번호
				//  resultchArr[18] ==> 배열의 크기를 오버했다.
					
				// resultchArr은 18개, chArr은 29개라서 또 오버를 했으므로
				// java.lang.ArrayIndexOutOfBoundsException 이 뜬다.
					
				///////////////// 올바른 케이스 /////////////////
				// resultchArr[0] = 'k'
				}
			
			else {
				j--;
			}
			

		
				
			
		}// end of for------------------------
		String result = "";
		
		
		for(char ch : resultchArr) { // 얘는 하나하나 누적해서 문자열로 만드는 거고
			result += ch;
		}
		System.out.println(result);
		// "koreaseoul쌍용강북교육센터"
		
		// 또는
		System.out.println(String.valueOf(resultchArr)); // 얘는 배열의 값들을 한 번에 문자열로 만들어버림
		
	}// end of main(Stinrg[] args)-------------------------------

}
