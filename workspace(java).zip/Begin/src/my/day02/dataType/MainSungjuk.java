package my.day02.dataType; //실행부

public class MainSungjuk {

	public static void main(String[] args) {

		// == 문자형 타입 == //
		// 자바는 char 타입을 표현할 때 unicode 를 사용한다.
		// char sung = 48149;
		char sung = '박';

		System.out.println((int) sung);
		// 48149 char 타입에 있는 글자를 그대로 보이지 말고, 숫자로 보여라

		char ch1 = 65;
		System.out.println("ch1 : " + ch1); // A

		char ch2 = 'a' + 1; // 'a'가 int로 바뀐다. 97+1 ==> 98 , 'a'는 변수가 아니여서 형변환 안해도 괜찮다.
		System.out.println("ch2 : " + ch2); // b

		char ch3 = (char) (ch2 - 1); // 98-1 ==> 97
		System.out.println("ch3 : " + ch3); // a

		char ch4 = '\u2665';
		System.out.println("ch4 : " + ch4); // ♥ 16진수를 나타내려면 다음과 같이 나타낸다.

		String hakbun1 = "0012345"; // 0012345

		System.out.println(hakbun1);

		int hakbun2 = 0012345;
		System.out.println(hakbun2); // 5349

		long money = 50000000000L;
		// 자바에서 정수는 기본적으로 int 타입을 취하므로 long 타입으로 나타내려면
		// 숫자 뒤에 L 또는 l 을 쓰면된다.

		System.out.println(money); // 50000000000

		short jumsu = (short) 30000;
		System.out.println(jumsu);

		System.out.println("10/4 = " + (10 / 4));
		// 10/4 = 2

		System.out.println("10.0/4 = " + (10.0 / 4));
		// 10.0/4 = 2.5

		System.out.println("10/4.0 = " + (10 / 4.0));
		// 10/4.0 = 2.5

		System.out.println("10.0/4.0 = " + (10.0 / 4.0));
		// 10.0/4.0 = 2.5

		System.out.println("283/3 = " + (283 / 3));
		// 283/3 = 94

		System.out.println("283/3.0 = " + (283 / 3.0));
		// 283/3.0 = 94.33333333333333

		System.out.println("(float)(283/3.0) = " + (float) (283 / 3.0));
		// (float)(283/3.0) = 94.333336

		System.out.println("283/3.0F = " + (283 / 3.0F));
		// 283/3.0F = 94.333336

		System.out.println("283/3.0f = " + (283 / 3.0f));
		// 283/3.0f = 94.333336

		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~");

		int point = 70;

		if (point >= 90) {
			System.out.println(point + "는 90보다 같거나 큽니다.");

		} else if (point >= 70) {
			System.out.println(point + "는 70보다 같거나 큽니다.");

		} else {
			System.out.println(point + "는 70보다 작습니다.");
		}

		boolean bool1 = true;

		if (!bool1) { // !는 not
			System.out.println("bool1 => " + bool1);
		}

		boolean bool2 = false;

		if (!bool2) { // !는 not
			System.out.println("bool2 => " + bool2);
		}

		System.out.println("\n ============================= \n");

		Sungjuk lssSj = new Sungjuk(); // lssSj 인스턴스화
		lssSj.hakbun = "091234"; // 학번
		lssSj.name = "이순신"; // 성명
		lssSj.kor = 68; // 국어 68점
		lssSj.eng = 95; // 영어 95점
		lssSj.math = 10; // 수학 10점

		Sungjuk eomSj = new Sungjuk(); // eomSj 인스턴스화
		eomSj.hakbun = "109876"; // 학번
		eomSj.name = "엄정화"; // 성명
		eomSj.kor = 98; // 국어 98점
		eomSj.eng = 88; // 영어 88점
		eomSj.math = 95; // 수학 95점

		lssSj.showSungjuk(); // 이순신의 성적

		eomSj.showSungjuk(); // 엄정화의 성적

		System.out.println("\n ########################################## \n");

		Sungjuk hongkdSj = new Sungjuk(); // hongkdSj 인스턴스화

		System.out.println("lssSj : " + lssSj);
		// lssSj : my.day02.dateType.Sungjuk@15db9742

		System.out.println("eomSj : " + eomSj);
		// eomSj : my.day02.dateType.Sungjuk@6d06d69c

		System.out.println("hongkdSj : " + hongkdSj);
		// hongkdSj : my.day02.dateType.Sungjuk@7852e922

		hongkdSj = eomSj; // 엄정화의 메모리 주소를 홍길동에게 부여한 것이다.

		System.out.println("hongkdSj : " + hongkdSj);
		// hongkdSj : my.day02.dateType.Sungjuk@6d06d69c

		hongkdSj.showSungjuk();

		/*
		 * ==== 성적결과 ==== 1. 학번 : 109876 2. 성명 : 엄정화 3. 국어 : 98 4. 영어 : 88 5. 수학 : 95 6.
		 * 총점 : 281 7. 평균1 : 93.666664 8. 평균2 : 93.666664 9. 평균3 : 93.66666666666667 10.
		 * 장학금 : 1000000원 11. 학점 : A
		 */

		hongkdSj.name = "홍길동";

		hongkdSj.showSungjuk();
		eomSj.showSungjuk();

		/*
		 * 홍길동이나 엄정화나 서로 똑같은 메모리 주소를 가지게 했기 때문에 홍길동의 항목을 바꿔도 엄정화의 항목도 똑같이 바뀌게 된 것이다.
		 */

	}
}
