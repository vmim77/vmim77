package my.day17.a.recruitment;

public class Recruitment {
	
	// field
	private String title; // 채용공고문
	private int hireCount; // 채용인원수
	
	private Company comp; // 채용하려는 회사의 정보(ID, ,회사명, EMAIL) 

	
	// method
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getHireCount() {
		return hireCount;
	}

	public void setHireCount(int hireCount) {
		this.hireCount = hireCount;
	}


	
	public Company getComp() {
		return comp;
	}

	public void setComp(Company comp) {
		this.comp = comp;
	}

	// 채용정보를 알려주는 메소드
	public String recruitInfo() {
		
		return "1. 채용공고문 : " + title + "\n"
			 + "2. 인원수 : " + hireCount + "명\n"
			 + "3. 회사명 : " + comp.getName() + "\n"
			 + "4. 담당자이메일 : " + comp.getEmail() + "\n";
		
		
	}// end of public String recruitInfo()-------------


	
	
}
