package my.day17.a.recruitment;

import java.util.*;

public class RecruitmentMain {

	public static void main(String[] args) {
		
		Map<String, Company> compMap = new HashMap<>();
		// 회사는 여러 회사가 넣고, ID값으로 빠르게 찾으려 Map로 한다.
		
		List<Recruitment> recruitList = new ArrayList<>();
		// 채용건수는 전체를 빠르게 봐야해서 List로 한다.
		
		// 구인회사로 회원가입
		Company comp1 = new Company();
		comp1.setId("samsung");
		comp1.setName("삼성");
		comp1.setEmail("samsungman@gmail.com");
		
		compMap.put("samsung", comp1);
		
		Company comp2 = new Company();
		comp2.setId("lg");
		comp2.setName("엘지");
		comp2.setEmail("lgman@gmail.com");
		
		compMap.put("lg", comp2);
		
		
		// 구인회사로 회원가입한 samsung 이 채용공고를 냈다.
		Recruitment rcmt1 = new Recruitment(); // 첫번째 공고
		rcmt1.setComp(compMap.get("samsung"));
		// 키값을 넣으면, 벨류값이 나온다.
		rcmt1.setTitle("삼성에서 프로그래머 신입직원 채용합니다.");
		rcmt1.setHireCount(10);
		
		recruitList.add(rcmt1);
		
		// 구인회사로 회원가입한 lg 가 채용공고를 냈다.
		Recruitment rcmt2 = new Recruitment(); // 두번째 공고
		rcmt2.setComp(compMap.get("lg"));
		rcmt2.setTitle("엘지에서 일할 경영신입직원 채용합니다.");
		rcmt2.setHireCount(5);
		
		recruitList.add(rcmt2);
		
		// 구인회사로 회원가입한 samsung 이 채용공고를 냈다.
		Recruitment rcmt3 = new Recruitment(); // 세번째 공고
		rcmt3.setComp(compMap.get("samsung"));
		rcmt3.setTitle("삼성에서 일할 회계신입직원 채용합니다.");
		rcmt3.setHireCount(2);
		
		recruitList.add(rcmt3);
		
		System.out.println("==== 모든 채용공고 조회하기 ====\n");
		
		for(int i=0; i<recruitList.size(); i++) {
			System.out.println(recruitList.get(i).recruitInfo()); // 채용정보를 알려준다. (제목, 인원수, 회사명, 이메일)
		}// end of for------------------------
		
		
	}// end of main(String[] args)------------------------

}
