package my.day17.b.subject;

import java.util.*;

public interface InterGujikjaCompanyCtrl {
	
	// == 구직자(Gujikja) 신규 회원가입을 해주는 메소드 생성하기 ==  
	boolean registerGujikja(Scanner sc, List<Gujikja> guList);
		
	// == 구인회사(Company) 신규 회원가입을 해주는 메소드 생성하기 ==  
	boolean registerCompany(Scanner sc, List<Company> compList);
	
	// 연령대에 해당하는 구직자 찾아보기
	void search(int ageline, List<Gujikja> guList);
	
	// === 성별로 구직자 찾아보기 ===
	void search(String gender, List<Gujikja> guList);
	
	// === 특정 연령대에 해당하는 회원중 특정 성별 회원만 출력해주기 메소드 생성 === //   
	void search(int ageline, String gender, List<Gujikja> guList);
	
	// 모든 구직자 희망급여보기
	void showAllHopeMoney(List<Gujikja> guList);
	
	// == Gujikja 인스턴스가 제대로 생성되었는지 확인 시켜주는 메소드 생성 == //
	boolean checkGujikja(Gujikja gu);
	
	// == Company 인스턴스가 제대로 생성되었는지 확인 시켜주는 메소드 생성 == //
	boolean checkCompany(Company comp);
	
	// === 구직자 로그인 ===
	Gujikja login(Scanner sc, List<Gujikja> guList);
	
	// === 구인회사 로그인 ===
	Company login(List<Company> compList, Scanner sc);
	
	// === 구직자 또는 구인회사 모두 보기 ===
	void showAll1(List<Gujikja> guList);
	
	// 모든 구인회사 보기
	void showAll2(List<Company> compList);
	
	// 구직자 나의 정보 변경해주는 메소드
	Gujikja update(Scanner sc, Gujikja loginGu);
	
	// 구인회사 정보 변경해주는 메소드
	Company update(Scanner sc, Company loginComp);
	
	// 구인공고 등록해주는 메소드
	void registerRc(Scanner sc, Company loginComp, List<Recruitment1> rcList);

	
	
	

}
