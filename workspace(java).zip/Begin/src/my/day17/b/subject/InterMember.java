package my.day17.b.subject;

public interface InterMember {
	
	// 추상메소드(미완성메소드)
	String showInfo(); // public abstract 가 자동으로 생략되어져 있다.
	
}
