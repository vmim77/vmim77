package my.day17.b.subject;

import java.util.*;


public class GujikjaCompanyMain {

	public static void main(String[] args) {
		
		InterGujikjaCompanyCtrl ctrl = new GujikjaCompanyCtrl();  
	
		List<Gujikja> guList = new ArrayList<>(); // 구직자용 저장소
		List<Company> compList = new ArrayList<>(); // 회사용 저장소
		List<Recruitment1> rcList = new ArrayList<>(); // 채용공고용 저장소
		
		///////////////////////////////////////////////////////////////
		
		Gujikja gu1 = new Gujikja();
		gu1.setId("leess");
		gu1.setPasswd("qwer1234$A");
		gu1.setName("이순신");
		gu1.setMobile("01011111111");
		gu1.setHopeMoney(5000);
		gu1.setJubun("9001011");
		
		guList.add(gu1);
		
		Gujikja gu2 = new Gujikja();
		gu2.setId("eomjh");
		gu2.setPasswd("qwer1234$A");
		gu2.setName("엄정화");
		gu2.setMobile("01022222222");
		gu2.setHopeMoney(5000);
		gu2.setJubun("9001012");
		
		guList.add(gu2);
		
		///////////////////////////////////////////////////////////////
		
		Company comp1 = new Company();
		comp1.setId("lg");
		comp1.setPasswd("qwer1234$A");
		comp1.setName("엘지");
		comp1.setMobile("01022222222");
		comp1.setJobType("반도체");
		comp1.setSeedMoney(5000000);
		
		compList.add(comp1);
		
		Company comp2 = new Company();
		comp2.setId("samsung");
		comp2.setPasswd("qwer1234$A");
		comp2.setName("삼성");
		comp2.setMobile("01033333333");
		comp2.setJobType("IT");
		comp2.setSeedMoney(9000000);
		
		compList.add(comp2);
		
		Company comp3 = new Company();
		comp3.setId("sk");
		comp3.setPasswd("qwer1234$A");
		comp3.setName("에스케이");
		comp3.setMobile("01044444444");
		comp3.setJobType("서비스");
		comp3.setSeedMoney(7000000);
		
		compList.add(comp3);
		
		////////////////////////////////////////////////////////////////
		
		Recruitment1 rc1 = new Recruitment1();
		rc1.setComp(compList.get(0));
		rc1.setTitle("LG 반도체 생산직 경력직 직원 모집");
		rc1.setHireCount(5);
		
		rcList.add(rc1);

		Recruitment1 rc2 = new Recruitment1();
		rc2.setComp(compList.get(1));
		rc2.setTitle("삼성 프로그래머 개발직 신규 직원 모집");
		rc2.setHireCount(2);
		
		rcList.add(rc2);
		
		Recruitment1 rc3 = new Recruitment1();
		rc3.setComp(compList.get(2));
		rc3.setTitle("SK 서비스직 인턴십 사원 모집");
		rc3.setHireCount(3);
		
		rcList.add(rc3);
		
		////////////////////////////////////////////////////////////////
		
		Scanner sc = new Scanner(System.in);
		
		String smenuNo = "";
		
		Gujikja loginGu = null; // 구직자로 로그인 되어지면  로그인 되어진 구직자 인스턴스를 저장할 용도임.
		Company loginComp = null; // 구인회사로 로그인 되어지면  로그인 되어진 구인회사 인스턴스를 저장할 용도임.
		
		
		
		do {
			
			System.out.println(">>> === 메인메뉴 ===  <<<\n" 
					+ "1.구직자 회원가입    2.구인회사 회원가입 \n"
					+ "3.구직자 로그인       4.구인회사 로그인 \n"
					+ "5.프로그램 종료 ");

			System.out.print("\n▷ 메뉴번호 선택 => "); 
			smenuNo = sc.nextLine();
			
			switch (smenuNo) {
			
			case "1": // 구직자 회원가입
				
				boolean result = ctrl.reqgisterGujikja(sc, guList);  
				
				if(result) {
					System.out.println(">> 구직자 회원가입 성공 !! \n");
				}

				break; // switch 의 break 이다.
				
			case "2": // 구인회사 회원가입
				
				result = ctrl.registerCompany(sc, compList);  
				
				if(result) {
					
					System.out.println(">> 구인회사 회원가입 성공 !! \n");
				}
				
				break; // switch 의 break 이다.
				
			case "3": // 구직자 로그인
			
				loginGu = ctrl.login(sc, guList); 
											    
				if(loginGu == null) {
					
					System.out.println("\n>> 로그인 실패!! <<\n");
				}
				
				else {
					guLogin(sc, ctrl, guList,loginGu, compList, rcList);
				}
				
				
				break;  // switch 의 break 이다.
				
				
			case "4": // 구인회사 로그인
				

				loginComp = ctrl.login(compList, sc); 
			    
				if(loginComp == null) {
					System.out.println("\n>> 로그인 실패!! <<\n");
				}
				
				else {
					compLogin(sc, ctrl, guList,loginComp, compList, rcList);
					loginComp = null;
				}

				break; // switch 의 break 이다.
				
				
			case "5": // 프로그램 종료
				
				break; // switch 의 break 이다.
				
			default : 
				System.out.println("\n>> 메뉴에 없는 번호 입니다. <<\n");
				
				break; // switch 의 break 이다.
				
			}// end of switch ---------------------------------------
			
		} while (!("5".equals(smenuNo))); // 4번을 누르면 do~while을 빠져나와라
		
		
		
		sc.close();
		System.out.println("\n ===== 프로그램 종료 ===== \n");

		

		
	}// end of main(String[] args)---------------------------------------------------
	
	
	// 구직자 로그인 메뉴
	static void guLogin(Scanner sc, InterGujikjaCompanyCtrl ctrl, List<Gujikja> guList, 
			Gujikja loginGu, List<Company> compList, List<Recruitment1> rcList) {
		
		String sMenuNo ="";
		
		
		do {
			
			System.out.println("\n>>> === 메인메뉴[구직자 "+ loginGu.getName() +" 로그인중..] ===  <<<\n"
					+ "1.모든 구인회사 보기	        2.모든 채용공고 보기\n"
					+ "3.내정보 변경하기		4.검색                    \n"
					+ "5.로그아웃                                                        \n");
	
			System.out.print("▷ 검색메뉴번호 선택 => ");
			sMenuNo = sc.nextLine();
			
			switch (sMenuNo) {
			
			case "1": // 모든 구인회사 보기
				
				ctrl.showAll2(compList);
			
				break;
				
			case "2": // 모든 채용공고 보기
				
				for(int i=0; i<rcList.size(); i++) {
					
					System.out.println(rcList.get(i).recruitInfo());
					
				}// end of for----------------------------------

				break;
				
			case "3": // 내정보 변경하기
				
				loginGu = ctrl.update(sc, loginGu);
				
				System.out.println("\n>>=== 변경후 구직자 나의 정보 ===<<");
				System.out.println(loginGu.showInfo());
				
				break;
				
			case "4": // 검색(채용검색, 회사명검색)
				
				searchComp(sc, ctrl, compList, rcList);
				
				break;
				
			case "5": // 로그아웃
				
				System.out.println("\n>> 로그아웃 되었습니다. <<\n");
				loginGu = null;
				break;

			default:
				System.out.println("\n>> 메뉴에 없는 번호 입니다. <<\n");
				break;
			}
			
			
		} while(!("5".equals(sMenuNo)));
		
	}// end of static void guLogin(Scanner sc, InterGujikjaCompanyCtrl ctrl, List<Gujikja> guList, Gujikja loginGu, List<Company> compList, List<Recruitment1> rcList)
	
	
	// 구인회사 로그인 메뉴
	static void compLogin(Scanner sc, InterGujikjaCompanyCtrl ctrl, 
			List<Gujikja> guList, Company loginComp, List<Company> compList, List<Recruitment1> rcList) {
		
		String sMenuNo ="";
		
		do {
			
			System.out.println("\n>>> === 메인메뉴[구인회사 "+loginComp.getName()+" 로그인중..] ===  <<<\n"
					+ "1.모든 구직자 보기             2.채용공고등록\n"
					+ "3.우리회사채용공고 보기     4.우리회사정보 변경하기\n"
					+ "5.검색                              6.모든 구직자 희망급여보기\n"
					+ "7.로그아웃\n");
	
			System.out.print("▷ 검색메뉴번호 선택 => ");
			sMenuNo = sc.nextLine();
			
			switch (sMenuNo) {
			
			case "1": // 모든 구직자 보기
				
				ctrl.showAll1(guList);
			
				break;
				
			case "2": // 채용공고등록
				
				ctrl.registerRc(sc, loginComp, rcList);
				
				break;
				
			case "3": // 우리회사채용공고 보기
				
				boolean flag = false;
				
				for(int i=0; i<rcList.size(); i++) {
					
					if(loginComp.getId().equals(rcList.get(i).getComp().getId())) {
						
						System.out.println(rcList.get(i).recruitInfo());
						flag = true;
					}
					
				}// end of for------------------------
				
				if(!flag) {
					System.out.println("\n>> 우리 회사는 아직 공고를 등록하지 않았습니다! <<\n");
				}
					
				
				break;
				
			case "4": // 우리회사정보 변경하기
				
				loginComp = ctrl.update(sc,  loginComp);
				System.out.println("\n>>=== 변경후 구인회사 정보 ===<<\n");
				System.out.println(loginComp.showInfo());
				
				break;
				
			case "5": // 검색(성별검색, 연령대검색, 연령대및성별검색)
				
				searchGu(sc, ctrl, guList);
				
				break;
				
			case "6": // 모든 구직자 희망급여보기
				
				ctrl.showAllHopeMoney(guList);
				
				break;
				
			case "7": // 로그아웃
				
				System.out.println("\n>> 로그아웃 되었습니다. <<\n");
				loginComp = null;
				break;

			default:
				System.out.println("\n>> 메뉴에 없는 번호 입니다. <<\n");
				break;
			}
			
			
		} while(!("7".equals(sMenuNo)));
		
	}// end of static void compLogin(Scanner sc, InterGujikjaCompanyCtrl ctrl, List<Gujikja> guList, Company loginComp, List<Company> compList, List<Recruitment1> rcList)
	
	
	// 구인회사 검색 메뉴
	static void searchComp(Scanner sc, InterGujikjaCompanyCtrl ctrl, List<Company> compList, List<Recruitment1> rcList) {
		
		boolean flag = false;
		
		String sMenuNo = "";
		
		do {
			System.out.println("\n *** ====== 검색메뉴 ====== *** \n"
							+ "1.채용검색   2.회사명검색  3.메인으로 돌아가기\n");
			
			System.out.print("▷ 검색메뉴번호 선택 => ");
			sMenuNo = sc.nextLine();
			
			switch (sMenuNo) {
			case "1" : // 채용검색
				
				System.out.print("▷ 검색할 채용공고 제목 => ");
				String title = sc.nextLine();
				flag = false;
				for(int i=0; i<rcList.size(); i++) {
					
					if(title != null) {
						
						if( !title.trim().isEmpty() && rcList.get(i).getTitle().indexOf(title) != -1) {
							System.out.println(rcList.get(i).recruitInfo());
							flag = true;
						}
					}
				}// end of for---------------------------------------------
				
				if(!flag) {
					System.out.println("검색하신 내용에 해당되는 구인공고가 없습니다!!");
				}
				break;
				
			case "2" : // 회사명검색
				
				System.out.print("▷ 검색할 회사명 => ");
				String name = sc.nextLine();
				
				
				flag = false;
				for(int i=0; i<compList.size(); i++) {
					
					if(name != null ) {
						
						if (!name.trim().isEmpty() && compList.get(i).getName().indexOf(name) != -1) {
							
							System.out.println(compList.get(i).showInfo());
							flag = true;
						}
					}
					else {
						System.out.println(">> 회사명에 공백은 들어갈 수 없습니다!! <<");
					}
				}// end of for---------------------------------------------
				
				if(!flag) {	
					System.out.println("\n>> 입력하신 " + name + " 은 등록되지 않은 회사입니다.");
				}
				
				
				
				break;
				
			case "3" : // 메인으로 돌아가기
				
				
				break;
			
			default:
				System.out.println("\n>> 메뉴에 없는 번호 입니다. <<\n");
				break;
			}// end of switch (sMenuNo) -----------------------------------
			
		} while(!("3".equals(sMenuNo)));
		
	} // end of static void searchMenu()-------------------------------------
	
	
	// 구직자 검색 메뉴
	static void searchGu(Scanner sc, InterGujikjaCompanyCtrl ctrl, List<Gujikja> guList) {
		
		String sMenuNo = "";
		
		do {
			System.out.println("\n *** ====== 검색메뉴 ====== *** \n"
							+ "1.연령대검색   2.성별검색   3.연령대및성별검색   4.메인으로 돌아가기\n");
			
			System.out.print("▷ 검색메뉴번호 선택 => ");
			sMenuNo = sc.nextLine();
			
			switch (sMenuNo) {
			case "1" : // 연령대검색
				do {
					try {
						System.out.print("▷ 연령대 => ");
						
						
						String sAgeline = sc.nextLine();
						int ageline = Integer.parseInt(sAgeline); 
						
						if( ageline%10 == 0 && (0 <= ageline && ageline <= 70) ) {// ageline은 10의 배수이면서, 0~70까지만
							ctrl.search(ageline, guList);
							
							break; // do~while 의 break
						}
						else { 
							System.out.println("\n>> 검색할 수 없는 연령대 입니다.!!\n");
							
						}
						
					} catch(NumberFormatException e) {
						System.out.println("\n>> 정수만 입력하세요 !! <<\n");
					}
				} while(true);
				
				break;
				
			case "2" : // 성별검색
				
				
				do {
				
					System.out.print("▷ 성별[남/여] => ");
											
					String gender = sc.nextLine();
					
					gender = gender.trim();
					
					if("남".equals(gender) || "여".equals(gender)) {
						ctrl.search(gender, guList);
						break; // do~while의 break
					}
					else {
						System.out.println("\n>> 남 또는 여 만 입력하세요!! <<\n");
					}
						
				} while(true);
				
				
				break;
				
			case "3" : // 연령대및성별검색
				do {
					try {
						System.out.print("▷ 연령대 => ");
						
						String sAgeline = sc.nextLine();
						int ageline = Integer.parseInt(sAgeline); 
																  
						if( ageline%10 == 0 && (0 <= ageline && ageline <= 70) ) {
							String gender = "";
							do {
								System.out.print("▷ 성별[남/여] => ");
								gender = sc.nextLine();
								
								if("남".equals(gender.trim()) || "여".equals(gender.trim())) {
									break; // 가장 가까운 do~while 문을 빠져나가는 break
								}
								else {
									System.out.println("\n>> 남 또는 여 만 입력하세요!! <<\n");
								}
							} while(true);// end of do~while-----------------------------
						
							ctrl.search(ageline, gender, guList);
							break; // 바깥쪽 do~while 문을 빠져 나간다.
						}
						else { 
							System.out.println("\n>> 검색할 수 없는 연령대 입니다.!!\n");
						}
						
					} catch(NumberFormatException e) { // 문자열, 실수형이 들어오면 여기로 온다.
						System.out.println("\n>> 정수만 입력하세요 !! <<\n");
					}
				} while(true);// end of do~while-----------------------------
				
				break;
				
			case "4" : // 메인으로 돌아가기
				
				break; // switch 문의 break
			
	
			default:
				System.out.println("\n>> 메뉴에 없는 번호 입니다. <<\n");
				break;
			}// end of switch (sMenuNo) -----------------------------------
			
		} while(!("4".equals(sMenuNo)));
		
	} // end of static void searchMenu()-------------------------------------
	
	

}