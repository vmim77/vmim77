package my.day17.b.subject;

import java.util.*;

public class GujikjaCompanyCtrl implements InterGujikjaCompanyCtrl {
	
	@Override
	public boolean registerGujikja(Scanner sc, List<Gujikja> guList) { 
		
		boolean result = false;
		
			Gujikja gu = new Gujikja();
			
			do {
				System.out.print("1.  아이디 : ");
				String id = sc.nextLine(); 
				
				gu.setId(id);
				
				if(gu.getId() == null) { 
					continue;
				}
					
				boolean isDuplicate = false; 
				
				for(int i=0; i<guList.size(); i++) { 
					
					if(guList.get(i).getId().equals(id)) {
						isDuplicate = true;
						break;
					}
	
				}// end of for----------------------
				
				if(isDuplicate) { 
					System.out.println("\n>> 당신이 입력하신 "+ id +"는 이미 사용중 입니다. 새로운 아이디를 입력하세요!! <<\n");
				}
				else { 
					gu.setId(id);
					break; 
				}
			} while(true);
			
			
			do {
				System.out.print("2.  암호 : ");
				String passwd = sc.nextLine();
				
				gu.setPasswd(passwd); 
				
				if( gu.getPasswd() != null ) { 
					break;
				}

			} while(true);
			
			
			do {
				System.out.print("3.  성명 : ");
				String name = sc.nextLine();
				
				gu.setName(name);
				
				if(gu.getName() != null) { 
					break;
				}
				
			} while(true);

			
			do {
				System.out.print("4.  주민번호 앞의 7자리만 : "); 
				String jubun = sc.nextLine();
				
				gu.setJubun(jubun);
				
				if(gu.getJubun()!= null) {
					break;
				}
				
			} while (true); // end of do~while----------------------------------------
			
			do {
				System.out.print("5.  연락처 : "); 
				String mobile = sc.nextLine();
				
				gu.setMobile(mobile);
				
				if(gu.getMobile()!= null) {
					break;
				}
				
			} while (true); // end of do~while----------------------------------------
			
			do {
				System.out.print("6.  희망급여 : "); 
				String str_hopeMoney = sc.nextLine(); 
				
				try {
					gu.setHopeMoney(Integer.parseInt(str_hopeMoney));
					
					if(1000 <= gu.getHopeMoney() && gu.getHopeMoney() <= 9999)  { 
						break;
					}
					
					
				} catch(NumberFormatException e) {
					System.out.println("\n>>  정수만 입력 가능합니다.!! <<\n");
				}
				
			} while (true); // end of do~while----------------------------------------
			
			
			if(checkGujikja(gu)) { 

				guList.add(gu);
				result = true;
			}

		return result;
	}// end of public boolean registerGujikja(Scanner sc, List<Gujikja> guList) --------------------------------------
	
	
	// == 구인회사(Company) 신규 회원가입을 해주는 메소드 생성하기 ==  
	@Override
	public boolean registerCompany(Scanner sc, List<Company> compList) {
		
		boolean result = false;
		
		
			
			Company comp = new Company(); // Company에 설계한 필드와 메소드를 사용하기 위해서 선언
			
			
			// == 아이디 중복검사 == //
			do {
				System.out.print("1.  아이디 : ");
				String id = sc.nextLine(); 
			
				
				comp.setId(id);
				
				if(comp.getId() == null) { 
					continue;
				}
					
				boolean isDuplicate = false; 
				
				for(int i=0; i<compList.size(); i++) { 
					
					if(compList.get(i).getId().equals(id)) { 
						isDuplicate = true; 
						break;
					}
	
				}// end of for----------------------
				
				if(isDuplicate) { 
					System.out.println("\n>> 당신이 입력하신 "+id+"는 이미 사용중 입니다. 새로운 아이디를 입력하세요!! <<\n");
				}
				else { 
					comp.setId(id);
					break; 
				}
			} while(true); // end of do~while----------------------------------------
			
			
		
			do {
				System.out.print("2.  암호 : ");
				String passwd = sc.nextLine();
				
				comp.setPasswd(passwd); 
				
				if( comp.getPasswd() != null ) {
					break;
				}

			} while(true); // end of do~while----------------------------------------
			
			
			
			do {
				System.out.print("3.  회사명 : ");
				String name = sc.nextLine();
				
				comp.setName(name);
				
				if(comp.getName() != null) { 
					break;
				}
				
			} while(true); // end of do~while----------------------------------------

			do {
				System.out.print("4.  인사 담당자 연락처 : "); 
				String mobile = sc.nextLine();
				
				comp.setMobile(mobile);
				
				if(comp.getMobile()!= null) {
					break;
				}
				
			} while (true); // end of do~while----------------------------------------
			
			
			do {
				System.out.print("5.  회사직종타입(서비스,제조업,IT,...) : "); 
				String jopType = sc.nextLine();
				
				comp.setJobType(jopType);
				
				if(comp.getJobType()!= null) {
					break;
				}
				
			} while (true); // end of do~while----------------------------------------
			
			
			do {
				System.out.print("6.  자본금 : "); 
				String str_seedMoney = sc.nextLine(); 
				
				try {
					comp.setSeedMoney(Long.parseLong(str_seedMoney)); 
					
					if(comp.getSeedMoney() > 0)  { 
						break;
					}
					
					
				} catch(NumberFormatException e) {
					System.out.println("\n>>  정수만 입력 가능합니다.!! <<\n");
				}
				
			} while (true); // end of do~while----------------------------------------
			
			
			if(checkCompany(comp)) { 

				compList.add(comp);
				result = true;
			}
			 		
		return result;

		
	}// end of public boolean registerCompany(Scanner sc, List<Company> compList) ------------------------
	
	
	
	// 연령대에 해당하는 구직자 찾아보기
	@Override
	public void search(int ageline, List<Gujikja> guList) {
		
		boolean isExists = false;
		
		for(int i=0; i<guList.size(); i++) {
			if( guList.get(i).getAge()/10*10 == ageline) {  // 내 나이가 20 24 29 이건                   => 20이 되야함
													  // 20/10*10 24/10*10 29/10*10  => 20
						
				isExists = true; // 내가 찾고자 하는 연령대의 정보가 있다면 배열에 있다면 true를 반환
				System.out.println(guList.get(i).showInfo()); // 이미 위에 if절에서 Gujikja임을 확인했으니, 여기는 형변환 불필요
			}

		}// end of for-------------------
		
		if(!isExists) {
			System.out.println("\n>> 검색하신 연령대 "+ageline +"대는 없습니다.<<\n");
		}
		
	}// end of void search(int ageline, Member[] mbrArr)-------------------------------
	
	
	
	
	// !!!! === method 의 overloading(메소드의 오버로딩) === !!!! //
	// ==> method 의 이름이 같더라도 
	//     파라미터의 개수나 또는 순서, 타입이 다르면 서로 다른 method 로 인식한다.
	
	
	// === 성별로 구직자 찾아보기 ===
	@Override
	public void search(String gender, List<Gujikja> guList) {
	      
	      for(int i=0; i<guList.size(); i++) {
	      
	    	 
    		 String n_gender = guList.get(i).getJubun().substring(6);
    		 //     "1"   "2"   "3"   "4"
    		 
    		 if("남".equals(gender)) { // "남"을 검색했는데
 	            if("2".equals(n_gender) || "4".equals(n_gender)) { // 꺼낸 구직자가 "여"이면
 	               continue; // 그 다음 사람을 검색한다.
 	            }
 	            else { // 꺼낸 사람도 "남"이면 그 구직자의 정보를 출력
 	               System.out.println(guList.get(i).showInfo());
 	            }
 	         }
 	         else { // "여"를 검색했는데
 	            if("1".equals(n_gender) || "3".equals(n_gender)) { // "꺼낸 구직자가 "남"이면
 	               continue; // 그 다음 사람을 검색한다.
 	            }
 	            else { // 꺼낸 사람도 "여"이면 그 구직자의 정보를 출력
 	               System.out.println(guList.get(i).showInfo());
 	            }
 	         }
	    	 
	         
	      }// end of for----------------------
	            
	   }// end of void search(String gender, Member[] mbrArr)-------------------------------
	   
	   
	   
	// === 특정 연령대에 해당하는 회원중 특정 성별 회원만 출력해주기 메소드 생성 === //   
	@Override
	public void search(int ageline, String gender, List<Gujikja> guList) {
		for(int i=0; i<guList.size(); i++) {
			
			
			
			if( ageline != guList.get(i).getAge()/10*10 ) { // 일단 연령대가 안 맞으면 다음 사람을 찾아온다.
				continue;
			}
			else { // 내가 찾고자하는 연령대와 가져온 구직자의 연령대가 똑같으면 
				String n_gender = guList.get(i).getJubun().substring(6); // 그 사람의 주민번호 끝자리를 가져온다.
				// "1" "2" "3" "4"
		
				if("남".equals(gender)) { // 내가 성별 선택을 "남"을 했는데
					if("1".equals(n_gender)||"3".equals(n_gender)) {// 가져온 구직자의 주민번호 끝자리도 "남"이라면
						System.out.println(guList.get(i).showInfo()); // 연령대와 성별도 맞으니 그 구직자의 정보를 출력한다.
					}
				}
				else { // 성별 선택을 "여"를 했는데
					if("2".equals(n_gender)||"4".equals(n_gender)) {// 가져온 구직자의 주민번호도 "여"이라면
						System.out.println(guList.get(i).showInfo());
					}
				}
			}
			
		}// end of for-------------------
		
	}// end of void search(int ageline, String gender, Member[] mbrArr)------------------------

	
	// 모든 구직자 희망급여보기
	@Override
	public void showAllHopeMoney(List<Gujikja> guList) {
		
		
		
		/*
		   -------------------
		            구직자명   희망급여
		   -------------------
		            엄정화       5,000만원
		            이순신       7,000만원
		            유관순       8,000만원
		 */

		
		System.out.println("-------------------------------------");
		System.out.println("구직자명               희망급여");
		System.out.println("-------------------------------------");
		
		for(int i=0; i<guList.size(); i++) {
			
			System.out.println(guList.get(i).getName()+"                  "+guList.get(i).strHopeMoney() );
			
		}// end of for----------------------
		
	}// end of public void showAllHopeMoney()-----------------------
		
	
	// 구직자들의 입력받은 필드값(Gujikja)들을 모두 검사하여서, null값이 있는지 없는지 확인한다.
	// 사용은 GujikjaMain에서 써야하니, private는 안 된다.
	// 같은 패키지이든, 다른 패키지이든 모든 곳에서 사용하게 하고싶다면 public로 한다.
	
	// == Gujikja 인스턴스가 제대로 생성되었는지 확인 시켜주는 메소드 생성 == //
	@Override
	public boolean checkGujikja(Gujikja gu){
		
		if(gu.getId() != null &&
		   gu.getPasswd() != null &&
		   gu.getName() != null &&
		   gu.getMobile() != null &&
	       gu.getJubun() != null &&
		   gu.getHopeMoney() > 0) {
			
			return true;
		}
		else {
			return false;
		}
		
	}
	
	// == Company 인스턴스가 제대로 생성되었는지 확인 시켜주는 메소드 생성 == //
	@Override
	public boolean checkCompany(Company comp){
		
		if(comp.getId() != null &&
		   comp.getPasswd() != null &&
		   comp.getName() != null &&
		   comp.getMobile() != null &&
		   comp.getJobType() != null &&
		   comp.getSeedMoney() > 0) {
			
			return true;
		}
		else {
			return false;
		}
		
		
	}

	// === 구직자 로그인 ===
	@Override
	public Gujikja login(Scanner sc, List<Gujikja> guList) {
		
		Gujikja loginGu = null;
		
		System.out.print("▷ 구직자 ID : ");
		String input_id = sc.nextLine();
		
		System.out.print("▷ 비밀번호 : ");
		String input_passwd = sc.nextLine();
		
		for(int i=0; i<guList.size(); i++) {
			String id = guList.get(i).getId();
			String passwd = guList.get(i).getPasswd();
			
			if(id.equals(input_id) && passwd.equals(input_passwd)) {
				// id 및 암호가 일치했다라면
				loginGu = guList.get(i); 
				break;
				}
		
		}// end of for-------------------
				
		return loginGu;
	}// end of public Gujikja login(Scanner sc, Map<String, Gujikja> guMap)



	// === 구인회사 로그인 ===
	@Override
	public Company login(List<Company> compList, Scanner sc) {
		
		Company loginComp = null;
		
		System.out.print("▷구인회사 ID : ");
		String input_id = sc.nextLine();
		
		System.out.print("▷비밀번호 : ");
		String input_passwd = sc.nextLine();
		
		for(int i=0; i<compList.size(); i++) {
			String id = compList.get(i).getId();
			String passwd =compList.get(i).getPasswd();
			
			if(id.equals(input_id) && passwd.equals(input_passwd)) {
				// id 및 암호가 일치했다라면
				
				loginComp = compList.get(i); 
				break;
			}
		}//end of for---------------------------
		
		return loginComp;
	}// end of public Company login(Map<String, Company> compMap, Scanner sc)-------------------



	// 모든 구직자보기
	@Override	
	public void showAll1(List<Gujikja> guList) {
			
		for(int i=0; i<guList.size(); i++) {
			
		
			System.out.println(guList.get(i).showInfo());

		
		}// end of for---------------------
		
	}// end of public void showAll(Map<String, Gujikja> guMap) ------------------------------------
		

	// 모든 구인회사 보기
	@Override
	public void showAll2(List<Company> compList) { 
		
		for(int i=0; i<compList.size(); i++) {
		
			System.out.println(compList.get(i).showInfo());

		
			
		}// end of for-----------------------
		
	}// end of public void showAll(Company[] compArr)--------------------------------



	// 구직자 나의 정보 변경해주는 메소드
	@Override
	public Gujikja update(Scanner sc, Gujikja loginGu) {
		
		System.out.println("\n>> === 변경전 구직자 나의 정보 === <<");
		System.out.println(loginGu.showInfo()); // 로그인 되어진 구직자를 받아서 그 사람의 정보를 보여준다.
		
		String original_passwd = loginGu.getPasswd();
		String original_name = loginGu.getName();
		int original_hopeMoney = loginGu.getHopeMoney(); // 만약 잘못친다면 null값으로 바뀌니깐, 바뀌기 전에 값들을 빼온다.
		

		
		
		do {
			System.out.print("▷암호변경[변경하지 않으려면 그냥 엔터하세요] : "); // 메인메소드에서 실행된 콘솔에서 입력된 스캐너값을 받는다.
			String passwd = sc.nextLine();
			
			if("".equals(passwd)) {
				// System.out.println("엔터이군요!");
				passwd = original_passwd; // 그냥엔터를 쳤다면, 원래 암호를 다시 넘겨준다.
			}
			
			loginGu.setPasswd(passwd); // 로그인 되어진 사람의 비밀번호를 일단 바꾼다.
			
			if( loginGu.getPasswd() != null ) { // 잘못 입력됐다고 메세지도 안 떳고, 들어간 값이 null이 아니면 정상이다.
				break;
			}

		} while(true);
		

		
		do {
			System.out.print("▷성명변경[변경하지 않으려면 그냥 엔터하세요] : ");
			String name = sc.nextLine();
			
			if("".equals(name)) {
				// System.out.println("엔터이군요!");
				name = original_name; // 그냥엔터를 쳤다면, 원래 성명을 다시 넘겨준다.
			}
			
			loginGu.setName(name);
			
			if(loginGu.getName() != null) { // 잘못 입력됐다고 메세지도 안 떳고, 들어간 값이 null이 아니면 정상이다.
				break;
			}
			
		} while(true);
		

		
		do {
			System.out.print("▷희망급여변경[변경하지 않으려면 그냥 엔터하세요] : "); 
			String str_hopeMoney = sc.nextLine(); // String 타입으로 받아왔지만, setHopeMoney는 int로 들어가야한다.
			
			if("".equals(str_hopeMoney)) {
				// System.out.println("엔터이군요!");
				str_hopeMoney = String.valueOf(original_hopeMoney); // 그냥엔터를 쳤다면, 원래 성명을 다시 넘겨준다.
			}
			
			try {
				
				loginGu.setHopeMoney(Integer.parseInt(str_hopeMoney)); // 여기는 Exception을 유발시킨다.
				
				if(1000 <= loginGu.getHopeMoney() && loginGu.getHopeMoney() <= 9999)  { // getHopeMoney의 초기값은 null이 아닌 0이여서 이렇게 조건을 설정한다.
					break;
				}
				
				
			} catch(NumberFormatException e) {
				System.out.println("\n>>  정수만 입력 가능합니다.!! <<\n");
			}
			
		} while (true); // end of do~while----------------------------------------
		
		
		// 이미 위에서 끄집어온 구직자에 (loginGu = guArr[i]) 정보를 넣고있다.

		return loginGu; // 변경되어진 정보를 넘긴다. 
		
	}// end of public boolean update(Scanner sc, Gujikja loginGu, Gujikja[] guArr)---------------------------



	// 구인회사 정보 변경해주는 메소드
	@Override
	public Company update(Scanner sc, Company loginComp) {
		
		//암호, 업종, 자본금
		
		

		
		System.out.println("\n>> === 변경전 구인회사 정보 === <<");
		System.out.println(loginComp.showInfo()); // 로그인 되어진 구직자를 받아서 그 사람의 정보를 보여준다.
		
		String original_passwd = loginComp.getPasswd();
		String original_jobType = loginComp.getJobType();
		long original_seedMoney = loginComp.getSeedMoney(); // 만약 잘못친다면 null값으로 바뀌니깐, 바뀌기 전에 값들을 빼온다.
		
		do {
			System.out.print("▷암호변경[변경하지 않으려면 그냥 엔터하세요] : "); // 메인메소드에서 실행된 콘솔에서 입력된 스캐너값을 받는다.
			String passwd = sc.nextLine();
			
			if("".equals(passwd)) {
				// System.out.println("엔터이군요!");
				passwd = original_passwd; // 그냥엔터를 쳤다면, 원래 암호를 다시 넘겨준다.
			}
			
			loginComp.setPasswd(passwd); // 로그인 되어진 사람의 비밀번호를 일단 바꾼다.
			
			if( loginComp.getPasswd() != null ) { // 잘못 입력됐다고 메세지도 안 떳고, 들어간 값이 null이 아니면 정상이다.
				break;
			}

		} while(true);
		
		
		do {
			System.out.print("▷업종변경[변경하지 않으려면 그냥 엔터하세요] : "); 
			String jopType = sc.nextLine();
			
			if("".equals(jopType)) {
				// System.out.println("엔터이군요!");
				jopType = original_jobType; // 그냥엔터를 쳤다면, 원래 업종을 다시 넘겨준다.
			}
			
			loginComp.setJobType(jopType);
			
			if(loginComp.getJobType()!= null) {
				break;
			}
			
		} while (true); // end of do~while----------------------------------------
		
		do {
			System.out.print("▷자본금변경[변경하지 않으려면 그냥 엔터하세요] : "); 
			String str_seedMoney = sc.nextLine(); // String 타입으로 받아왔지만, setHopeMoney는 int로 들어가야한다.
			
			if("".equals(str_seedMoney)) {
				// System.out.println("엔터이군요!");
				str_seedMoney = String.valueOf(original_seedMoney); // 그냥엔터를 쳤다면, 원래 업종을 다시 넘겨준다.
			}
			
			try {
				loginComp.setSeedMoney(Long.parseLong(str_seedMoney)); // 여기는 Exception을 유발시킨다.
				
				if(loginComp.getSeedMoney() > 0)  { 
					break;
				}
				
				
			} catch(NumberFormatException e) {
				System.out.println("\n>>  정수만 입력 가능합니다.!! <<\n");
			}
			
		} while (true); // end of do~while----------------------------------------
		
		// 이미 위에서 끄집어온 구인회사에 (loginComp = compArr[i]) 정보를 넣고있다.

		return loginComp; // 변경되어진 정보를 넘긴다. 
		
		
	}//end of public void update(Scanner sc, Company loginComp)-----------------------------------
	
	
	
	
	// 구인공고 등록하기
	public void registerRc(Scanner sc, Company loginComp, List<Recruitment1> rcList) {
		
		Recruitment1 rc = new Recruitment1();
		
		rc.setComp(loginComp);
		
		do {
			System.out.print("▷ 등록할 구인공고에 제목을 적어주세요  : ");
			String title = sc.nextLine();
			
			if(title != null && !title.trim().isEmpty()) {
				rc.setTitle(title);
				break;
			}
			else {
				System.out.println(" >> 제목에 공백이나 빈칸은 들어올 수 없습니다!!");
				continue;
			}
		} while(true); // 제목 검사
		
			
		do {
			try {
				System.out.print("▷ 구인할 인원을 적어주세요  : ");
				String str_hireCount = sc.nextLine();
				int hireCount = Integer.parseInt(str_hireCount);
				
				if(hireCount > 0) {
					rc.setHireCount(hireCount);
					
				}
				else {
					System.out.println("\n>> 구인인원수는 자연수만 입력해야 합니다!! <<\n");
					continue;
				}
				
				rcList.add(rc);
				System.out.println("\n>> 등록성공!! <<\n");
			
				break;
			} catch (NumberFormatException e) {
				System.out.println("\n>> 정수만 입력해야 합니다. <<\n");
			}
		} while(true); // 구인인원 검사
		
	};

	
}
	

